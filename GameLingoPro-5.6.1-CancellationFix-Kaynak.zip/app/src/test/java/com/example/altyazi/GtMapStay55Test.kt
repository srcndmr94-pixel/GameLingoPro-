package com.example.altyazi
import org.junit.Assert.*
import org.junit.Test
import java.io.File

class GtMapStay55Test {
    @Test fun temporaryOcrFailuresNeverEraseSelectedQuest() {
        for(misses in listOf(1,2,3,4,10,25)) {
            assertFalse(GtMapStay55.shouldExitMap(true,misses,false))
            assertFalse(GtMapStay55.shouldForgetQuest(true,misses))
        }
        assertFalse(GtMapStay55.shouldExitMap(true,3,true))
        assertTrue(GtMapStay55.shouldExitMap(true,4,true))
    }
    @Test fun userCanOptOutOfStickyMode() {
        assertFalse(GtMapStay55.shouldExitMap(false,1,false))
        assertTrue(GtMapStay55.shouldExitMap(false,2,false))
        assertTrue(GtMapStay55.shouldForgetQuest(false,2))
    }
    @Test fun justDialogueIsNotEvidenceOfLeavingTheMap() {
        val lines=listOf(
            GtAllHud.Line("Hey, I have a surprise for you!",250,520,570,545))
        assertFalse(GtMapStay55.differentScreenEvidence(lines,1536,690))
    }
    @Test fun aDifferentFullScreenCanReleaseTheMapOverlay() {
        val lines=listOf(
            GtAllHud.Line("PAUSED",400,100,550,125),
            GtAllHud.Line("RESUME GAME",400,150,600,178),
            GtAllHud.Line("SETTINGS",400,195,610,220),
            GtAllHud.Line("EXIT TO MAIN MENU",400,250,690,278))
        assertTrue(GtMapStay55.differentScreenEvidence(lines,1536,690))
    }
    @Test fun preferenceIsVisibleAndSavedLive() {
        val xml=File("src/main/res/layout/activity_main.xml").readText()
        val prefs=File("src/main/java/com/example/altyazi/Prefs.kt").readText()
        val activity=File("src/main/java/com/example/altyazi/MainActivity.kt").readText()
        assertTrue(xml.contains("@+id/cbMapKeepVisible"))
        assertTrue(xml.contains("Harita görev çevirisini menüden çıkana kadar göster"))
        assertTrue(prefs.contains("sp.getBoolean(\"mapKeepVisible\", true)"))
        assertTrue(activity.contains("prefs.mapKeepVisible=keep"))
    }
    @Test fun noFrameMustNotEraseStaticMapAndNewSelectionStillInvalidates() {
        val service=File("src/main/java/com/example/altyazi/CaptureService.kt").readText()
        assertTrue(service.contains("if(gtMapPanelMode && !prefs.mapKeepVisible)"))
        assertTrue(service.contains("GtMapStay55.shouldExitMap"))
        assertTrue(service.contains("GtMapStay55.shouldForgetQuest"))
        assertTrue(service.contains("if(gtPanelKeys[slot]!=identity)"))
        assertTrue(service.contains("gtPanelJobs.remove(slot)?.cancel()"))
        assertTrue(service.contains("drawMapDetailPanels()"))
        assertTrue(service.contains("processSubtitle(full) // caption always has priority"))
    }
}
