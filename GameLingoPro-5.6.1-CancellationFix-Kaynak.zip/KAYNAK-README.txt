GameLingoPro 5.6.1 MapFix · Android telefon uygulaması
Paket kimliği com.gamelingo.pro · sürüm kodu 20261231

Proje kökünü Android Studio ile açabilirsiniz. Komut satırı derlemesi için JDK 17, Gradle 8.13, Android SDK Platform 35 ve Build Tools 34.0.0 gerekir.
Uygulama ve test kaynakları app/src dizinindedir. Eski yama betikleri tools altında geçmiş kayıt olarak yer alır. Güncel kaynak doğrudan derlenir.

İmzalama
Mevcut kurulumun üzerine güncelleme üretmek için aynı imza anahtarı gerekir. Yetkili anahtarınızı app/debug.keystore konumuna yerleştirin.
Bağımsız test kurulumu için yeni bir yerel anahtar oluşturabilirsiniz:
keytool -genkeypair -keystore app/debug.keystore -storetype JKS -storepass android -keypass android -alias androiddebugkey -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=Android Debug,O=Android,C=US"

Proje kökünde çalıştırın:
gradle :app:testDebugUnitTest :app:assembleDebug

APK çıktısı:
app/build/outputs/apk/debug/app-debug.apk
