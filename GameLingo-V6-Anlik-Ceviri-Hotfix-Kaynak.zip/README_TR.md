# GameLingo V6 — Anlık çeviri iyileştirme kaynak paketi

Bu paket **Alpha.77'nin güncellenmiş APK'sı değildir**. Alpha.77'nin tam düzenlenebilir kaynak projesi bu oturumda bulunamadığı için APK'yı doğrudan değiştirmedik.

## Yapılan ve test edilen değişiklikler

- 1920 px ve daha geniş altyazı şeritlerinde ilk OCR okumasını en fazla 1440 px genişliğe indirir.
- Arka arkaya üç boş okumadan sonra dördüncü okumayı tam çözünürlükte yaparak küçük yazıların kaybolmasını azaltmayı hedefler.
- Altyazı konum hesaplarını yeni ölçek oranına göre korur.
- Paylaşılan Alpha.77 çalışma kaydındaki kesin OCR ayrılmalarını düzeltir: `tw O plus` → `two plus`; `discus S Something` → `discuss something`.
- Kaynak metin birebir eşleştiğinde `Ya dig?`, `You a trip...`, `Look who's back. What's good?`, `Can you not?` gibi deyimleri doğal Türkçe ile düzeltir.
- Argo/küfür ve konuşmacı adları için genel silme/filtre uygulamaz.
- Mevcut çeviri motoru sırasını ve TV köprüsünü değiştirmez.

## Gerçek sınırlar

- Kotlin mantık testleri geçti. Eski V6 kaynak ağacına yama teknik olarak uygulandı.
- Bu değişikliklerin Pixel 9 Pro'da performans farkı yarattığı **ölçülmedi**.
- Güncel Alpha.77'nin kaynak yapısına **uygulanmadı**. Bu yüzden Alpha.77 için yeni APK yok.
- PS5 bağlantısının yeni kodlarla korunacağını ancak Alpha.77 kaynak projesinden derleyerek doğrulayabiliriz.

## Dizinler

- `v6/realtime/V6RealtimePolicy.kt`: adaptif OCR boyutu.
- `v6/realtime/V6DialogueRepair.kt`: kaynak kontrollü Türkçe düzeltmeler.
- `v6/tools/apply_v6_realtime.py`: eski V6 kaynak tabanı için otomatik uygulama.
- `tests/LiveFix77Test.kt`: Kotlin birim mantık testleri; `kotlinc` ile çalıştırılabilir.

**Önemli:** Alpha.77 uygulamanı silme veya bu kaynak ZIP dosyasını APK sanarak kurmaya çalışma.
