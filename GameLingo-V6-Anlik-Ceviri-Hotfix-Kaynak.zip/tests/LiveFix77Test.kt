package com.example.altyazi.v6

fun main() {
    fun eq(expect: Any, actual: Any) { check(expect == actual) { "Expected <$expect> got <$actual>" } }
    eq(1440, V6RealtimePolicy.targetWidth(1920, 280, 0))
    eq(1920, V6RealtimePolicy.targetWidth(1920, 280, 3))
    eq(1440, V6RealtimePolicy.targetWidth(1920, 280, 4))
    eq(1920, V6RealtimePolicy.targetWidth(1920, 60, 0))
    eq(800, V6RealtimePolicy.targetWidth(800, 240, 0))
    eq(0, V6RealtimePolicy.nextEmptyCount(3,"DJ: Hello"))
    eq(4, V6RealtimePolicy.nextEmptyCount(3," "))
    eq("DJ: Anladın mı? Evet!", V6DialogueRepair.polish("DJ: Ya dig? Yeah!", "DJ: Kazdın mı? Evet!"))
    eq("Stranger: Sen de alemsin.", V6DialogueRepair.polish("Stranger: You a trip...", "Stranger: Sen bir yolculuksun"))
    eq("Lucia: Yapmasan olmaz mı?", V6DialogueRepair.polish("Lucia: Can you not?", "Lucia: Yapamaz mısın?"))
    eq("Jason: Bir saniye.", V6DialogueRepair.polish("Jason: One sec.", "Jason: Bir saniye."))
    eq("What's two plus seven?", V6DialogueRepair.repairInput("What's tw O plus seven?"))
    eq("We need to discuss something.", V6DialogueRepair.repairInput("We need to discus S Something."))
    eq("Lucia: Sen de alemsin.", V6DialogueRepair.polish("Lucia: You a trip.", "Lucia: You a trip.")) // speaker kept, correction below
    println("LIVEFIX77_POLICY_TESTS_PASSED")
}
