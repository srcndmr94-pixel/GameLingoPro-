package com.example.altyazi.v6

/**
 * Chooses an inexpensive first OCR scan for large 1080p/4K subtitle strips.
 * A periodic full-resolution pass keeps small letters from silently disappearing.
 * No fixed delay is introduced before displaying a recognized subtitle.
 */
internal object V6RealtimePolicy {
    const val FAST_MAX_WIDTH = 1440
    const val FULL_RETRY_AFTER_EMPTY_READS = 3

    fun targetWidth(width: Int, height: Int, precedingEmptyReads: Int): Int {
        if (width <= 0 || height <= 0) return width
        // For thin/small letters avoid shrinking, especially on cropped app captures.
        if (width <= FAST_MAX_WIDTH || height < 140) return width
        // Every fourth empty scan is full resolution; a new caption gets a
        // quick fast scan first, then a clear high-resolution safety pass.
        if (precedingEmptyReads >= FULL_RETRY_AFTER_EMPTY_READS &&
            precedingEmptyReads % (FULL_RETRY_AFTER_EMPTY_READS + 1) == FULL_RETRY_AFTER_EMPTY_READS)
            return width
        return FAST_MAX_WIDTH
    }

    fun nextEmptyCount(previous: Int, rawText: String): Int =
        if (rawText.isNotBlank()) 0 else (previous + 1).coerceAtMost(1_000_000)
}
