#!/usr/bin/env python3
"""Experimental low-latency OCR and source-locked dialogue fixes for V6 source.
Requires a *real editable source tree*. Does not patch signed Alpha.77 APK.
Apply after V6 core and stability patches, never to a different source silently.
"""
from pathlib import Path
import shutil
root = Path('.')
service = root/'app/src/main/java/com/example/altyazi/CaptureService.kt'
out = root/'app/src/main/java/com/example/altyazi/v6'
if not service.exists() or 'com.gamelingo.pro.v6stability' not in (root/'app/build.gradle.kts').read_text():
    raise RuntimeError('Expected an editable V6 stability source tree; refusing to alter unknown Alpha.77 code')
out.mkdir(parents=True, exist_ok=True)
for name in ('V6RealtimePolicy.kt','V6DialogueRepair.kt'):
    shutil.copyfile(root/'v6/realtime'/name, out/name)

def change(old, new):
    text = service.read_text(encoding='utf-8')
    n = text.count(old)
    if n!=1:
        raise RuntimeError(f'CaptureService anchor mismatch {n}: {old[:100]}')
    service.write_text(text.replace(old,new,1),encoding='utf-8')

change('''    private suspend fun processSubtitle(full: Bitmap, epoch: Int) {''',
'''    private var v6RecentEmptyOcrReads = 0
    private suspend fun processSubtitle(full: Bitmap, epoch: Int) {''')
change('''        if (band.height < 110) {
            val scaled = Bitmap.createScaledBitmap(band, band.width * 2, band.height * 2, true)
            if (scaled != band) band.recycle()
            band = scaled
        }''',
'''        // Prefer a smaller OCR strip on large 1080p/4K captures.
        // Every fourth empty OCR probes at full resolution to rescue tiny letters.
        // Never apply this resize to the map/HUD scan or original PS5 frame.
        val v6Target = com.example.altyazi.v6.V6RealtimePolicy.targetWidth(
            band.width,band.height,v6RecentEmptyOcrReads)
        if (v6Target in 1 until band.width) {
            val scaledHeight = (band.height.toLong() * v6Target / band.width).toInt().coerceAtLeast(2)
            val scaled = Bitmap.createScaledBitmap(band, v6Target, scaledHeight, true)
            if (scaled !== band) band.recycle()
            band = scaled
        } else if (band.height < 110) {
            val scaled = Bitmap.createScaledBitmap(band,band.width * 2,band.height * 2,true)
            if (scaled !== band) band.recycle()
            band = scaled
        }''')
change('''        ocrBandScale = if (band.height >= (bottom - top) * 2 - 1) 2f else 1f''',
'''        ocrBandScale = band.height.toFloat() / (bottom - top).coerceAtLeast(1)''')
change('''        lastOcrRaw = text
        gtRealtimeLastOcrStartMs''',
'''        lastOcrRaw = text
        v6RecentEmptyOcrReads = com.example.altyazi.v6.V6RealtimePolicy.nextEmptyCount(
            v6RecentEmptyOcrReads,text)
        gtRealtimeLastOcrStartMs''')
change('''                        val rendered = GtOriginalQualityGuard.polish(source, translated)''',
'''                        val rendered = com.example.altyazi.v6.V6DialogueRepair.polish(
                            source, GtOriginalQualityGuard.polish(source,translated))''')
change('''            val prepared = GtOriginalInputGuard.prepare(raw)''',
'''            val prepared = GtOriginalInputGuard.prepare(
                com.example.altyazi.v6.V6DialogueRepair.repairInput(raw))''')

# Explicit regression checks for accidental changes to the PS5 or TV transports.
modified=service.read_text(encoding='utf-8')
assert 'V6RealtimePolicy.targetWidth' in modified
assert 'V6DialogueRepair.polish' in modified
assert 'gtOriginalDialogueDelegate.value.onOcrText' in modified
assert 'PhoneBridgeService' in modified
print('V6 realtime source patch applied; not yet verified on Pixel/PS5 or Alpha.77')
