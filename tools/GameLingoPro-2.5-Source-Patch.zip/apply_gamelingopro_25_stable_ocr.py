#!/usr/bin/env python3
"""GameLingoPro 2.5: correct OCR continuation detection and avoid translating noisy re-reads.

Run after the 2.4 patch against the user's ORIGINAL GameLingoPro Kotlin project.
Preserves all translator engines, settings, package ID, phone bridge and webOS.
"""
from pathlib import Path
import re,sys
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path('.')
src=root/'app/src/main/java/com/example/altyazi'
cap=src/'CaptureService.kt'
ass=src/'ProSubtitleAssembler.kt'
guard=src/'ProTranscriptGuard.kt'
bld=root/'app/build.gradle.kts'
for f in (cap, ass, guard, bld):
    if not f.is_file():raise RuntimeError('Missing '+str(f))
if 'applicationId = "com.gamelingo.pro"' not in bld.read_text():
    raise RuntimeError('Refusing to patch any app other than GameLingoPro')

def once(p, a, b):
    s=p.read_text(encoding='utf8')
    if a not in s or s.count(a)!=1:raise RuntimeError(f'{p.name}: ambiguous patch anchor {a[:90]!r} (count {s.count(a)})')
    p.write_text(s.replace(a,b,1),encoding='utf8')

# Stateful OCR assembler is pure Kotlin so it can be regression tested without Android.
ass.write_text(r'''package com.example.altyazi

import java.util.Locale
import kotlin.math.max

/** Never manufacture missing words; combine only on-screen OCR fragments. */
internal class ProSubtitleAssembler {
    private var last = ""
    private var lastSeenMs = 0L

    fun clear() { last = ""; lastSeenMs = 0L }

    fun accept(raw: String, nowMs: Long): String {
        val next = raw.trim()
        if (next.isEmpty()) {
            if (nowMs - lastSeenMs > 1200L) clear()
            return ""
        }
        if (last.isEmpty() || nowMs < lastSeenMs || nowMs - lastSeenMs > 1800L) {
            last = next; lastSeenMs = nowMs; return next
        }
        val previous = last
        val a = normalized(previous)
        val b = normalized(next)
        when {
            a == b -> {lastSeenMs=nowMs;return previous}
            b.startsWith(a) && b.length>a.length -> {last=next;lastSeenMs=nowMs;return next}
            a.startsWith(b) && a.length>b.length && b.length>=12 -> {
                lastSeenMs=nowMs;return previous
            }
            // Distorted OCR often merges two words: "Go onsoolet merest".
            // Keep the last clean reading only if it shares most letters and
            // the new reading lost at least two word boundaries.
            suspiciousShortReread(previous,next) -> {
                lastSeenMs=nowMs;return previous
            }
            // A continuation is accepted only when the displayed source ends
            // in an open clause AND the next line begins in lowercase. Never
            // merge a new speaker, a menu heading, or a separate objective.
            likelyContinued(previous) && next.firstOrNull()?.isLowerCase()==true &&
                next.length>=10 && !next.contains(':') && !normalized(previous).endsWith(b) -> {
                val joined=previous.trimEnd()+" "+next
                last=joined;lastSeenMs=nowMs;return joined
            }
            a.endsWith(b) && b.length>=18 -> {lastSeenMs=nowMs;return previous}
            else -> {last=next;lastSeenMs=nowMs;return next}
        }
    }

    companion object {
        private fun normalized(s:String)=s.lowercase(Locale.ROOT)
            .replace(Regex("""[^\p{L}\p{N}]+"""), "")
        private fun wordCount(s:String)=s.trim().split(Regex("""\s+""")).count {it.isNotBlank()}

        /** Stable text can end in a conjunction, comma, or unfinished phrase. */
        fun likelyContinued(text:String):Boolean {
            val s=text.trimEnd()
            if(s.length<18 || s.lastOrNull() in listOf('.','!','?','…'))return false
            if(s.lastOrNull() in listOf(',',';',':'))return true
            return Regex("""(?i)\b(?:and|but|while|although|because|with|to|for|if|or|then|now|she's|he's|it's|they're|we're|i'm)\s*$""").containsMatchIn(s)
        }

        /** Prevent a glitched OCR sample from replacing a clean stable one. */
        fun suspiciousShortReread(previous:String,next:String):Boolean {
            if(previous.length<17 || next.length<12 || next.contains(':'))return false
            if(wordCount(previous)-wordCount(next)<2)return false
            val a=normalized(previous);val b=normalized(next)
            if(a.length<12 || b.length<10 || a.take(4)!=b.take(4))return false
            return editDistance(a,b) <= max(3,(max(a.length,b.length)*.29).toInt())
        }

        private fun editDistance(a:String,b:String):Int {
            if(a==b)return 0
            if(a.length>180 || b.length>180)return Int.MAX_VALUE
            var row=IntArray(b.length+1){it}
            for(i in a.indices) {
                val next=IntArray(b.length+1)
                next[0]=i+1
                for(j in b.indices)next[j+1]=minOf(
                    next[j]+1,row[j+1]+1,row[j]+if(a[i]==b[j])0 else 1)
                row=next
            }
            return row[b.length]
        }

        /** Use a longer second crop only when it really extends the same text. */
        fun fuller(first:String,second:String):String {
            val a=first.trim();val b=second.trim()
            if(a.isEmpty())return b
            if(b.length<=a.length+4)return a
            val left=normalized(a);val right=normalized(b)
            if(left.length<12 || right.length<12)return a
            val prefix=left.take(14)
            if(right.startsWith(prefix))return b
            if(editDistance(left.take(22),right.take(22))<=2)return b
            return a
        }
    }
}
''',encoding='utf8')

# The same OCR crop zoomed a second time can NEVER see a subtitle row beyond
# its boundaries. Re-read an expanded vertical region instead; preserve
# the old OCR geometry and never accept an unrelated HUD label as a suffix.
s=cap.read_text(encoding='utf8')
a='''        // Lower line can be faint while upper one ends in a comma. Retry once
        // at a higher scale instead of submitting half the English sentence.
        val ocrNow = android.os.SystemClock.elapsedRealtime()
        if (ProSubtitleAssembler.likelyContinued(text) &&
            band.width < 2700 && ocrNow - lastLongOcrRetryAtMs >= 450L) {
            lastLongOcrRetryAtMs = ocrNow
            val zoom = if (band.width >= 1450) 1.35f else 1.6f
            val scaled = Bitmap.createScaledBitmap(
                band, (band.width * zoom).toInt(), (band.height * zoom).toInt(), true)
            if (scaled !== band) {
                val oldScale = ocrBandScale
                try {
                    ocrBandScale *= zoom
                    text = ProSubtitleAssembler.fuller(text, runOcr(scaled, filterEdges = true))
                } finally {
                    ocrBandScale = oldScale
                    scaled.recycle()
                }
            }
        }
'''
b='''        // IMPORTANT: re-reading the SAME crop at higher scale cannot see a
        // second subtitle line outside its rectangle. Expand vertically.
        // The alternative is accepted only if it genuinely extends the same
        // beginning; an unrelated reward/HUD must not replace the dialogue.
        val ocrNow = android.os.SystemClock.elapsedRealtime()
        val retry = ProSubtitleAssembler.likelyContinued(text) ||
            (text.isBlank() && lastOcrRaw.isNotBlank())
        if (retry && ocrNow - lastLongOcrRetryAtMs >= 600L) {
            lastLongOcrRetryAtMs = ocrNow
            val extraAbove = (full.height * .075f).toInt().coerceAtLeast(24)
            val extraBelow = (full.height * .055f).toInt().coerceAtLeast(16)
            val extendedTop = (top - extraAbove).coerceAtLeast(0)
            val extendedBottom = (bottom + extraBelow).coerceAtMost(full.height)
            if (extendedBottom - extendedTop > bottom - top) {
                val expanded = Bitmap.createBitmap(full, left, extendedTop,
                    right - left, extendedBottom - extendedTop)
                val oldTop = ocrBandTop
                val oldScale = ocrBandScale
                try {
                    ocrBandTop = extendedTop
                    ocrBandScale = 1f
                    val alternate = runOcr(expanded, filterEdges = true)
                    val merged = if (text.isBlank()) {
                        // A blank frame must not turn an unrelated mission or
                        // reward label into dialogue. Recover only the same
                        // previously visible caption, never invent new text.
                        val recovered = ProSubtitleAssembler.fuller(lastOcrRaw, alternate)
                        if (recovered.isNotBlank() && recovered == alternate) recovered else ""
                    } else ProSubtitleAssembler.fuller(text, alternate)
                    if (merged != text && merged.length > text.length)
                        log("OCR UZUN SATIR TAMAMLANDI: ${text.length} → ${merged.length} karakter")
                    text = merged
                } finally {
                    ocrBandTop = oldTop
                    ocrBandScale = oldScale
                    expanded.recycle()
                }
            }
        }
'''
# 2.4 has two equivalent source encodings (local vs. GitHub). Replace the
# bounded OCR retry section structurally, without depending on comment text.
start_marker = "        // Second OCR pass only when the first row clearly ends mid-clause."
if start_marker not in s:
    start_marker = "        // Lower line can be faint while upper one ends in a comma. Retry once"
start=s.find(start_marker)
end=s.find("        sonOcrMs = android.os.SystemClock.elapsedRealtime() - ocrBasi",start)
if start<0 or end<start or s.count("        sonOcrMs = android.os.SystemClock.elapsedRealtime() - ocrBasi")!=1:
    raise RuntimeError("Unexpected GameLingoPro 2.4 OCR retry region")
cap.write_text(s[:start]+b+s[end:],encoding='utf8')

# 2.3 requires a three-word suffix; that suppresses real, shorter second
# clauses. This is invoked only when the entire old normalized text is a
# PREFIX of the new source. Require additional word content (not punctuation).
g=guard.read_text(encoding='utf8')
start=g.find("    fun meaningfulExpansion(")
end=g.find("\n    }",start)
if start<0 or end<start:
    raise RuntimeError("Expected meaningfulExpansion in original GameLingoPro")
end+=len("\n    }")
updated=r'''    fun meaningfulExpansion(incoming: String, older: String): Boolean {
        fun normalized(t: String): String = t.lowercase(java.util.Locale.ROOT)
            .replace(Regex("""[^\p{L}\p{N}]+"""), " ")
            .trim().replace(Regex("""\s+"""), " ")
        val current = normalized(incoming)
        val previous = normalized(older)
        if (previous.length < 20 || current.length < previous.length + 7) return false
        if (!current.startsWith(previous)) return false
        return current.substring(previous.length).count { it.isLetter() } >= 5
    }'''
guard.write_text(g[:start]+updated+g[end:],encoding='utf8')

# Preserve the 2.4 bounded delay for genuinely unfinished rows. The rescan
# happens on a 600-ms throttle, so one stable extra cycle is worthwhile.
once(cap,
     'android.os.SystemClock.elapsedRealtime() - candidateStartedAtMs < 750L) return',
     'android.os.SystemClock.elapsedRealtime() - candidateStartedAtMs < 1000L) return')

# Do not prolong the old subtitle if ML Kit has produced an empty region for
# multiple frames. Blank-frame handling already has its own expiry path; this
# code does not pretend missing subtitles were successfully OCR'd.

s=bld.read_text(encoding='utf8')
s,n=re.subn(r'(?m)^(\s*)versionCode\s*=\s*\d+',r'\g<1>versionCode = 20261126',s,count=1)
if n!=1:raise RuntimeError('versionCode missing')
s,n=re.subn(r'(?m)^(\s*)versionName\s*=\s*"[^"]+"',r'\g<1>versionName = "GameLingoPro-2.5-OCR-Stable"',s,count=1)
if n!=1:raise RuntimeError('versionName missing')
bld.write_text(s,encoding='utf8')
assert 'applicationId = "com.gamelingo.pro"' in bld.read_text()
assert 'expanded.recycle()' in cap.read_text()
assert 'versionCode = 20261126' in bld.read_text()
print('GameLingoPro 2.5: expanded OCR reading, strict source continuation, anti-glitch assembly installed')
