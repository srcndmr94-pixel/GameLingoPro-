package com.example.altyazi

fun main() {
    var passed=0
    fun test(ok:Boolean, name:String) {check(ok){"FAILED: $name"};passed++}
    val assembler=ProSubtitleAssembler()
    val first="A spiritually attuned object like jade may serve as a medium,"
    val second="allowing the flower's memories to resurface."
    val full="$first $second"
    test(assembler.accept(first,1000)==first,"first source")
    test(assembler.accept(first,1100)==first,"repeat")
    test(assembler.accept(second,1400)==full,"lowercase extension")
    test(assembler.accept(second,1500)==full,"short OCR reread keeps whole")
    test(assembler.accept(full,1600)==full,"full OCR stabilizes")
    test(ProSubtitleAssembler.fuller(first,full)==full,"larger recrop")
    test(ProSubtitleAssembler.fuller(first,"Go to Dunk's trailer")==first,"ignore unrelated HUD")
    test(ProSubtitleAssembler.fuller(first,"$first therefore")=="$first therefore","shorter extension")
    test(ProSubtitleAssembler.likelyContinued(first),"comma incomplete")
    test(ProSubtitleAssembler.likelyContinued("That cult woman... now she's"),"trailing she's incomplete")
    test(!ProSubtitleAssembler.likelyContinued(full),"complete sentence")
    test(!ProSubtitleAssembler.likelyContinued("Please... end my suffering."),"full sentence")
    val noisy=ProSubtitleAssembler()
    val clean="Go on... let me rest..."
    test(noisy.accept(clean,2000)==clean,"clean early")
    test(noisy.accept("Go onsoolet merest",2100)==clean,"reject glued OCR")
    test(noisy.accept("Go to Dunk's trailer",2200)=="Go to Dunk's trailer","do not join unrelated goal")
    test(noisy.accept("Lucia: Why?",2300)=="Lucia: Why?","speaker change")
    val speakers=ProSubtitleAssembler()
    test(speakers.accept("Vicki: Come here,",3000)=="Vicki: Come here,","speaker A")
    test(speakers.accept("Lucia: No thanks.",3100)=="Lucia: No thanks.","speaker B")
    test(speakers.accept("new sentence after comma",3150)=="new sentence after comma","no merging after period")
    test(speakers.accept("A totally new subtitle.",6000)=="A totally new subtitle.","time expiry")
    test(speakers.accept("",8000).isEmpty(),"blank expires")
    println("GameLingoPro v2.5: $passed/21 OCR continuation regression scenarios passed")
}
