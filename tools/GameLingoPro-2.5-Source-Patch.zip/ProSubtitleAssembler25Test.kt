package com.example.altyazi

import org.junit.Test
import org.junit.Assert.*

class ProSubtitleAssembler25Test {
    @Test fun fullCaptionsNotClipped() {
        val a = ProSubtitleAssembler()
        val first="A spiritually attuned object like jade may serve as a medium,"
        val continuation="allowing the flower's memories to resurface."
        val whole="$first $continuation"
        assertEquals(first,a.accept(first,1000))
        assertEquals(first,a.accept(first,1100))
        assertEquals(whole,a.accept(continuation,1400))
        assertEquals(whole,a.accept(continuation,1500))
        assertEquals(whole,a.accept(whole,1600))
        assertEquals(whole,ProSubtitleAssembler.fuller(first,whole))
        assertEquals(first,ProSubtitleAssembler.fuller(first,"Go to Dunk's trailer"))
        assertEquals("$first therefore",ProSubtitleAssembler.fuller(first,"$first therefore"))
    }
    @Test fun incompleteAndEmptyCases() {
        assertTrue(ProSubtitleAssembler.likelyContinued("That cult woman... now she's"))
        assertTrue(ProSubtitleAssembler.likelyContinued("A talisman that reduces bleeding and"))
        assertTrue(ProSubtitleAssembler.likelyContinued("She said that,"))
        assertFalse(ProSubtitleAssembler.likelyContinued("Please... end my suffering."))
        assertFalse(ProSubtitleAssembler.likelyContinued("I am leaving!"))
        val a=ProSubtitleAssembler()
        assertEquals("Long subtitle with continuation,",a.accept("Long subtitle with continuation,",2000))
        assertEquals("",a.accept("",2100))
        assertEquals("A new subtitle.",a.accept("A new subtitle.",4400))
    }
    @Test fun noMixedSpeakersOrWrongDialogue() {
        val a=ProSubtitleAssembler()
        assertEquals("Go on... let me rest...",a.accept("Go on... let me rest...",2000))
        assertEquals("Go on... let me rest...",a.accept("Go onsoolet merest",2100))
        assertEquals("Go to Dunk's trailer",a.accept("Go to Dunk's trailer",2200))
        assertEquals("Lucia: Why?",a.accept("Lucia: Why?",2300))
        val b=ProSubtitleAssembler()
        assertEquals("Vicki: Come here,",b.accept("Vicki: Come here,",3000))
        assertEquals("Lucia: No thanks.",b.accept("Lucia: No thanks.",3100))
        assertEquals("new sentence after comma",b.accept("new sentence after comma",3150))
    }
}
