package com.example.altyazi

import java.util.Locale

/**
 * Conservative English OCR normalization and short spoken-idiom repair.
 * No lookup by game title or entire scripted scene; never invent context.
 * Quality repair is independent of the GTX/ML Kit translator ordering.
 */
internal object GtDialogueQuality {
    private val soundOrStage=Regex(
        """(?i)\[(?:[^\]]{1,34}\b(?:music|sighs|groans|""" +
        """crackles|beeps|sparks|swells)\b|sinisterly|high pitched voice)\]\)?\s*""")
    fun removeSceneDirections(raw:String):String =
        raw.replace(soundOrStage,"").trim()
    fun stageOnly(raw:String):Boolean =
        raw.isNotBlank() && removeSceneDirections(raw).isBlank()
    fun repairOcr(raw:String):String {
        var s=raw
        // Spoken speaker tag is *not* translated and should not oscillate.
        s=s.replace(Regex("""(?i)^Dr\s+Bill:"""),"Dr. Bill:")
        s=s.replace(Regex("""(?i)^Dunk\s+(?=Dr\.?\s*Bill[,!])"""),"Dunk: ")
        // Leading capital I is often seen as 1/T on dark game subtitles.
        // Limit repairs to highly specific neighboring English words.
        s=s.replace(Regex("""(?i)(:\s*)1(?=\s*,\s*(?:uh|um)\b)""")) {
            it.groupValues[1]+"I"
        }
        s=s.replace(Regex("""(?i)-[TI](?=\s+forgot\b)"""),"I")
        s=s.replace(Regex("""(?i)\b(?:I1|1I)(?=\s+will\b)"""),"I")
        s=s.replace(Regex("""(?i)\bTm-(?=I'm\b)"""),"")
        s=s.replace(Regex("""(?i)\bYouire\b"""),"You're")
        s=s.replace(Regex("""(?i)\bIll(?=\s+(?:sort|be|call|take)\b)"""),"I'll")
        s=s.replace(Regex("""(?i)\bDont\s+knowe\b"""),"Don't know")
        s=s.replace(Regex("""(?i)(how many\s+)ser\s+[i1l]\s+pts\b""")){
            it.groupValues[1]+"scripts"
        }
        s=s.replace(Regex("""(?i)\bcạn\b"""),"can")
        s=s.replace(Regex("""(?i)\bDřive\b"""),"Drive")
        s=s.replace(Regex("""(?i)\bho\s+[wW]\s+many\b"""),"how many")
        s=s.replace(Regex("""(?i)\bWet(?=,?\s+that's\s+not\s+a\s+problem)"""),"Well")
        // This ungrammatical read-back appeared just after the correct line.
        s=s.replace(Regex("""(?i)\bWe\s+not\s+that\s+covered\b"""),
            "We got that covered")
        return s.replace(Regex("""\s{2,}""")," ").trim()
    }

    fun polish(source:String, translation:String):String {
        val english=repairOcr(source).lowercase(Locale.ROOT)
            .trim().replace(Regex("""\s+""")," ")
        val turkish=translation.trim()
        // English dialogue idioms that GTX translates literally in the
        // recorded session. Only exact short phrases receive fixed rewrites.
        if(english.matches(Regex("""don't sweat[.!…]*""")))
            return "Takma kafana."
        if(english.matches(Regex("""now then[.!…]*""")))
            return "Pekâlâ."
        if(english.matches(Regex("""fine[.!…]*""")) &&
            turkish.equals("İyi.",ignoreCase=true))
            return "Peki."
        if(english.matches(Regex("""whoa,?\s+badass[.!…]*""")))
            return "Vay be, müthiş!"
        val emptyThreat=Regex(
            """or[,.…\s]+([a-z][a-z'-]*) can come back to absolutely nothing[.!…]*""")
            .matchEntire(english)
        if(emptyThreat!=null) {
            val name=source.split(Regex("""\s+"""))
                .firstOrNull { it.equals(emptyThreat.groupValues[1],ignoreCase=true) }
                ?: emptyThreat.groupValues[1]
            return "Yoksa "+name+" döndüğünde ortada hiçbir şey kalmayacak!"
        }
        val yearly=Regex("""got a good (\d+) this year,? sir[.!…]*""")
            .matchEntire(english)
        if(yearly!=null)
            return "Bu yıl tam "+yearly.groupValues[1]+" tane, efendim."
        if(english.matches(Regex("""i wouldn['’]t try that(?:,?\s+my dear)?[.!…]*"""))) {
            return if(english.contains("my dear")) "Yerinde olsam bunu denemezdim, canım."
                else "Yerinde olsam bunu denemezdim."
        }
        if(english.matches(Regex("""she(?:'|’)s pedigree[.!…]*""")))
            return "O safkan."
        if(english.matches(Regex("""any minute!\s*like,?\s*soon-soon[.!…]*""")))
            return "Her an! Çok yakında!"
        if(english.matches(Regex("""i(?:'|’)m out[.!]?\s*what[!?.…]*""")))
            return "Ben bu işte yokum. Ne?"

        var result=turkish
        if(Regex("""\bokay\b""").containsMatchIn(english) &&
           !Regex("""\b(?:babe|baby|honey|darling|sweetheart|love)\b""").containsMatchIn(english)) {
            result=result.replace(Regex("""(?iu)\b(tamam|peki)[,!. ]+"""+
                """(aşkım|sevgilim|canım)\b"""),"$1")
        }
        if(Regex("""\blet me vent\b""").containsMatchIn(english)) {
            result=result.replace(Regex("""(?iu)beni\s+havalandırmam[aı]\s+izin"""),
                "içimi dökmeme izin")
        }
        if(english.contains("pound it"))
            result=result.replace(Regex("""(?i)\bvur onu[.!]?"""),
                "Yumruk tokuşturalım!")
        if(english.contains("make a fucking commercial"))
            result=result.replace(Regex("""(?i)hadi lanet bir reklam yapalım"""),
                "hadi şu lanet reklamı çekelim")
        // Do not add terms of endearment absent from the original.
        if(english.matches(Regex("""okay[.!…]*""")) &&
            result.contains(Regex("""(?i)\b(?:aşkım|sevgilim|canım)\b""")))
            result="Tamam..."
        // Preserve the meaning of "have" vs "bought" in recorded dialogue.
        if(english.contains("i know you got 'em")) {
            result=result.replace(
                Regex("""(?i)\bonları aldığını biliyorum\b"""),
                "Elinde olduklarını biliyorum")
        }
        // "hand jobs" must not become the craft-related "el işi".
        if(english.contains("hand jobs")) {
            result=result.replace(Regex("""(?i)\bel işi yapacaksın\b"""),
                "başkalarını elle tatmin edeceksin")
        }
        if(english.contains("client outreach") && english.contains("in-person"))
            result=result.replace("yüz yüze müşteri desteği",
                "müşterilerle yüz yüze görüşme",ignoreCase=true)

        if(english.contains("spaced out") && english.contains("saw"))
            result=result.replace("tamamen uzaklaştım",
                "aklım başımdan gitti",ignoreCase=true)

        if(english.contains("stoners"))
            result=result.replace(Regex("""(?i)\btaşçı\b"""),
                "ot içen insan")

        if(english.contains("tow your whip")) {
            result=result.replace("Kırbacını çekmelerini sağladım",
                "Arabanı çektirdim",ignoreCase=true)
            if(english.contains("ugly as fuck"))
                result=result.replace("O şey çok çirkindi",
                    "Zaten bok gibiydi",ignoreCase=true)
        }

        if(english.contains("book it to the impound") &&
           (result.contains("Hapishaneye",ignoreCase=true) ||
            result.contains("kayıt ettir",ignoreCase=true)))
            result="Aracın çekildiği otoparka koşmamız lazım!"

        if(english.contains("smoke boat")) {
            result=result.replace("duman teknemiz","ot arabamız",ignoreCase=true)
            result=result.replace("duman teknesini sıcak tellerle çevireceğim",
                "ot arabasına düz kontak yapacağım",ignoreCase=true)
            result=result.replace("duman teknesine tel çekeceğim",
                "ot arabasına düz kontak yapacağım",ignoreCase=true)
        }

        if(english.contains("slinging our shit"))
            result=result.replace("bokumuzu atacağız",
                "malımızı satacağız",ignoreCase=true)

        if(english.contains("pile of bud"))
            result=result.replace("tomurcuk yığını",
                "ot yığını",ignoreCase=true)

        if(english.matches(Regex("""sounds like a plan[.!…]*""")) &&
           result.contains("plana benziyor",ignoreCase=true))
            result="Mantıklıymış."

        return result
    }
}
