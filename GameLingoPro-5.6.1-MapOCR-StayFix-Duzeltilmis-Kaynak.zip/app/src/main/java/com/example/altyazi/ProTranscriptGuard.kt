package com.example.altyazi
import java.util.Locale
/** Conservative source-level OCR fixes, with no API or token calls. */
internal object ProTranscriptGuard {
    private val speaker=Regex("^\\s*(?:\\[([\\p{L} .'-]{2,28})\\]|([\\p{Lu}][\\p{L} .'-]{1,27}):)\\s*")
    private val objective=Regex("(?i)\\s+(?:go to|wait for|pull up next to|drive to|head to|talk to|meet with|return to)\\s+[\\p{L}\\p{N}'’ -]{3,76}\\.?$")
    private fun nameOf(t:String):String? {
        val m=speaker.find(t)?:return null
        return m.groupValues[1].ifBlank{m.groupValues[2]}.trim().lowercase(Locale.ROOT)
            .replace(Regex("\\s+")," ")
    }
    fun speakersCompatible(a:String,b:String):Boolean {
        val x=nameOf(a);val y=nameOf(b)
        return x==null||y==null||x==y
    }
    fun repairOcr(raw:String):String {
        if(raw.isBlank())return raw
        return raw.replace(Regex("(?i)\\bget all Njumpy\\b"),"get all jumpy")
            .replace(Regex("(?i)\\bit'?s fne\\b"),"it's fine")
            .replace(Regex("(?i)\\bA\\.KIA\\."),"A.K.A.")
            .replace(Regex("(?i)\\bwho'?s your triend\\b"),"who's your friend")
            .replace(Regex("(?i)\\bCompličated\\b"),"Complicated")
            .replace(Regex("\\bmy OWn\\b"),"my own")
            .replace(Regex("(?i)\\bMaster[. ]+0 finally\\b"),"Master... I finally")
            .replace(Regex("(?i)\\bIcanthold on any longer\\b"),"I can't hold on any longer")
            .replace(Regex("^\\s*Vickt(?=\\s*:)"),"Vicki")
            .replace(Regex("^\\s*Lucla(?=\\s*:)"),"Lucia")
    }
    /** Never mix a spoken dialogue with a separately displayed game mission. */
    fun separateObjective(source:String):String {
        if(speaker.find(source)==null)return source
        val m=objective.find(source)?:return source
        val before=source.substring(0,m.range.first).trimEnd()
        val spoken=before.substringAfter(':',before).trim()
        if(spoken.length<12||(before.lastOrNull()?.let{it in ".!?…"}!=true))return source
        return before
    }
    /** A NEW trailing clause is not duplicate OCR of its earlier first line. */
    fun meaningfulExpansion(incoming: String, older: String): Boolean {
        fun normalized(t: String): String = t.lowercase(java.util.Locale.ROOT)
            .replace(Regex("""[^\p{L}\p{N}]+"""), " ")
            .trim().replace(Regex("""\s+"""), " ")
        val current = normalized(incoming)
        val previous = normalized(older)
        if (previous.length < 20 || current.length < previous.length + 7) return false
        if (!current.startsWith(previous)) return false
        return current.substring(previous.length).count { it.isLetter() } >= 5
    }

    /** Warn on provable idiom errors; do not fabricate a replacement. */
    fun literalIdiom(source:String,translated:String):Boolean {
        val s=source.lowercase(Locale.ROOT)
        val t=translated.lowercase(Locale.forLanguageTag("tr-TR"))
        return ("brightest bulbs" in s && "ampul" in t) ||
            ("sounds wholesome" in s && "sağlıklı" in t) ||
            ("shady-ass shit" in s && "gölgeli" in t) ||
            ("baby daddy" in s && "baba" !in t) ||
            ("you better not be" in s && "gerektik" in t) ||
            ("deals out of the car wash" in s && "araba yıkama işini" in t) ||
            ("jumpy" in s && "njumpy" in t) ||
            ("get my own place" in s && "own" in t)
    }
}
