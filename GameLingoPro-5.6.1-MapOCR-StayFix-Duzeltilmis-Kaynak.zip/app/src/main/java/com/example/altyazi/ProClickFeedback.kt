package com.example.altyazi

import android.app.Activity
import android.content.Context
import android.graphics.Rect
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.SoundPool
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.EditText
import kotlin.math.abs

/** Independent feedback for GameLingo Pro. Leaves existing click listeners untouched. */
internal class ProClickFeedback(private val activity: Activity) {
    private val audio = activity.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val slop = ViewConfiguration.get(activity).scaledTouchSlop.toFloat()
    private val pool = SoundPool.Builder().setMaxStreams(2).setAudioAttributes(
        AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
    ).build()
    private var clickId = 0
    private var confirmId = 0
    private var clickReady = false
    private var confirmReady = false
    private var tracking = false
    private var x = 0f
    private var y = 0f

    init {
        pool.setOnLoadCompleteListener { _, id, status ->
            if (status == 0) {
                if (id == clickId) clickReady = true
                if (id == confirmId) confirmReady = true
            }
        }
        clickId = pool.load(activity, R.raw.pro_ui_click, 1)
        confirmId = pool.load(activity, R.raw.pro_ui_confirm, 1)
    }

    fun onTouch(e: MotionEvent) {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                x = e.rawX
                y = e.rawY
                tracking = true
            }
            MotionEvent.ACTION_MOVE ->
                if (abs(x-e.rawX)>slop || abs(y-e.rawY)>slop) tracking=false
            MotionEvent.ACTION_CANCEL, MotionEvent.ACTION_POINTER_DOWN -> tracking=false
            MotionEvent.ACTION_UP -> {
                val tap=tracking && abs(x-e.rawX)<=slop && abs(y-e.rawY)<=slop
                tracking=false
                if (!tap || !enabled(activity) ||
                    audio.ringerMode != AudioManager.RINGER_MODE_NORMAL) return
                val target=findClickable(activity.window.decorView,e.rawX.toInt(),e.rawY.toInt()) ?: return
                val confirm=target.id == R.id.btnToggle
                if (confirm && confirmReady) pool.play(confirmId,.28f,.28f,1,0,1f)
                if (!confirm && clickReady) pool.play(clickId,.22f,.22f,1,0,1f)
            }
        }
    }

    private fun findClickable(view: View, x: Int, y: Int): View? {
        if (view.visibility != View.VISIBLE || !view.isEnabled || view.alpha <= 0f) return null
        val rect=Rect()
        if (!view.getGlobalVisibleRect(rect) || !rect.contains(x,y)) return null
        if (view is WebView || view is EditText) return null
        if (view is ViewGroup) for (i in view.childCount-1 downTo 0) {
            val hit=findClickable(view.getChildAt(i),x,y)
            if (hit != null) return hit
        }
        return if (view.isClickable) view else null
    }

    fun release() = pool.release()

    companion object {
        private const val FILE="gamelingo_pro_feedback"
        private const val KEY="button_sounds_enabled"
        fun enabled(c:Context)=c.getSharedPreferences(FILE,Context.MODE_PRIVATE).getBoolean(KEY,true)
        fun save(c:Context,on:Boolean) {
            c.getSharedPreferences(FILE,Context.MODE_PRIVATE).edit().putBoolean(KEY,on).apply()
        }
    }
}
