// SPDX-License-Identifier: AGPL-3.0-only
// GameTranslator v1.8.49 Android source adapted into original GameLingoPro.
package com.example.altyazi
import com.example.altyazi.gtcore.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

internal object GtNativeEngine {
    private val google=GoogleGtxTranslator("en","tr")
    private val offline by lazy { MlKitTranslator("en","tr") }
    @Volatile private var prepared=false
    private val speaker=Regex("""^(?:\[[\p{L} .'-]{2,30}\]|[\p{Lu}][\p{L} .'-]{1,29}:)\s*""")
    fun normalize(raw:String):String {
        val text=GtDialogueQuality.repairOcr(
            OcrNoise.clean(raw).trim().ifEmpty { raw.trim() })
        return text.replace(Regex("""(?i)\bstandśa\b"""),"stands a")
            .replace(Regex("""(?i)\bstands aj\b"""),"stands a")
            .replace(Regex("""(?i)\bshutey\b"""),"shut eye")
            .replace(Regex("""(?i)\bYoune Master\b"""),"Young Master")
            .replace(Regex("""\s+""")," ").trim()
    }
    suspend fun translate(raw:String,unused:FastTranslate?):String? = translateWith(raw,
        { s -> withContext(Dispatchers.IO) { google.translate(s) } },
        { s -> withContext(Dispatchers.IO) {
            if(!prepared) synchronized(offline) { if(!prepared) prepared=offline.prepare(8) }
            if(prepared) offline.translate(s) else null
        } })
    suspend fun translateWith(raw:String,primary:suspend (String)->String?,backup:suspend (String)->String?):String? {
        val clean=GtDialogueQuality.removeSceneDirections(normalize(raw))
        if(clean.isEmpty())return null
        // Keep entire OCR sentence together, even when split across display lines.
        val label=speaker.find(clean)?.value?.trim() ?: ""
        val body=(if(label.isEmpty())clean else clean.drop(label.length).trim())
            .trimStart('-',' ')
        if(body.isEmpty())return null
        val translated=primary(body)?.trim()?.takeIf{usable(body,it)}
            ?:backup(body)?.trim()?.takeIf{usable(body,it)} ?: return null
        val fluent=GtDialogueQuality.polish(body,translated)
        return if(label.isEmpty())fluent else "$label $fluent"
    }
    internal fun usable(source:String,text:String):Boolean {
        if(text.isBlank() || source.equals(text,ignoreCase=true))return false
        if(source.length>45 && Regex("""(?i)\b(?:the|and|when|with|after|before|from|this|that|your)\b""")
            .findAll(text).count()>=3)return false
        return true
    }
}
