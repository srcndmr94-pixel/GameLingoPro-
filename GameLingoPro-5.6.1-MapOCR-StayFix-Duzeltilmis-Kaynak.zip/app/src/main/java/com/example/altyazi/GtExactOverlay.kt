// SPDX-License-Identifier: AGPL-3.0-only
package com.example.altyazi

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView

/**
 * GameTranslator v1.8.49 visual model port.
 * Source: tv/webos/style.css: #subtitle-text and #screen .item;
 *          tv/webos/app.js: setSubtitleText speaker highlighting.
 * No legacy yellow GameLingoPro Overlay window is instantiated.
 * AGPL source attribution in app/src/main/assets/GameTranslator-LICENSE.txt.
 */
class GtExactOverlay(private val context: Context) {
    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var root: FrameLayout? = null
    private var caption: TextView? = null
    private val boxes = ArrayList<TextView>()
    @Volatile private var lastRenderedLabels: List<Overlay.Label> = emptyList()
    private val gtLabelGeneration=java.util.concurrent.atomic.AtomicLong(0L)
    @Volatile private var style = Overlay.Stil()
    private var lastSubtitleValue: String? = null
    private var lastSubtitleTop: Int = 0
    private var lastSubtitleBottom: Int = -1
    private val pink = Color.rgb(255, 119, 175)

    fun setStil(next: Overlay.Stil) {
        style = next
        root?.post {
            caption?.let(::subtitleStyle)
            // Repaint the source rectangles; hudStyle() alone erases masks.
            setLabels(lastRenderedLabels)
            if (!lastSubtitleValue.isNullOrBlank())
                setSubtitle(lastSubtitleValue,lastSubtitleTop,bottomPx=lastSubtitleBottom)
        }
    }
    private fun dp(v:Int):Int=(v * context.resources.displayMetrics.density+0.5f).toInt()
    private fun shape(alpha:Int,radius:Int):GradientDrawable = GradientDrawable().apply {
        cornerRadius=dp(radius).toFloat()
        setColor(Color.argb(alpha.coerceIn(0,255),
            Color.red(style.arkaRenk),Color.green(style.arkaRenk),
            Color.blue(style.arkaRenk)))
    }
    private fun speakerColor(text:String):CharSequence {
        // GameTranslator app.js places only the speaker name in another color.
        val annotated=SpannableString(text)
        val regex=Regex("""(?m)(^|[.!?…]\s+)([\p{Lu}][\p{L}'’.-]*(?: [\p{Lu}][\p{L}'’.-]*){0,2}):(?=\s)""")
        for (match in regex.findAll(text)) {
            val prefix=match.groups[2]?:continue
            annotated.setSpan(ForegroundColorSpan(pink),prefix.range.first,
                (prefix.range.last+2).coerceAtMost(text.length),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        // Game objective example from screenshots: "Linda ile konuş".
        if(!regex.containsMatchIn(text)) {
            val mission=Regex("""^([\p{Lu}][\p{L}'’-]{2,24})\s+(?=ile konuş|ile görüş|ile buluş|ile konuşun)""").find(text)
            if(mission!=null) {
                val name=mission.groups[1]!!
                annotated.setSpan(ForegroundColorSpan(pink),name.range.first,
                    name.range.last+1,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }
        return annotated
    }
    private fun subtitleStyle(tv:TextView) {
        // Native GameTranslator look. No second/legacy yellow overlay.
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP,GtStyleContract.captionSp(style.boyutSp))
        tv.setTextColor(style.yaziRengi)
        tv.typeface=Typeface.create("sans-serif-medium",Typeface.NORMAL)
        tv.gravity=Gravity.CENTER
        tv.setLineSpacing(0f,1.14f)
        tv.setPadding(dp(12),dp(5),dp(12),dp(5))
        tv.maxLines=Int.MAX_VALUE
        tv.ellipsize=null
        tv.background=shape(GtStyleContract.subtitleAlpha(style.arkaAlfa),10)
        if(style.kenarlik)
            tv.setShadowLayer(dp(1).toFloat(),0f,dp(1).toFloat(),Color.BLACK)
        else tv.setShadowLayer(0f,0f,0f,Color.TRANSPARENT)
    }
    private fun hudStyle(tv:TextView) {
        // The same GT renderer and chosen colors/background for all HUD areas.
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP,GtStyleContract.hudSp(style.boyutSp))
        tv.setTextColor(style.yaziRengi)
        tv.typeface=Typeface.create("sans-serif-medium",Typeface.NORMAL)
        tv.gravity=Gravity.CENTER_VERTICAL or Gravity.START
        tv.setLineSpacing(0f,1.13f)
        tv.setPadding(dp(6),dp(3),dp(6),dp(3))
        tv.maxLines=Int.MAX_VALUE
        tv.ellipsize=null
        tv.background=shape(GtStyleContract.hudAlpha(style.arkaAlfa),6)
        if(style.kenarlik)
            tv.setShadowLayer(dp(1).toFloat(),0f,dp(1).toFloat(),Color.BLACK)
        else tv.setShadowLayer(0f,0f,0f,Color.TRANSPARENT)
    }
    fun show() {
        if(root!=null)return
        val frame=FrameLayout(context)
        val sub=TextView(context).apply { visibility=View.GONE }
        subtitleStyle(sub)
        frame.addView(sub,FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,FrameLayout.LayoutParams.WRAP_CONTENT
        ).apply{gravity=Gravity.TOP or Gravity.CENTER_HORIZONTAL})
        val kind=if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val lp=WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,kind,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply{gravity=Gravity.TOP or Gravity.START}
        try {wm.addView(frame,lp);root=frame;caption=sub}
        catch(_:Exception) {root=null;caption=null}
    }
    fun setSubtitle(value:String?,topPx:Int,refined:Boolean=false,draft:Boolean=false,
                    bottomPx:Int=-1,previous:String?=null) {
        lastSubtitleValue=value
        lastSubtitleTop=topPx
        lastSubtitleBottom=bottomPx
        val target=caption?:return
        target.post {
            if(value.isNullOrBlank()) {target.visibility=View.GONE;target.text="";return@post}
            subtitleStyle(target)
            target.setTextColor(style.yaziRengi) // live user-selected color
            target.text=speakerColor(value)
            val w=(root?.width?.takeIf{it>0}?:context.resources.displayMetrics.widthPixels)
            val h=(root?.height?.takeIf{it>0}?:context.resources.displayMetrics.heightPixels)
            val maxW=(w*.82f).toInt().coerceAtLeast(dp(210))
            target.maxWidth=maxW
            target.measure(View.MeasureSpec.makeMeasureSpec(maxW,View.MeasureSpec.AT_MOST),
                View.MeasureSpec.makeMeasureSpec(0,View.MeasureSpec.UNSPECIFIED))
            val textHeight=target.measuredHeight
            val desired=if(bottomPx>=0) bottomPx-textHeight else topPx
            val top=desired.coerceIn(dp(6),(h-textHeight-dp(10)).coerceAtLeast(dp(6)))
            val lp=target.layoutParams as FrameLayout.LayoutParams
            lp.topMargin=top
            val sideMargin=maxOf(dp(8),(w*style.kenarPayYuzde/100f).toInt())
            lp.leftMargin=sideMargin;lp.rightMargin=sideMargin
            target.layoutParams=lp
            target.visibility=View.VISIBLE
            target.alpha=1f
        }
    }
    fun oncekiYaz(value:String?) { /* GT single active caption; no stacked GLP subtitle. */ }
    fun oncekiSoldur(sureMs:Long) { /* Previous GLP caption intentionally removed. */ }
    fun setLabels(labels:List<Overlay.Label>) {
        val snapshot=labels.toList()
        lastRenderedLabels=snapshot
        val generation=gtLabelGeneration.incrementAndGet()
        val container=root?:return
        container.post {
            if(gtLabelGeneration.get()!=generation || root!==container)return@post
            while(boxes.size<labels.size){
                val tv=TextView(context).apply{visibility=View.GONE}
                hudStyle(tv)
                container.addView(tv,FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT).apply{
                    gravity=Gravity.TOP or Gravity.START
                })
                boxes.add(tv)
            }
            val w=container.width.takeIf{it>0}?:context.resources.displayMetrics.widthPixels
            val h=container.height.takeIf{it>0}?:context.resources.displayMetrics.heightPixels
            val density=context.resources.displayMetrics.density
            for(i in boxes.indices) {
                val tv=boxes[i]
                val card=snapshot.getOrNull(i)
                if(card==null || card.text.isBlank()) {
                    tv.visibility=View.GONE
                    continue
                }
                hudStyle(tv)
                tv.gravity=Gravity.TOP or Gravity.START
                if(card.gameNotice) {
                    val light=card.lightNotice
                    // Dark backdrop keeps all user-selected light font colors
                    // readable even when the original game notice was pale.
                    tv.setTextColor(style.yaziRengi)
                    tv.background=GradientDrawable().apply{
                        cornerRadius=dp(3).toFloat()
                        setColor(Color.argb(248,17,24,38))
                    }
                    tv.setShadowLayer(0f,0f,0f,Color.TRANSPARENT)
                    tv.setPadding(dp(2),dp(1),dp(2),dp(1))
                    tv.maxLines=(card.sourceLines+1).coerceIn(1,7)
                    tv.ellipsize=android.text.TextUtils.TruncateAt.END
                } else {
                    tv.setTextColor(style.yaziRengi) // live HUD color
                    tv.setPadding(dp(4),dp(2),dp(4),dp(2))
                }
                tv.setLineSpacing(0f,1.05f)
                tv.text=speakerColor(card.text)
                // IMPORTANT: use OCR frame coordinates relative to the
                // ACTUAL overlay container (avoids landscape/padding offset).
                val useRect=card.fitSourceBox && card.frameWidth>0 && card.frameHeight>0
                val fx=if(useRect)w.toFloat()/card.frameWidth else 1f
                val fy=if(useRect)h.toFloat()/card.frameHeight else 1f
                val sourceX=(card.x*fx).toInt()
                val sourceY=(card.y*fy).toInt()
                val right=((card.rightX?:card.x+dp(96))*fx).toInt()
                val bottom=((card.bottomY?:card.y+dp(23))*fy).toInt()
                val originalWidth=(right-sourceX).coerceAtLeast(dp(22))
                val originalHeight=(bottom-sourceY).coerceAtLeast(dp(11))
                val sourceW=if(useRect)originalWidth.coerceAtMost(w)
                    else GtSourceBox.width(originalWidth,w,dp(8)).coerceAtLeast(dp(38))
                val sourceH=if(useRect)originalHeight.coerceAtMost(h)
                    else (originalHeight+dp(7)).coerceAtLeast(dp(17))
                if(useRect) {
                    // Visual colors only; preserve all original OCR geometry.
                    // Respect selected white/yellow/green/turquoise on all
                    // source-positioned game, mission and objective labels.
                    tv.setTextColor(style.yaziRengi)
                    tv.typeface=Typeface.create("sans-serif-medium",
                        if(card.questHeading)Typeface.BOLD else Typeface.NORMAL)
                    tv.background=GradientDrawable().apply {
                        cornerRadius=dp(1).toFloat()
                        setColor(Color.argb(248,17,24,38)) // readable mask
                        // Background color remains independent of text color.
                    }
                    tv.setPadding(dp(1),0,dp(1),0)
                    tv.setShadowLayer(0f,0f,0f,Color.TRANSPARENT)
                    tv.setLineSpacing(0f,1f)
                    tv.maxLines=card.sourceLines.coerceIn(1,8)+1
                    tv.ellipsize=android.text.TextUtils.TruncateAt.END
                }
                val initialFont=if(useRect)
                    (originalHeight.toFloat()/card.sourceLines.coerceIn(1,8)/1.18f)
                        .coerceIn(dp(6).toFloat(),dp(28).toFloat())
                    else GtSourceBox.fontPx(originalHeight,card.sourceLines,density)
                var fontPx=initialFont
                val minPx=if(useRect)(initialFont*.72f).coerceAtLeast(dp(8).toFloat())
                    else dp(6).toFloat()
                // Allow a little more of the original bordered card area for
                // Turkish (generally longer), but never paint outside screen.
                val displayW=if(useRect)(sourceW+dp(5)).coerceAtMost(w)
                    else sourceW
                val displayH=if(useRect) {
                    val grown=if(card.questHeading)sourceH+dp(3)
                        else (sourceH*1.17f).toInt()+dp(4)
                    grown.coerceAtMost((h-sourceY).coerceAtLeast(dp(12)))
                } else sourceH
                tv.maxWidth=displayW
                for(n in 0 until 65) {
                    tv.setTextSize(TypedValue.COMPLEX_UNIT_PX,fontPx)
                    tv.measure(View.MeasureSpec.makeMeasureSpec(displayW,
                        View.MeasureSpec.EXACTLY),
                        View.MeasureSpec.makeMeasureSpec(0,View.MeasureSpec.UNSPECIFIED))
                    if(tv.measuredHeight<=displayH || fontPx<=minPx)break
                    fontPx=(fontPx-0.5f).coerceAtLeast(minPx)
                }
                val measuredH=if(useRect)displayH else tv.measuredHeight.coerceAtLeast(dp(14))
                val x=(if(useRect)sourceX-dp(2) else sourceX-dp(4))
                    .coerceIn(0,(w-displayW).coerceAtLeast(0))
                val y=(if(useRect)sourceY else sourceY-dp(2))
                    .coerceIn(0,(h-measuredH).coerceAtLeast(0))
                val lp=tv.layoutParams as FrameLayout.LayoutParams
                lp.width=displayW
                lp.height=if(useRect || card.gameNotice)displayH
                    else FrameLayout.LayoutParams.WRAP_CONTENT
                lp.leftMargin=x
                lp.topMargin=y
                lp.rightMargin=0
                tv.layoutParams=lp
                tv.visibility=View.VISIBLE
            }
        }
    }
    fun clearLabels()=setLabels(emptyList())
    fun hide() {
        val frame=root?:return
        try{wm.removeView(frame)}catch(_:Exception){}
        root=null;caption=null;boxes.clear()
        lastRenderedLabels=emptyList()
        gtLabelGeneration.incrementAndGet()
        lastSubtitleValue=null
    }
}
