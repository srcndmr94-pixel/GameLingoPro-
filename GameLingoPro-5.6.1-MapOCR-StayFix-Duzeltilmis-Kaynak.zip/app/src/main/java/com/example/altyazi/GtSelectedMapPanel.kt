package com.example.altyazi
import java.util.Locale

/** Read selected map box paragraphs by their untouched on-screen headers.
 * The header is not overlaid, so its disappearance can clear the translation.
 */
internal object GtSelectedMapPanel {
    data class Panel(val slot:String,val title:String,val body:String,
        val left:Int,val top:Int,val right:Int,val bottom:Int,val rows:Int,
        val titleLeft:Int,val titleTop:Int,val titleRight:Int,val titleBottom:Int) {
        val identity:String get()=slot+"|"+title.lowercase(Locale.ROOT).trim()
    }
    private val tabs=setOf("map","brief","progress")
    fun isMap(lines:List<GtAllHud.Line>,w:Int,h:Int):Boolean {
        if(w<100 || h<100)return false
        val topCount=lines.count {
            it.top.toFloat()/h<.125f &&
            it.text.lowercase(Locale.ROOT).trim() in tabs
        }
        val controls=lines.count { row ->
            row.left.toFloat()/w>.76f && row.top.toFloat()/h>.65f &&
            Regex("(?i)^(?:recenter|2d view|add marker|set destination|exit)\\b")
                .containsMatchIn(row.text.trim())
        }
        val selectedQuest=panels(lines,w,h).isNotEmpty()
        return topCount>=2 || (topCount>=1 && controls>=1) ||
            controls>=3 || (selectedQuest && (topCount>=1 || controls>=1))
    }
    private fun heading(s:String):Boolean {
        val t=s.trim()
        val letters=t.filter{it.isLetter()}
        return t.length in 4..54 && letters.length>=4 &&
            letters.all{it.isUpperCase()} && '.' !in t && ':' !in t &&
            t.lowercase(Locale.ROOT) !in setOf("inventory","features",
                "standard","recenter","set destination","add marker",
                "exit","map","brief","progress","2d view","security")
    }
    private fun inBox(lines:List<GtAllHud.Line>,w:Int,h:Int,slot:String):Panel? {
        val right=slot=="right"
        val minX=if(right).50f else .15f
        val maxX=if(right).60f else .34f
        val minY=if(right).19f else .075f
        val maxY=if(right).66f else .39f
        val titles=lines.filter{ heading(it.text) &&
            it.left.toFloat()/w in minX..maxX &&
            it.top.toFloat()/h in minY..maxY
        }.sortedBy{it.top}
        for(head in titles) {
            val lower=lines.filter { row ->
                row.top>head.bottom &&
                row.top-head.bottom<=h*.30f &&
                row.left>=head.left-w*.025f &&
                row.left<=head.left+w*.055f &&
                row.right<=head.left+w*.295f &&
                row.text.any{it.isLowerCase()} &&
                row.text.trim().length>=5
            }.sortedBy{it.top}
            val rows=ArrayList<GtAllHud.Line>()
            for(line in lower) {
                if(rows.isNotEmpty()) {
                    val gap=line.top-rows.last().bottom
                    if(gap>h*.055f || gap < -h*.04f)break
                }
                rows.add(line)
                if(rows.size>=9)break
            }
            if(rows.isNotEmpty()) {
                val text=rows.joinToString(" "){it.text.trim()}
                if(text.length>=5)return Panel(slot,head.text.trim(),text,
                    rows.minOf{it.left},rows.minOf{it.top},
                    rows.maxOf{it.right},rows.maxOf{it.bottom},rows.size,
                    head.left,head.top,head.right,head.bottom)
            }
            // Body may now be covered by our translation. Keep header visible
            // and track source presence without inserting permanent text.
            return Panel(slot,head.text.trim(),"",head.left,head.bottom+3,
                head.right,head.bottom+22,1,
                head.left,head.top,head.right,head.bottom)
        }
        return null
    }
    fun panels(lines:List<GtAllHud.Line>,w:Int,h:Int):List<Panel> =
        listOfNotNull(inBox(lines,w,h,"right"),inBox(lines,w,h,"left"))

    /** Bottom-centred task instruction is a separate source rectangle. */
    fun objective(lines:List<GtAllHud.Line>,w:Int,h:Int):GtAllHud.Line? {
        if(w<2 || h<2)return null
        val instruction=Regex("(?i)^(?:search|steal|find|reach|follow|go|"+
            "collect|meet|enter|drive|talk to|return|pick up|take|escape|use)\\b")
        return lines.filter { row ->
            val x=(row.left+row.right)*.5f/w
            val y=(row.top+row.bottom)*.5f/h
            x in .22f.. .79f && y in .80f.. .97f &&
                row.text.length in 5..120 &&
                instruction.containsMatchIn(row.text.trim())
        }.maxByOrNull{it.text.length}
    }
}
