package com.example.altyazi

/** Do not translate single-word place/person names on the game map. */
internal object GtMapHeadingPolicy {
    fun shouldTranslate(title:String):Boolean =
        title.trim().split(Regex("\\s+")).count { it.isNotBlank() } >= 2
}
