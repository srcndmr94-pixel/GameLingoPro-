package com.example.altyazi
/** Force re-reading if sampling missed new text on a nearly identical frame. */
internal object GtCaptionScanPolicy54 {
    const val MAX_UNCHANGED_OCR_INTERVAL_MS=420L
    fun shouldRunOcr(signatureUnchanged:Boolean,msSinceLastOcr:Long):Boolean =
        !signatureUnchanged || msSinceLastOcr >= MAX_UNCHANGED_OCR_INTERVAL_MS
}
