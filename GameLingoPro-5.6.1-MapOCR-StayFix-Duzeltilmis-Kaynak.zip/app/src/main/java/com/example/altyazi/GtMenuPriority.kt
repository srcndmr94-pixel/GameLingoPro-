package com.example.altyazi

/** GameTranslator menu priority: focus on the panel the player is reading. */
internal object GtMenuPriority {
    fun score(card:GtAllHud.Card,width:Float,height:Float):Int {
        val w=width.coerceAtLeast(1f)
        val h=height.coerceAtLeast(1f)
        val x=card.left/w
        val y=card.top/h
        val panel=(x in .46f.. .81f && y in .22f.. .73f)
        val mission=(x in .15f.. .40f && y in .08f.. .40f)
        val paragraph=card.sourceLines>=2 || card.text.length>=45
        return (if(panel)1000 else 0) + (if(mission)600 else 0) +
            (if(paragraph)450 else 0) + card.text.length.coerceAtMost(130)
    }
}
