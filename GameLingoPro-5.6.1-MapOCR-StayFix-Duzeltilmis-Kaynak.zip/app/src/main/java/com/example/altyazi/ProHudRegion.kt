package com.example.altyazi

/** Normalized translated box from GameLingoPro's own OCR. */
internal data class ProHudRegion(
    val id: String, val text: String,
    val x: Double, val y: Double, val right: Double, val side: String
)

internal object ProHudRegions {
    fun convert(labels: List<Overlay.Label>, width: Int, height: Int): List<ProHudRegion> {
        if (width < 1 || height < 1) return emptyList()
        var left = 0
        var right = 0
        return labels.asSequence().filter { it.text.isNotBlank() }
            .sortedWith(compareBy<Overlay.Label> { it.y }.thenBy { it.x })
            .mapNotNull { label ->
                val isRight = label.x >= width / 2
                val slot = if (isRight) right++ else left++
                if (slot >= 7) null else {
                    val side = if (isRight) "right" else "left"
                    val x = (label.x.toDouble() / width).coerceIn(0.0,1.0)
                    val y = (label.y.toDouble() / height).coerceIn(0.0,1.0)
                    val last = ((label.rightX ?: label.x).toDouble() / width).coerceIn(x,1.0)
                    ProHudRegion("hud_${side}_${slot}",label.text.trim().take(400),x,y,last,side)
                }
            }.toList()
    }
}
