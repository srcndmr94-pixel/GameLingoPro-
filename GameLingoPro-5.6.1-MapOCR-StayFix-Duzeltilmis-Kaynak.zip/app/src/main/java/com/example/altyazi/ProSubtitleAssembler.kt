package com.example.altyazi

import java.util.Locale
import kotlin.math.max

/** Never manufacture missing words; combine only on-screen OCR fragments. */
internal class ProSubtitleAssembler {
    private var last = ""
    private var lastSeenMs = 0L

    fun clear() { last = ""; lastSeenMs = 0L }

    fun accept(raw: String, nowMs: Long): String {
        val next = raw.trim()
        if (next.isEmpty()) {
            if (nowMs - lastSeenMs > 1200L) clear()
            return ""
        }
        if (last.isEmpty() || nowMs < lastSeenMs || nowMs - lastSeenMs > 1800L) {
            last = next; lastSeenMs = nowMs; return next
        }
        val previous = last
        val a = normalized(previous)
        val b = normalized(next)
        when {
            a == b -> {lastSeenMs=nowMs;return previous}
            b.startsWith(a) && b.length>a.length -> {last=next;lastSeenMs=nowMs;return next}
            a.startsWith(b) && a.length>b.length && b.length>=12 -> {
                lastSeenMs=nowMs;return previous
            }
            // Distorted OCR often merges two words: "Go onsoolet merest".
            // Keep the last clean reading only if it shares most letters and
            // the new reading lost at least two word boundaries.
            suspiciousShortReread(previous,next) -> {
                lastSeenMs=nowMs;return previous
            }
            // A continuation is accepted only when the displayed source ends
            // in an open clause AND the next line begins in lowercase. Never
            // merge a new speaker, a menu heading, or a separate objective.
            likelyContinued(previous) && next.firstOrNull()?.isLowerCase()==true &&
                next.length>=10 && !next.contains(':') && !normalized(previous).endsWith(b) -> {
                val joined=previous.trimEnd()+" "+next
                last=joined;lastSeenMs=nowMs;return joined
            }
            a.endsWith(b) && b.length>=18 -> {lastSeenMs=nowMs;return previous}
            else -> {last=next;lastSeenMs=nowMs;return next}
        }
    }

    companion object {
        private fun normalized(s:String)=s.lowercase(Locale.ROOT)
            .replace(Regex("""[^\p{L}\p{N}]+"""), "")
        private fun wordCount(s:String)=s.trim().split(Regex("""\s+""")).count {it.isNotBlank()}

        /** Stable text can end in a conjunction, comma, or unfinished phrase. */
        fun likelyContinued(text:String):Boolean {
            val s=text.trimEnd()
            if(s.lastOrNull() in listOf('.','!','?','…'))return false
            if(s.lastOrNull() in listOf(',',';',':'))return s.length>=10
            if(s.length<18)return false
            return Regex("""(?i)\b(?:and|but|while|although|because|with|to|for|if|or|then|now|she's|he's|it's|they're|we're|i'm|the|a|an|of|at|in|on|from|by|his|her|their|our|this|that|is|are|were|was|did|do|does|would|could|should|will|has|have)\s*$""").containsMatchIn(s) ||
                (s.length > 68 && Regex("""(?i)\b(?:and|but|or)\s+(?:(?:\p{L}+[ '’]*){1,4})$""").containsMatchIn(s)) ||
                Regex("""(?i)\b(?:and|but)\s+[\p{L}-]*ing\s*$""").containsMatchIn(s)
        }

        /** Prevent a glitched OCR sample from replacing a clean stable one. */
        fun suspiciousShortReread(previous:String,next:String):Boolean {
            if(previous.length<17 || next.length<12 || next.contains(':'))return false
            if(wordCount(previous)-wordCount(next)<1)return false
            val a=normalized(previous);val b=normalized(next)
            if(a.length<12 || b.length<10 || a.take(4)!=b.take(4))return false
            return editDistance(a,b) <= max(3,(max(a.length,b.length)*.29).toInt())
        }

        private fun editDistance(a:String,b:String):Int {
            if(a==b)return 0
            if(a.length>180 || b.length>180)return Int.MAX_VALUE
            var row=IntArray(b.length+1){it}
            for(i in a.indices) {
                val next=IntArray(b.length+1)
                next[0]=i+1
                for(j in b.indices)next[j+1]=minOf(
                    next[j]+1,row[j+1]+1,row[j]+if(a[i]==b[j])0 else 1)
                row=next
            }
            return row[b.length]
        }

        /** Use a longer second crop only when it really extends the same text. */
        fun fuller(first:String,second:String):String {
            val a=first.trim();val b=second.trim()
            if(a.isEmpty())return b
            if(b.length<=a.length+4)return a
            val left=normalized(a);val right=normalized(b)
            if(left.length<12 || right.length<12)return a
            val prefix=left.take(14)
            if(right.startsWith(prefix))return b
            if(editDistance(left.take(22),right.take(22))<=2)return b
            return a
        }
    }
}
