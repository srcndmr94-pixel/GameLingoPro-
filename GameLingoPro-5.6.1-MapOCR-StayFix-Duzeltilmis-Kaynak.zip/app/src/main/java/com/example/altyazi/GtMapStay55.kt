package com.example.altyazi

/** Keep map translations across transient OCR loss, never with a blind TTL. */
internal object GtMapStay55 {
    /** A few missing samples aren't proof that the player left the map. */
    fun shouldExitMap(sticky:Boolean, consecutiveMissing:Int,
                      confidentDifferentScreen:Boolean):Boolean =
        if (sticky) {
            // An OCR failure, even across many scans, is not a map exit.
            // Require both sustained absence and convincing screen evidence.
            consecutiveMissing >= 4 && confidentDifferentScreen
        } else {
            // Optional legacy behaviour: clear after two failed map probes.
            consecutiveMissing >= 2
        }

    fun shouldForgetQuest(sticky:Boolean, consecutiveMissing:Int):Boolean =
        !sticky && consecutiveMissing >= 2

    /** Generic subtitles alone are not evidence of a game-menu transition.
     * A meaningful, unrelated screen has several non-map OCR items.
     */
    fun differentScreenEvidence(lines:List<GtAllHud.Line>,w:Int,h:Int):Boolean {
        if(w<=0 || h<=0 || lines.size<4)return false
        val readable=lines.count { row ->
            row.text.count(Char::isLetter)>=6 &&
                row.text.length in 6..120
        }
        val mapControls=lines.any { line ->
            val s=line.text.trim().lowercase(java.util.Locale.ROOT)
            s in setOf("map","brief","progress") ||
                s.startsWith("recenter") || s.startsWith("set destination") ||
                s.startsWith("2d view")
        }
        return readable>=4 && !mapControls
    }
}
