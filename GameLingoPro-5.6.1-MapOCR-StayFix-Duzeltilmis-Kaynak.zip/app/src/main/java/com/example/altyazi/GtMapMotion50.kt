package com.example.altyazi
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
/** Screen-relative map stability. Treat OCR flicker as the same mission. */
internal object GtMapMotion50 {
    fun near(ax:Int,ay:Int,bx:Int,by:Int,w:Int,h:Int):Boolean =
        abs(ax-bx) <= max(8,(w*.013f).toInt()) &&
        abs(ay-by) <= max(7,(h*.017f).toInt())
    fun newBody(old:String,next:String):Boolean {
        fun tokens(text:String) = Regex("""[\p{L}\p{N}]+""").findAll(text.lowercase(Locale.ROOT))
            .map { it.value }.toList()
        val a=tokens(old)
        val b=tokens(next)
        if(a.size!=b.size)return true
        return a.indices.any { i ->
            val x=a[i]
            val y=b[i]
            // A missing final plural s is common on a noisy paragraph edge.
            x!=y && !(i==a.lastIndex && a.size>=5 && minOf(x.length,y.length)>=4 &&
                (x==y+"s" || y==x+"s"))
        }
    }
    fun needsProbe(changed:Boolean, missing:Int, elapsedMs:Long):Boolean =
        elapsedMs>=8000L || (elapsedMs>=450L && (changed || missing>0))
    fun settled(firstMs:Long,nowMs:Long):Boolean = nowMs-firstMs>=210L
}
