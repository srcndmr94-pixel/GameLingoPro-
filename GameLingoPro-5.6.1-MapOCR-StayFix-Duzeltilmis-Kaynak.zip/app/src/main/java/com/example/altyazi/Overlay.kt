package com.example.altyazi

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView

/**
 * Ekranın üzerine çizilen çeviri katmanı.
 *
 * İki tür yazı var:
 *  - Altyazı kutusu: büyük, ortalı, altyazı şeridinin hemen üstünde durur.
 *  - Küçük etiketler: menü, görev ve tuş yazılarının kendi yanında durur.
 *
 * Böylece farklı yerlerden gelen çeviriler tek kutuda toplanıp birbirine karışmaz.
 */
class Overlay(private val context: Context) {

    data class Label(
        val text: String, val x: Int, val y: Int,
        val rightX: Int? = null, val bottomY: Int? = null,
        val sourceLines: Int = 1,
        val gameNotice: Boolean = false,
        val lightNotice: Boolean = false,
        val frameWidth: Int = 0,
        val frameHeight: Int = 0,
        val fitSourceBox: Boolean = false,
        val questHeading: Boolean = false,
        val questObjective: Boolean = false
    )

    /** Altyazı kutusunun görünümü; ayarlardan geliyor. */
    data class Stil(
        val boyutSp: Float = 18f,
        val yaziRengi: Int = Color.WHITE,
        val arkaAlfa: Int = 190,
        val arkaRenk: Int = Color.BLACK,
        val kenarlik: Boolean = true,
        /** Kutunun ekran kenarlarına uzaklığı, ekran genişliğinin yüzdesi (TV modu: kesilme payı). */
        val kenarPayYuzde: Int = 0,
    )

    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var root: FrameLayout? = null
    private var subtitleView: TextView? = null

    /**
     * Bir önceki repliğin kutusu: hızlı konuşmada yeni satır gelince eski satır
     * silinmez, buraya küçülüp solgunlaşarak çıkar ve bir süre daha okunabilir
     * kalır. Düzeltme geç yetiştiğinde de kaybolmayıp burada görünür.
     */
    private var prevView: TextView? = null
    private val labelViews = ArrayList<TextView>()

    @Volatile
    private var stil = Stil()

    /** Ayarlar değişince çağrılır; kutu anında yeni görünüme geçer. */
    fun setStil(yeni: Stil) {
        stil = yeni
        subtitleView?.post { stiliUygula() }
    }

    private fun stiliUygula() {
        subtitleView?.let { stiliUygula(it, stil.boyutSp) }
        labelViews.forEach { stiliUygula(it, (stil.boyutSp * .90f).coerceIn(14f, 48f)) }
    }

    private fun stiliUygula(t: TextView, boyutSp: Float) {
        // GameTranslator glass box, with real GameLingoPro user-selected settings.
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, boyutSp.coerceIn(12f, 60f))
        t.setTextColor(stil.yaziRengi)
        t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        t.gravity = Gravity.CENTER
        if (stil.kenarlik) t.setShadowLayer(2.5f,0f,1f,Color.BLACK)
        else t.setShadowLayer(0f,0f,0f,Color.TRANSPARENT)
        t.setPadding(dp(10), dp(5), dp(10), dp(5))
        t.maxWidth = (context.resources.displayMetrics.widthPixels * .88f).toInt()
            .coerceAtLeast(dp(180))
        t.maxLines = Int.MAX_VALUE
        t.ellipsize = null
        t.background = GradientDrawable().apply {
            cornerRadius = dp(10).toFloat()
            setColor(Color.argb(stil.arkaAlfa.coerceIn(0,255),
                Color.red(stil.arkaRenk),Color.green(stil.arkaRenk),
                Color.blue(stil.arkaRenk)))
        }
    }

    fun show() {
        if (root != null) return

        val container = FrameLayout(context)

        // Önceki satır ÖNCE eklenir: alttaki (güncel) kutu onun üstüne çizilsin,
        // ikisi bir an çakışırsa güncel satır okunaklı kalsın.
        val prev = makeText(stil.boyutSp * ONCEKI_ORAN, stil.arkaAlfa).apply {
            visibility = View.GONE
            alpha = ONCEKI_SOLUK
        }
        container.addView(
            prev,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL }
        )

        val subtitle = makeText(stil.boyutSp, stil.arkaAlfa).apply { visibility = View.GONE }
        container.addView(
            subtitle,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL }
        )

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
        }

        try {
            wm.addView(container, lp)
            root = container
            subtitleView = subtitle
            prevView = prev
            stiliUygula()
        } catch (_: Throwable) {
        }
    }

    private fun makeText(sizeSp: Float, alpha: Int): TextView = TextView(context).apply {
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
        setShadowLayer(6f, 0f, 2f, Color.BLACK)
        setPadding(dp(10), dp(5), dp(10), dp(5))
        background = GradientDrawable().apply {
            cornerRadius = dp(12).toFloat()
            setColor(Color.argb(alpha, 0, 0, 0))
        }
    }

    /**
     * Altyazı çevirisi. topPx, kutunun ekranın üstünden uzaklığı.
     * [refined]: telefondaki yapay zekânın düzgün çevirisi; aynı repliğin kaba çevirisinin
     * yerine geçer. Kutu daralmaz (zıplamasın), yazı yumuşakça değişir, köşede küçük nokta çıkar.
     */
    /**
     * [bottomPx] >= 0 ise kutunun ALT kenarı bu çizginin üstünde kalır (kutu ne kadar
     * büyük olursa olsun İngilizce altyazının üstüne binmez, okumayı engellemez).
     */
    fun setSubtitle(
        value: String?,
        topPx: Int,
        refined: Boolean = false,
        draft: Boolean = false,
        bottomPx: Int = -1,
        previous: String? = null,
    ) {
        val t = subtitleView ?: return
        t.post {
            if (value.isNullOrBlank()) {
                t.animate().cancel()
                t.alpha = 1f
                t.minWidth = 0
                t.visibility = View.GONE
                t.text = ""
                oncekiGizle()
                return@post
            }
            val lp = t.layoutParams as FrameLayout.LayoutParams
            lp.topMargin = topPx.coerceAtLeast(dp(8))
            val kenar = maxOf(dp(12), context.resources.displayMetrics.widthPixels * stil.kenarPayYuzde / 100)
            lp.leftMargin = kenar
            lp.rightMargin = kenar
            val displayWidth = context.resources.displayMetrics.widthPixels
            t.maxWidth = (displayWidth * .86f).toInt().coerceAtLeast(dp(200))
            t.maxLines = Int.MAX_VALUE
            t.ellipsize = null
            val scale = when {
                value.length > 290 -> .70f
                value.length > 210 -> .78f
                value.length > 145 -> .85f
                value.length > 95 -> .91f
                else -> 1f
            }
            // Real subtitle must honour the chosen size. The old GT 15.5sp
            // override ran AFTER stiliUygula() and silently undid the slider.
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP,
                stil.boyutSp.coerceIn(12f, 60f))
            t.layoutParams = lp

            val wasVisible = t.visibility == View.VISIBLE
            // Aynı repliğin düzeltilmiş hali: kutu en az eski genişliğinde kalsın.
            t.minWidth = if (refined && wasVisible) t.width else 0

            val shown: CharSequence = value
            // NOT: taslak artık GRİYE boyanmıyor. Kullanıcı altyazı rengini kendi
            // seçiyor (ör. sarı); gri taslak o seçimi eziyor ve replik yapay zekâ
            // onaylayınca griden sarıya dönüyordu. Yazı artık hep seçilen renkte;
            // yapay zekânın onayladığı satırı sondaki turkuaz nokta gösteriyor.
            t.text = shown
            if (bottomPx >= 0) {
                val genislik = (context.resources.displayMetrics.widthPixels - lp.leftMargin - lp.rightMargin).coerceAtLeast(dp(80))
                t.measure(
                    View.MeasureSpec.makeMeasureSpec(genislik, View.MeasureSpec.AT_MOST),
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
                )
                lp.topMargin = (bottomPx - t.measuredHeight).coerceAtLeast(dp(8))
                t.layoutParams = lp
            }
            // Kutu ekranın altından taşmasın ("İngilizcenin altında" konumunda alt boşluk dar olabilir).
            val ekranYuk = context.resources.displayMetrics.heightPixels
            if (bottomPx < 0 && lp.topMargin > ekranYuk / 2) {
                val genislik = (context.resources.displayMetrics.widthPixels - lp.leftMargin - lp.rightMargin).coerceAtLeast(dp(80))
                t.measure(
                    View.MeasureSpec.makeMeasureSpec(genislik, View.MeasureSpec.AT_MOST),
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
                )
                val enFazla = ekranYuk - t.measuredHeight - dp(2)
                if (lp.topMargin > enFazla) {
                    lp.topMargin = enFazla.coerceAtLeast(dp(8))
                    t.layoutParams = lp
                }
            }
            t.visibility = View.VISIBLE
            if (wasVisible) {
                // Yumuşak geçiş: yazı aniden değişmesin.
                t.animate().cancel()
                t.alpha = 0.35f
                t.animate().alpha(1f).setDuration(180).start()
            } else {
                t.alpha = 1f
            }
            // Önceki satır, güncel kutunun TAM ÜSTÜNE. Güncel kutunun yeri bu
            // noktada kesinleştiği için aynı geçişte yerleştiriliyor; ayrı bir
            // post ile yapılsaydı iki kutu bir kare üst üste binebilirdi.
            oncekiGizle() // GameTranslator single visible caption
        }
    }

    /**
     * Önceki repliği güncel kutunun üstüne koyar. [altPx] güncel kutunun üst
     * kenarı: önceki satırın ALT kenarı bunun hemen üstünde durur.
     */
    private fun oncekiYerlestir(value: String?, altPx: Int, sol: Int, sag: Int) {
        val p = prevView ?: return
        if (value.isNullOrBlank()) {
            oncekiGizle()
            return
        }
        p.animate().cancel()
        p.text = value
        val lp = p.layoutParams as FrameLayout.LayoutParams
        lp.leftMargin = sol
        lp.rightMargin = sag
        val genislik = (context.resources.displayMetrics.widthPixels - sol - sag).coerceAtLeast(dp(80))
        p.measure(
            View.MeasureSpec.makeMeasureSpec(genislik, View.MeasureSpec.AT_MOST),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val ust = altPx - p.measuredHeight - dp(3)
        // Yukarıda yer yoksa önceki satırı hiç gösterme: ekranın tepesine
        // yapışmış, oyunun üstünü kapatan bir kutu okumayı kolaylaştırmaz.
        if (ust < dp(8)) {
            oncekiGizle()
            return
        }
        lp.topMargin = ust
        p.layoutParams = lp
        p.alpha = ONCEKI_SOLUK
        p.visibility = View.VISIBLE
    }

    /**
     * Yalnız üst sıranın yazısını değiştirir; güncel satıra dokunmaz.
     * Geç gelen düzeltme için: alttaki yazı yerinde kalır, üstteki tazelenir.
     * Güncel satır ekranda değilse tek başına üst sıra gösterilmez.
     */
    fun oncekiYaz(value: String?) {
        // Old stacked GameLingoPro caption disabled in GT mode.
        oncekiGizle()
    }


    /** Önceki satırı solarak kaldırır (çağıran süreyi kendisi tutar). */
    fun oncekiSoldur(sureMs: Long) {
        val p = prevView ?: return
        p.post {
            if (p.visibility != View.VISIBLE) return@post
            p.animate().cancel()
            p.animate().alpha(0f).setDuration(sureMs).withEndAction {
                p.visibility = View.GONE
                p.text = ""
                p.alpha = ONCEKI_SOLUK
            }.start()
        }
    }

    private fun oncekiGizle() {
        val p = prevView ?: return
        p.animate().cancel()
        p.visibility = View.GONE
        p.text = ""
        p.alpha = ONCEKI_SOLUK
    }

    /** Menü, görev ve tuş yazılarının çevirileri; her biri kendi yerinde. */
    fun setLabels(labels: List<Label>) {
        val container = root ?: return
        container.post {
            while (labelViews.size < labels.size) {
                val tv = makeText(13f, 205)
                stiliUygula(tv,(stil.boyutSp*.90f).coerceIn(14f,48f))
                container.addView(
                    tv,
                    FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.WRAP_CONTENT,
                        FrameLayout.LayoutParams.WRAP_CONTENT
                    ).apply { gravity = Gravity.TOP or Gravity.START }
                )
                labelViews.add(tv)
            }

            for (i in labelViews.indices) {
                val tv = labelViews[i]
                val label = labels.getOrNull(i)
                if (label == null) {
                    tv.visibility = View.GONE
                    continue
                }
                val screenWidth = container.width.takeIf { it > 0 } ?: context.resources.displayMetrics.widthPixels
                val screenHeight = container.height.takeIf { it > 0 } ?: context.resources.displayMetrics.heightPixels
                val margin = dp(8)
                stiliUygula(tv,(stil.boyutSp*.90f).coerceIn(14f,48f))
                val rightSide = label.x >= screenWidth / 2
                val maximum = (screenWidth * (if (rightSide) .38f else .43f)).toInt()
                    .coerceAtLeast(dp(140))
                val sourceWidth = ((label.rightX ?: label.x) - label.x).coerceAtLeast(0)
                val sourceHeight = ((label.bottomY ?: label.y) - label.y).coerceAtLeast(0)
                tv.maxWidth = maximum
                tv.minWidth = (sourceWidth + dp(18)).coerceIn(dp(90), maximum)
                tv.minHeight = (sourceHeight + dp(12)).coerceAtLeast(dp(36))
                tv.text = label.text
                tv.measure(View.MeasureSpec.makeMeasureSpec(maximum, View.MeasureSpec.AT_MOST),
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
                val width = tv.measuredWidth.coerceAtLeast(tv.minWidth)
                val height = tv.measuredHeight.coerceAtLeast(tv.minHeight)
                val desiredX = if (rightSide) (label.rightX ?: label.x) - width + dp(4)
                    else label.x - dp(4)
                val lp = tv.layoutParams as FrameLayout.LayoutParams
                lp.leftMargin = desiredX.coerceIn(margin, (screenWidth - width - margin).coerceAtLeast(margin))
                lp.topMargin = (label.y - dp(5)).coerceIn(margin,
                    (screenHeight - height - margin).coerceAtLeast(margin))
                lp.rightMargin = 0
                tv.layoutParams = lp
                tv.visibility = View.VISIBLE
            }
        }
    }

    fun clearLabels() = setLabels(emptyList())

    fun hide() {
        val r = root ?: return
        try {
            wm.removeView(r)
        } catch (_: Throwable) {
        }
        root = null
        subtitleView = null
        prevView = null
        labelViews.clear()
    }

    private fun dp(value: Int): Int =
        (value * context.resources.displayMetrics.density).toInt()

    companion object {
        /** Önceki satırın yazı boyutu, güncel satıra oran. */
        const val ONCEKI_ORAN = 0.78f

        /** Önceki satırın saydamlığı: okunur ama öne çıkmaz. */
        const val ONCEKI_SOLUK = 0.62f
    }
}
