package com.example.altyazi
import java.util.Locale
import kotlin.math.abs

/** OCR geometry for *in-game* SMS and tutorial notices, not Android alerts. */
internal object GtGameNotice {
    data class Notice(
        val kind:String, val title:String, val body:String,
        val left:Int,val top:Int,val right:Int,val bottom:Int,val rows:Int
    ) {
        val identity:String get()=kind+"|"+title.lowercase(Locale.ROOT).trim()
        val isSms:Boolean get()=kind=="sms"
    }
    private val excluded=setOf("map","brief","progress","game","store",
        "settings","inventory","features","standard","recenter",
        "exit","sms","message","messages","subtitle","mission",
        "fifa","güç","guc","power","ps5","playstation","dualsense",
        "system","sistem","notifications","bildirimler")
    // A PlayStation notification can overlay the video frame.  It is not an
    // in-game SMS even when OCR geometry resembles the game's message box.
    private val psShell=Regex(
        """(?i)(?:\bps5\b|\bplaystation\b|\bdualsense\b|""" +
        """\bsisteminiz\b|\bkapatılmaya\b|\bkapatilmaya\b|""" +
        """\bhazırlanıyor\b|\bhazirlaniyor\b|\bwireless controller\b)""")
    private val englishCue=Regex(
        """(?i)\b(?:the|they|them|their|your|you|we|our|he|she|""" +
        """this|that|when|what|where|why|how|can|could|would|should|""" +
        """will|was|were|are|is|have|has|had|with|from|for|in|""" +
        """don't|doesn't|won't|it's|i'm|i'll|me|my|out|take|need|""" +
        """them|some|to|and|be)\b""")
    private fun gameEnglish(text:String):Boolean =
        !psShell.containsMatchIn(text) && englishCue.containsMatchIn(text)
    private fun person(s:String):Boolean {
        val t=s.trim()
        if(t.length !in 3..28 || t.lowercase(Locale.ROOT) in excluded)return false
        if(t.count{it==' '}>2 || !t.first().isUpperCase())return false
        return t.count(Char::isLetter)>=3 &&
            t.all{it.isLetter() || it==' ' || it=='\'' || it=='’'}
    }
    fun find(lines:List<GtAllHud.Line>,w:Int,h:Int,
             activeTitle:String?=null):Notice? {
        if(w<100 || h<100)return null
        val valid=lines.filter{
            it.text.isNotBlank() && it.right>it.left && it.bottom>it.top
        }.sortedWith(compareBy<GtAllHud.Line>{it.top}.thenBy{it.left})
        // Turkish platform UI is not source English, do not overlay/translate.
        if(valid.any{psShell.containsMatchIn(it.text)})return null
        // In-game texts (Moses, Vicki, etc.) show an untouched sender heading
        // followed by one or more English lines in a pop-up at screen side.
        val headers=valid.filter{
            person(it.text) &&
            it.left.toFloat()/w in .025f.. .65f &&
            it.top.toFloat()/h in .34f.. .91f
        }
        for(head in headers) {
            val near=valid.filter{
                it !== head && it.top>head.bottom &&
                it.top-head.bottom<=h*.25f &&
                abs(it.left-head.left)<=w*.16f &&
                it.right.toFloat()/w<=.84f &&
                it.text.length>=11 &&
                it.text.count(Char::isLetter)>=7 &&
                it.text.any(Char::isLowerCase)
            }.sortedBy{it.top}
            val rows=ArrayList<GtAllHud.Line>()
            for(row in near) {
                if(rows.isNotEmpty()) {
                    val previous=rows.last()
                    val gap=row.top-previous.bottom
                    val lineH=(previous.bottom-previous.top).coerceAtLeast(8)
                    if(gap < -lineH/2 || gap > lineH*2.1f)break
                    if(abs(row.left-previous.left)>w*.10f)break
                }
                rows.add(row)
                if(rows.size>=6)break
            }
            val source=rows.joinToString(" "){it.text.trim()}.trim()
            if(source.length>=23 && gameEnglish(source))
                return Notice("sms",head.text.trim(),source,
                rows.minOf{it.left},rows.minOf{it.top},
                rows.maxOf{it.right},rows.maxOf{it.bottom},rows.size)
            // When our translation sits on the English body, the untouched
            // heading is still a valid presence signal for the SAME sender.
            if(activeTitle!=null &&
               activeTitle.equals(head.text.trim(),ignoreCase=true)) {
                return Notice("sms",head.text.trim(),"",
                    head.left,head.bottom+1,head.right,head.bottom+24,1)
            }
        }

        // Ordinary two-line film dialogue must not become a tutorial pop-up.
        // Require a game-control or objective cue, not merely English words.
        val gameplayHint=Regex(
            """(?i)\b(?:weapon|weapons|gun|guns|ammo|ammunition|""" +
            """trunk|inventory|equip|equipped|hold|press|button|""" +
            """controller|mission|objective|quest|map|marker|""" +
            """interact|store|stored|stash|garage|vehicle|vehicles|""" +
            """drive|driving|health|armor|collect|collected|reward|""" +
            """upgrade|upgrades|open the|access the|save your|use your)\b""")
        val candidates=valid.filter{
            it.left.toFloat()/w in .025f.. .46f &&
            it.top.toFloat()/h in .12f.. .70f &&
            it.right.toFloat()/w<.69f &&
            it.text.length>=12 && it.text.any(Char::isLowerCase)
        }
        for(first in candidates) {
            val rows=ArrayList<GtAllHud.Line>()
            rows.add(first)
            for(row in candidates.filter{it.top>first.top}.sortedBy{it.top}) {
                val previous=rows.last()
                val gap=row.top-previous.bottom
                val lineH=(previous.bottom-previous.top).coerceAtLeast(8)
                if(gap>lineH*1.5f || gap < -lineH/2)break
                if(abs(row.left-first.left)>w*.052f)break
                rows.add(row)
                if(rows.size>=5)break
            }
            val text=rows.joinToString(" "){it.text.trim()}.trim()
            if(rows.size>=2 && text.length>=48 && gameEnglish(text) &&
                gameplayHint.containsMatchIn(text))
                return Notice(
                "tip",text,text,
                rows.minOf{it.left},rows.minOf{it.top},
                rows.maxOf{it.right},rows.maxOf{it.bottom},rows.size)
        }
        // Independent lower-right game notification region. Exclude icons,
        // numeric counters, TV/PS5 system shell and ordinary subtitles.
        val right=valid.filter { line ->
            val x=line.left.toFloat()/w
            val y=line.top.toFloat()/h
            val xr=line.right.toFloat()/w
            val t=line.text.trim()
            x in .57f.. .955f && y in .58f.. .955f &&
                xr<=.994f && t.length>=10 &&
                t.count(Char::isLetter)>=8 &&
                t.count(Char::isDigit)*3 < t.length &&
                !psShell.containsMatchIn(t)
        }
        for(first in right) {
            val rows=ArrayList<GtAllHud.Line>()
            rows.add(first)
            for(row in right.filter{it.top>first.top}.sortedBy{it.top}) {
                val previous=rows.last()
                val gap=row.top-previous.bottom
                val lineH=(previous.bottom-previous.top).coerceAtLeast(8)
                if(gap > lineH*1.7f || gap < -lineH/2)break
                if(abs(row.left-first.left)>w*.13f)break
                rows.add(row)
                if(rows.size==5)break
            }
            val body=rows.joinToString(" "){it.text.trim()}
            val gameNoticeCue=Regex(
                """(?i)\b(?:new\s+(?:objective|mission|task)|objective|""" +
                """mission|quest|reward|challenge|completed|unlocked|""" +
                """available|delivered|notification|updated)\b""")
            val taskInstruction=Regex(
                """(?i)^(?:meet|drive|reach|find|collect|take|""" +
                """go to|return to|head to|deliver|locate)\b""")
            // Two video subtitle lines are NOT evidence of a game notice.
            val realGameCue=gameNoticeCue.containsMatchIn(body) ||
                taskInstruction.containsMatchIn(rows.first().text.trim())
            if(w>h && body.length>=25 && realGameCue &&
                !psShell.containsMatchIn(body)) {
                return Notice("corner","Oyun bildirimi",body,
                    rows.minOf{it.left},rows.minOf{it.top},
                    rows.maxOf{it.right},rows.maxOf{it.bottom},rows.size)
            }
        }
        return null
    }
}
