package com.example.altyazi.gtcore
fun interface TextTranslator { fun translate(text: String): String? }
