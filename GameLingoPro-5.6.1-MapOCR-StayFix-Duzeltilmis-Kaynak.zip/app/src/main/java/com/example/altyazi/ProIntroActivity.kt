package com.example.altyazi

import android.app.Activity
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.LinearGradient
import android.graphics.Shader
import android.media.MediaPlayer
import android.os.Bundle
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.MotionEvent
import android.widget.FrameLayout
import android.widget.TextView
import android.graphics.Typeface
import java.util.concurrent.atomic.AtomicBoolean

/** Original neon motion sequence for GameLingo Pro. Skippable, optional music, offline. */
class ProIntroActivity : Activity() {
    private val ended=AtomicBoolean(false)
    private var music:MediaPlayer?=null
    private var clicks:ProClickFeedback?=null
    private val durationMs=5000L
    private val preferences by lazy { getSharedPreferences("gamelingo_pro_intro",MODE_PRIVATE) }
    private val finishIntro=Runnable { enterApplication() }

    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        clicks=ProClickFeedback(this)
        window.decorView.systemUiVisibility=(View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        val root=FrameLayout(this).apply { setBackgroundColor(Color.rgb(2,3,15)) }
        root.addView(Artwork(),FrameLayout.LayoutParams(-1,-1))
        val skip=TextView(this).apply {
            text="ATLA";textSize=13f;setTextColor(Color.WHITE);gravity=Gravity.CENTER
            setBackgroundColor(Color.argb(156,9,22,46))
            setOnClickListener { enterApplication() }
        }
        val sound=TextView(this).apply {
            textSize=20f;setTextColor(Color.WHITE);gravity=Gravity.CENTER
            setBackgroundColor(Color.argb(156,9,22,46))
            text=if(preferences.getBoolean("intro_music",true)) "♫" else "×"
            setOnClickListener {
                val next=!preferences.getBoolean("intro_music",true)
                preferences.edit().putBoolean("intro_music",next).apply()
                text=if(next) "♫" else "×"
                if(next) playAudio() else stopAudio()
            }
        }
        val density=resources.displayMetrics.density
        fun dip(n:Float)=(n*density).toInt()
        root.addView(skip,FrameLayout.LayoutParams(dip(68f),dip(40f),Gravity.TOP or Gravity.END).apply {
            setMargins(0,dip(40f),dip(18f),0)
        })
        root.addView(sound,FrameLayout.LayoutParams(dip(40f),dip(40f),Gravity.TOP or Gravity.START).apply {
            setMargins(dip(18f),dip(40f),0,0)
        })
        setContentView(root)
        playAudio()
        window.decorView.postDelayed(finishIntro,durationMs)
    }
    private fun playAudio() {
        if(ended.get() || !preferences.getBoolean("intro_music",true)) return
        stopAudio()
        try {
            music=MediaPlayer.create(this,R.raw.pro_intro_theme)?.apply {
                isLooping=false;setVolume(.55f,.55f);start()
            }
        } catch (_:Exception) { stopAudio() }
    }
    private fun stopAudio() {
        try {music?.stop()} catch (_:Exception) {}
        try {music?.release()} catch (_:Exception) {}
        music=null
    }
    private fun enterApplication() {
        if(!ended.compareAndSet(false,true)) return
        window.decorView.removeCallbacks(finishIntro)
        stopAudio()
        startActivity(Intent(this,MainActivity::class.java))
        @Suppress("DEPRECATION")
        overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out)
        finish()
    }
    override fun dispatchTouchEvent(ev:MotionEvent):Boolean {
        val consumed=super.dispatchTouchEvent(ev)
        if(consumed) clicks?.onTouch(ev)
        return consumed
    }
    override fun onPause() {stopAudio();super.onPause()}
    override fun onDestroy() {
        window.decorView.removeCallbacks(finishIntro)
        clicks?.release();stopAudio();super.onDestroy()
    }
    private inner class Artwork:View(this@ProIntroActivity) {
        private val began=SystemClock.uptimeMillis()
        private val p=Paint(Paint.ANTI_ALIAS_FLAG)
        private val turquoise=Color.rgb(6,231,244)
        private val violet=Color.rgb(182,54,252)
        init {setLayerType(View.LAYER_TYPE_SOFTWARE,null)}
        private fun neon(c:Canvas,path:Path,color:Int,weight:Float) {
            p.reset();p.isAntiAlias=true;p.style=Paint.Style.STROKE
            p.strokeWidth=weight;p.strokeCap=Paint.Cap.ROUND;p.strokeJoin=Paint.Join.ROUND
            p.color=color;p.setShadowLayer(17f,0f,0f,color)
            c.drawPath(path,p);p.clearShadowLayer()
        }
        private fun title(c:Canvas,value:String,x:Float,y:Float,size:Float,color:Int) {
            p.reset();p.isAntiAlias=true;p.color=color;p.textSize=size
            p.typeface=Typeface.DEFAULT_BOLD
            c.drawText(value,x,y,p)
        }
        override fun onDraw(canvas:Canvas) {
            val t=(SystemClock.uptimeMillis()-began).coerceAtLeast(0)
            canvas.drawColor(Color.rgb(2,3,15))
            canvas.save()
            // Preserve proportions and draw at native display resolution.
            val sc=kotlin.math.min(width/360f,height/800f).coerceAtLeast(.01f)
            canvas.translate((width-360f*sc)/2f,(height-800f*sc)/2f)
            canvas.scale(sc,sc)
            // Continuously animated procedural strokes; no raster slides or bitmap scaling.
            val seconds=t/1000f
            val phase=kotlin.math.sin(seconds*1.35f)
            // Two glowing swooshes reproduce the turquoise-violet opening palette.
            neon(canvas,Path().apply {
                moveTo(32f,240f+phase*18f);cubicTo(115f,145f+phase*22f,252f,192f-phase*19f,328f,68f+phase*28f)
            },turquoise,2.7f)
            neon(canvas,Path().apply {
                moveTo(-30f,716f-phase*12f);cubicTo(121f,578f+phase*23f,204f,716f-phase*16f,391f,552f+phase*26f)
            },violet,3.3f)
            neon(canvas,Path().apply {
                moveTo(-24f,690f+phase*9f);cubicTo(123f,640f-phase*25f,202f,710f+phase*14f,383f,592f-phase*18f)
            },turquoise,1.8f)
            // Small moving glints add subtle motion throughout the intro.
            for(i in 0 until 18) {
                val x=30f+(i*19f+kotlin.math.sin(seconds*1.2f+i)*11f)%300f
                val y=195f+(i*31)%385+kotlin.math.cos(seconds*.75f+i)*17f
                p.reset();p.isAntiAlias=true
                p.color=if(i%3==0)violet else turquoise
                p.alpha=(80+75*(.5f+.5f*kotlin.math.sin(seconds*2f+i))).toInt().coerceIn(0,255)
                canvas.drawCircle(x,y,if(i%4==0)1.5f else .85f,p)
            }
            val stage=when {t<780->0;t<1770->1;t<2950->2;else->3}
            if(stage>=1) {
                val pad=Path().apply {
                    moveTo(133f,320f);cubicTo(119f,309f,108f,319f,105f,332f)
                    lineTo(96f,372f);cubicTo(92f,389f,107f,402f,121f,394f)
                    lineTo(148f,380f);lineTo(209f,380f);lineTo(239f,394f)
                    cubicTo(255f,402f,269f,386f,264f,370f)
                    lineTo(253f,329f);cubicTo(250f,315f,237f,312f,226f,320f)
                    close()
                }
                neon(canvas,pad,turquoise,5f);neon(canvas,pad,violet,1.5f)
                title(canvas,"+",119f,361f,41f,turquoise)
                for ((x,y) in listOf(218f to 342f,238f to 352f,218f to 368f,201f to 352f)) {
                    p.reset();p.isAntiAlias=true;p.color=turquoise
                    p.setShadowLayer(9f,0f,0f,turquoise)
                    canvas.drawCircle(x,y,3.6f,p)
                }
                val bubble=Path().apply {
                    moveTo(196f,270f);lineTo(258f,270f)
                    quadTo(270f,270f,270f,282f);lineTo(269f,309f)
                    quadTo(269f,320f,258f,320f);lineTo(223f,320f)
                    lineTo(203f,333f);lineTo(205f,317f);lineTo(195f,317f)
                    quadTo(186f,317f,187f,306f);lineTo(190f,280f);close()
                }
                neon(canvas,bubble,violet,4.3f);neon(canvas,bubble,turquoise,1.5f)
                title(canvas,"A 文",196f,307f,25f,Color.WHITE)
            }
            if(stage>=2) {
                title(canvas,"GameLingo",72f,455f,34f,Color.WHITE)
                title(canvas,"Pro",259f,455f,34f,turquoise)
            }
            if(t>=1770 && t<4000) {
                p.reset();p.isAntiAlias=true
                p.shader=LinearGradient(91f,0f,267f,0f,turquoise,violet,Shader.TileMode.CLAMP)
                p.setShadowLayer(13f,0f,0f,turquoise)
                val fill=((t-1770)/2100f).coerceIn(0f,1f)
                canvas.drawRoundRect(90f,515f,90f+180f*fill,526f,6f,6f,p)
                p.clearShadowLayer();p.shader=null
                for(i in 0..2) {
                    p.color=if(i==0) turquoise else Color.rgb(21,78,145)
                    canvas.drawCircle(163f+i*17f,549f,3.5f,p)
                }
            }
            canvas.restore()
            if(t<durationMs && !ended.get()) postInvalidateOnAnimation()
        }
    }
}
