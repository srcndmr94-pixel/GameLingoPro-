package com.example.altyazi

import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull

internal object GtObjectiveTranslation {
    suspend fun translate(source: String, request: suspend (String) -> String?,
                          pause: suspend (Long) -> Unit = { delay(it) },
                          timeoutMs: Long = 3500L): String {
        var retryMs = 1000L
        while (true) {
            val result = withTimeoutOrNull(timeoutMs) { request(source) }?.trim()
            if (!result.isNullOrBlank() && !result.equals(source, ignoreCase = true)) return result
            pause(retryMs)
            retryMs = (retryMs * 2).coerceAtMost(8000L)
        }
    }
}
