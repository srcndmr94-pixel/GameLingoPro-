package com.example.altyazi

import java.util.Locale
import kotlin.math.abs

/**
 * Complete game-menu text recognition, separate from live speech subtitles.
 * Keeps all English game labels/paragraphs in their original screen coordinates.
 * Uses only ML Kit OCR lines; does not render game graphics or translate icons.
 */
internal object GtMenuUi {
    private fun norm(s:String):String = s.trim()
        .lowercase(Locale.ROOT).replace(Regex("""\s+""")," ")

    private val nav = setOf("map","brief","progress","game","store",
        "help","photo studio","settings","recenter","set destination",
        "add marker","2d view","security","take value","exit")
    private val direct = mapOf(
        "map" to "Harita", "brief" to "Bilgi", "progress" to "İlerleme",
        "game" to "Oyun", "store" to "Mağaza", "help" to "Yardım",
        "photo studio" to "Fotoğraf Stüdyosu", "settings" to "Ayarlar",
        "recenter" to "Yeniden ortala", "2d view" to "2B görünüm",
        "add marker" to "İşaret ekle", "set destination" to "Hedef belirle",
        "exit" to "Çıkış", "security" to "Güvenlik",
        "take value" to "Ganimet değeri", "low" to "Düşük",
        "medium" to "Orta", "high" to "Yüksek"
    )
    private fun bare(s:String):String=norm(s)
        .replace(Regex("""(?:\s+[lLrR][1-3]|\s+[xXoO]|\s+[○◯●✕□△])+$"""),"")
        .trim()
    fun isGameMenu(lines:List<GtAllHud.Line>):Boolean {
        val labels=lines.map{bare(it.text)}.toSet()
        val sections=labels.count{it in nav}
        val top=lines.count{line->
            val t=norm(line.text)
            t=="map"||t=="brief"||t=="progress"||t=="photo studio"
        }
        val panel=lines.any{
            norm(it.text).contains("take value")||
            norm(it.text).startsWith("security")
        }
        return (sections>=2 && top>=1) || (panel && sections>=1)
    }
    fun knownControl(s:String):Boolean {
        val t=bare(s)
        return t in nav || t in direct || Regex("""(?i)^(?:recenter|2d view|add marker|set destination|exit)\b""").containsMatchIn(t)
    }
    fun localized(s:String):String? {
        val trimmed=s.trim()
        val base=bare(trimmed)
        val translation=direct[base]?:return null
        val suffix=trimmed.substring(base.length).trim()
        return if (suffix.isEmpty()) translation else "$translation $suffix"
    }
    fun keepAsGameName(s:String):Boolean {
        val t=s.trim()
        return t.length>7 && t.length<65 &&
            t.any{it=='-'} &&
            t.all{!it.isLetter() || it.isUpperCase()}
    }
    fun group(
        input:List<GtAllHud.Line>,width:Int,height:Int,subtitleTop:Float
    ):List<GtAllHud.Card> {
        if(width<2||height<2)return emptyList()
        val lines=input.filter{ line ->
            line.text.count(Char::isLetter)>=2 &&
            line.right>line.left && line.bottom>line.top &&
            line.top>=height*.018f && line.bottom<=height*.985f &&
            // Preserve the separate dialogue subtitle recognizer.
            !((line.left+line.right)/2f in width*.33f..width*.67f &&
              (line.top+line.bottom)/2f>=height*subtitleTop &&
              !GtObjectiveLine.matches(line.text))
        }.sortedWith(compareBy<GtAllHud.Line>{it.top}.thenBy{it.left})
        val groups=mutableListOf<MutableList<GtAllHud.Line>>()
        for(line in lines) {
            val isolated=knownControl(line.text) || keepAsGameName(line.text) ||
                (line.text.trim().length<22 && !line.text.contains(","))
            val candidate=if(isolated)null else groups.asReversed().firstOrNull{g->
                val last=g.last()
                val previousText=last.text.trim()
                val lastHeight=(last.bottom-last.top).coerceAtLeast(8)
                val gap=line.top-last.bottom
                val xTolerance=width*.045f
                !knownControl(previousText) && !keepAsGameName(previousText) &&
                previousText.length>=19 &&
                gap>=-lastHeight*.4f && gap<=lastHeight*1.65f &&
                abs(line.left-last.left)<=xTolerance &&
                abs(line.left-g.first().left)<=xTolerance &&
                g.size<7
            }
            if(candidate==null)groups.add(mutableListOf(line))
            else candidate.add(line)
        }
        return groups.mapNotNull{group->
            val text=group.joinToString(" "){it.text.trim()}.trim()
            if(text.length<2 || keepAsGameName(text))null
            else {
                val left=group.minOf{it.left}
                val right=group.maxOf{it.right}
                val top=group.minOf{it.top}
                val bottom=group.maxOf{it.bottom}
                val centerX=(left+right)/2f/width
                val centerY=(top+bottom)/2f/height
                val zone=when {
                    centerX<.34f->"menu-left"
                    centerX>.76f->"menu-right"
                    centerY<.17f->"menu-top"
                    else->"menu-panel"
                }
                GtAllHud.Card(zone,text,left,top,right,bottom,group.size)
            }
        }.take(32)
    }
}
