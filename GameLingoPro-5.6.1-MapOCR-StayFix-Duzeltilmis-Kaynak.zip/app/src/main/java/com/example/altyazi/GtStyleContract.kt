package com.example.altyazi

/** Pure Kotlin GT renderer sizes/alpha, testable without Android. */
internal object GtStyleContract {
    fun captionSp(chosen:Float):Float=chosen.coerceIn(12f,34f)
    fun hudSp(@Suppress("UNUSED_PARAMETER") chosen:Float):Float=12f
    fun subtitleAlpha(chosen:Int):Int=chosen.coerceIn(0,255)
    fun hudAlpha(chosen:Int):Int=if(chosen<=0)0 else
        maxOf(chosen.coerceAtMost(255),222)
}
