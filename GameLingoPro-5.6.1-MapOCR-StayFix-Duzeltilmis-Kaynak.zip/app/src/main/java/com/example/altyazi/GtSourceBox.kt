package com.example.altyazi

/** Exact OCR rectangle based placement; all sizes are SCREEN PIXELS. */
internal object GtSourceBox {
    fun width(source:Int,viewport:Int,padding:Int):Int =
        (source.coerceAtLeast(1)+padding.coerceAtLeast(0))
            .coerceIn(1,(viewport*0.47f).toInt().coerceAtLeast(1))
    fun fontPx(sourceHeight:Int,lines:Int,density:Float):Float {
        val rowPx=sourceHeight.toFloat()/lines.coerceIn(1,8)
        return (rowPx/1.13f).coerceIn(6f*density.coerceAtLeast(1f),
            16f*density.coerceAtLeast(1f))
    }
    fun hold(misses:Int,sinceSeenMs:Long):Boolean =
        misses<2
    fun nearby(ax:Int,ay:Int,bx:Int,by:Int,screenWidth:Int,screenHeight:Int):Boolean =
        kotlin.math.abs(ax-bx)<= (screenWidth*.025f).toInt().coerceAtLeast(10) &&
        kotlin.math.abs(ay-by)<= (screenHeight*.032f).toInt().coerceAtLeast(12)
}

/** Only short unpunctuated game instructions, never full spoken dialogue. */
internal object GtObjectiveLine {
    private val verbs=Regex(
        """(?i)^(?:steal|collect|find|follow|reach|meet|escape|interact with|go to|talk to|head to|drive to|wait for|pick up|return to|take a|use the|enter the|locate)\b"""
    )
    fun matches(raw:String):Boolean {
        val s=raw.trim()
        return s.length in 6..63 && !s.contains(':') && !s.contains('?') &&
            !s.contains('!') && !s.contains('.') && verbs.containsMatchIn(s)
    }
}
