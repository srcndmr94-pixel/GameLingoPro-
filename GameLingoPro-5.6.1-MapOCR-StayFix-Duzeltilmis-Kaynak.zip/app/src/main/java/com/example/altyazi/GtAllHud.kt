// SPDX-License-Identifier: AGPL-3.0-only
package com.example.altyazi

/**
 * Region approach adapted from GameTranslator v1.8.49.
 * Unlike a single subtitle rectangle, game HUD texts can appear in all corners.
 * Pure Kotlin geometry; tested without an Android device.
 */
internal object GtAllHud {
    data class Line(val text:String, val left:Int, val top:Int, val right:Int, val bottom:Int)
    data class Card(val zone:String, val text:String, val left:Int, val top:Int, val right:Int,
                    val bottom:Int, val sourceLines:Int=1)
    private data class MutableCard(
        val zone:String, val rows:MutableList<Line>, var left:Int,
        var top:Int, var right:Int, var bottom:Int
    ) {
        fun asCard():Card = Card(zone,rows.joinToString(" ") { it.text.trim() }.trim(),
            left,top,right,bottom,rows.size)
    }
    fun region(line:Line, width:Int, height:Int, subtitleTop:Float):String? {
        if(width<=0||height<=0||line.bottom<=line.top)return null
        val x=(line.left+line.right).toFloat()/2/width
        val y=(line.top+line.bottom).toFloat()/2/height
        if(y<.065f||y>.985f)return null
        // The middle of the bottom strip belongs to the separate speech subtitle OCR.
        // BUT the left and right lower corners contain mission/inventory notifications.
        if(x>=0.40f && x<=0.60f && y>=subtitleTop &&
            !GtObjectiveLine.matches(line.text))return null
        return when {
            x<=.44f && y>=.69f -> "left-bottom"
            x<=.44f -> "left-top"
            x>=.56f && y>=.69f -> "right-bottom"
            x>=.56f -> "right-top"
            y<subtitleTop -> "center"
            GtObjectiveLine.matches(line.text) -> "center-objective"
            else -> null
        }
    }
    fun group(lines:List<Line>, width:Int, height:Int, subtitleTop:Float):List<Card> {
        val clean=lines.filter{
            it.text.count(Char::isLetter)>=3 &&
            it.right>it.left && it.bottom>it.top &&
            it.text.length<=340 && region(it,width,height,subtitleTop)!=null
        }.sortedWith(compareBy<Line>{it.top}.thenBy{it.left})
        val cards=mutableListOf<MutableCard>()
        for(line in clean) {
            val zone=region(line,width,height,subtitleTop)?:continue
            val heightOfLine=(line.bottom-line.top).coerceAtLeast(10)
            val match=cards.asReversed().firstOrNull { card ->
                if(card.zone!=zone || card.rows.size>=7)return@firstOrNull false
                val previous=card.rows.last()
                val gap=line.top-previous.bottom
                val h=(previous.bottom-previous.top).coerceAtLeast(10)
                val overlap=(minOf(line.right,card.right)-maxOf(line.left,card.left)).coerceAtLeast(0)
                val narrow=minOf(line.right-line.left,card.right-card.left).coerceAtLeast(1)
                val centerA=(line.left+line.right)/2
                val centerB=(card.left+card.right)/2
                gap >= -heightOfLine && gap<=maxOf(h,heightOfLine)*1.9f &&
                  (overlap>=narrow*.22f || kotlin.math.abs(centerA-centerB)<=width*.055f)
            }
            if(match==null)cards.add(MutableCard(zone,mutableListOf(line),
                line.left,line.top,line.right,line.bottom))
            else {
                match.rows.add(line)
                match.left=minOf(match.left,line.left)
                match.top=minOf(match.top,line.top)
                match.right=maxOf(match.right,line.right)
                match.bottom=maxOf(match.bottom,line.bottom)
            }
        }
        return cards.asSequence().map{it.asCard()}
            .filter{it.text.length>=5}
            .sortedWith(compareBy<Card>{it.zone}.thenBy{it.top}.thenBy{it.left})
            .take(6).toList()
    }
}
