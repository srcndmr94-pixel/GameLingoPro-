package com.example.altyazi
import kotlin.math.abs
/** Pure Kotlin fingerprint while translation overlays are temporarily hidden. */
internal object GtMapVisual56 {
    private const val COLS=9
    private const val ROWS=7
    fun fingerprint(width:Int,height:Int,pixel:(Int,Int)->Int):IntArray {
        if(width<100 || height<100)return intArrayOf()
        val out=IntArray(COLS*ROWS)
        for(row in 0 until ROWS) for(col in 0 until COLS) {
            val x=(width*(.14+(col+.5)*.72/COLS)).toInt().coerceIn(0,width-1)
            val y=(height*(.16+(row+.5)*.68/ROWS)).toInt().coerceIn(0,height-1)
            out[row*COLS+col]=pixel(x,y)
        }
        return out
    }
    fun changed(reference:IntArray?,current:IntArray):Boolean {
        if(reference==null || reference.size!=COLS*ROWS || current.size!=reference.size)
            return false
        var changed=0
        var total=0L
        for(i in current.indices) {
            val a=reference[i]
            val b=current[i]
            val diff=abs((a shr 16 and 255)-(b shr 16 and 255)) +
                abs((a shr 8 and 255)-(b shr 8 and 255)) +
                abs((a and 255)-(b and 255))
            total+=diff
            if(diff>=129)changed++
        }
        return changed*100>=current.size*40 && total>=current.size*3L*42L
    }
}
