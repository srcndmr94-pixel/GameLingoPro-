package com.example.altyazi
import org.junit.Assert.*
import org.junit.Test
class GameLingoUi51Test {
 @Test fun appKeepsAllCriticalControlsWhileUsingTwoPages() {
  val xml=java.io.File("src/main/res/layout/activity_main.xml").readText()
  val main=java.io.File("src/main/java/com/example/altyazi/MainActivity.kt").readText()
  for(id in listOf("homePage","settingsPage","btnToggle","tvStatus", "secSettings",
      "ayarMenu","ayarSatir1","ayarSatir2","ayarSatir3","ayarSatir4",
      "ayarSatir5","ayarSatir6","ayarSatir7","ayarSatir8","btnProWebOs",
      "btnProRemote","btnModePhone","btnModeTv","navHistory","navHelp",
      "secRegion","secLook","secAi","secSes","secAdvanced","tvLastTr")) {
   assertTrue("Missing $id",xml.contains("@+id/$id"))
  }
  assertTrue(main.contains("private fun showUiPage(settings:Boolean)"))
  assertTrue(main.contains("showUiPage(false)"))
  assertTrue(main.contains("showUiPage(true)"))
  assertTrue(main.contains("ayarListesineDon()"))
 }
 @Test fun translationServiceAndGTXStillAttached() {
  val cap=java.io.File("src/main/java/com/example/altyazi/CaptureService.kt").readText()
  assertTrue(cap.contains("processSubtitle(full)"))
  assertTrue(cap.contains("processGameNotice(full,noticeProbe)"))
  assertTrue(cap.contains("processMapDetailPanels(full,noticeProbe)"))
  assertFalse(cap.contains("gtQuestBoxesOnly"))
  val engine=java.io.File("src/main/java/com/example/altyazi/GtNativeEngine.kt").readText()
  assertTrue(engine.contains("GoogleGtxTranslator"))
  assertTrue(engine.contains("MlKitTranslator"))
 }
 @Test fun noNeonBannersOrRedundantConnectionHubOnHome() {
  val xml=java.io.File("src/main/res/layout/activity_main.xml").readText()
  assertFalse(xml.contains("GAMELINGO PRO  •  BAĞLANTI MERKEZİ"))
  assertFalse(xml.contains("GAME LINGO PRO  /  BAĞLANTI MERKEZİ"))
  assertTrue(xml.contains("GameLingoPro"))
  assertTrue(xml.contains("BAĞLANTILAR"))
 }
}
