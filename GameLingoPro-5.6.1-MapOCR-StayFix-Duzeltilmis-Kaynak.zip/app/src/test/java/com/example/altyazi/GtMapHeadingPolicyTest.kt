package com.example.altyazi
import org.junit.Assert.*
import org.junit.Test
class GtMapHeadingPolicyTest {
    @Test fun singleWordProperNamesStayUntouched() {
        assertFalse(GtMapHeadingPolicy.shouldTranslate("KELLY"))
        assertFalse(GtMapHeadingPolicy.shouldTranslate("LEONIDA"))
    }
    @Test fun multiwordDescriptionsCanTranslate() {
        assertTrue(GtMapHeadingPolicy.shouldTranslate("EMPOWERED ELECTRONICS"))
        assertTrue(GtMapHeadingPolicy.shouldTranslate("A BETTER YOU"))
    }
}
