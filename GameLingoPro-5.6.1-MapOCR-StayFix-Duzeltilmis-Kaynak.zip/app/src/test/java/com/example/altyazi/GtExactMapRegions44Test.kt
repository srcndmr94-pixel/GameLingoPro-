package com.example.altyazi
import org.junit.Assert.*
import org.junit.Test
class GtExactMapRegions44Test {
    private fun line(t:String,x:Int,y:Int,w:Int=300,h:Int=21)=
        GtAllHud.Line(t,x,y,x+w,y+h)
    @Test fun extractsTitleAndBodyFromBothTaskPanels() {
        val o=listOf(line("STEAL THE CRAWLER FOR MOSES",270,80,295),
            line("Moses wants an '82 Canis Crawler",270,119),
            line("stolen from some clients who didn't",270,145),
            line("pay. It's parked by the old Trader's",270,171))
        val r=listOf(line("STEAL THE CRAWLER FOR MOSES",828,269,304),
            line("Moses wants an '82 Canis Crawler",827,314),
            line("stolen from some clients who didn't",827,343),
            line("pay. It's parked by the old Trader's",827,372))
        val panels=GtSelectedMapPanel.panels(o+r,1536,690)
        assertEquals(2,panels.size)
        assertTrue(panels.any{it.slot=="left" && it.titleTop==80})
        assertTrue(panels.any{it.slot=="right" && it.titleTop==269})
        assertTrue(panels.all{it.body.contains("Moses")})
    }
    @Test fun bottomMissionSearchTextHasItsOwnRect() {
        val one=line("Search the area for the '82 Crawler",625,639,385)
        val result=GtSelectedMapPanel.objective(listOf(one),1536,690)
        assertNotNull(result)
        assertEquals(one.left,result!!.left)
        assertEquals(one.bottom,result.bottom)
    }
    @Test fun neverTreatTopMapTabAsBottomObjective() {
        assertNull(GtSelectedMapPanel.objective(listOf(line("MAP",735,28)),1536,690))
    }
    @Test fun labelsUseCaptureFrameNotGuessedPhoneScreenWidth() {
        val view=java.io.File("src/main/java/com/example/altyazi/GtExactOverlay.kt").readText()
        val service=java.io.File("src/main/java/com/example/altyazi/CaptureService.kt").readText()
        // The capture frame is the source of truth; never guessed phone metrics.
        assertTrue(view.contains("card.frameWidth>0 && card.frameHeight>0"))
        assertTrue(view.contains("w.toFloat()/card.frameWidth"))
        assertTrue(view.contains("h.toFloat()/card.frameHeight"))
        assertTrue(view.contains("val displayW=if(useRect)"))
        assertTrue(view.contains("val displayH=if(useRect)"))
        assertTrue(view.contains("lp.width=displayW"))
        assertTrue(view.contains("if(useRect || card.gameNotice)displayH"))
        assertTrue(service.contains("frameWidth=width,frameHeight=height,fitSourceBox=true"))
    }
}