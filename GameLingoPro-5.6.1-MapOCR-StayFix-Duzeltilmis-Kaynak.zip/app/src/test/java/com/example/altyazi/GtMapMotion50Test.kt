package com.example.altyazi
import org.junit.Assert.*
import org.junit.Test
class GtMapMotion50Test {
    @Test fun tinyOcrJitterIsIgnoredAndMovingCardsAreNot() {
        assertTrue(GtMapMotion50.near(840,252,846,257,1536,690))
        assertFalse(GtMapMotion50.near(840,252,970,300,1536,690))
        assertFalse(GtMapMotion50.settled(100L,245L))
        assertTrue(GtMapMotion50.settled(100L,310L))
    }
    @Test fun newlySelectedTextWithSameHeaderInvalidatesOldBody() {
        assertFalse(GtMapMotion50.newBody(
            "Nightclub with luxury hospitality and beautiful views.",
            "Nightclub with luxury hospitality and beautiful view"))
        assertTrue(GtMapMotion50.newBody(
            "Nightclub with luxury hospitality and beautiful views.",
            "Take the car to the dock and meet the gang outside"))
    }
    @Test fun liveSelectionUsesMapStabilityButKeepsAllTranslations() {
        val s=java.io.File("src/main/java/com/example/altyazi/CaptureService.kt").readText()
        assertTrue(s.contains("gtPanelSources[slot]=source"))
        assertTrue(s.contains("gtPanelPendingSince[slot]=nowMap"))
        assertTrue(s.contains("HARİTA METNİ DEĞİŞTİ"))
        assertTrue(s.contains("processSubtitle(full)"))
        assertTrue(s.contains("processGameNotice(full,noticeProbe)"))
        assertFalse(s.contains("gtQuestBoxesOnly"))
    }
}
