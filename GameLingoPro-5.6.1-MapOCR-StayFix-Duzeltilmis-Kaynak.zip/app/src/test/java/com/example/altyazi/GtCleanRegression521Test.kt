package com.example.altyazi
import org.junit.Assert.*
import org.junit.Test

class GtCleanRegression521Test {
    private fun line(t:String,x:Int,y:Int,w:Int=375)=
        GtAllHud.Line(t,x,y,x+w,y+24)

    @Test fun videoSubtitleWithTwoLinesNeverBecomesGameNotification() {
        assertNull(GtGameNotice.find(listOf(
            line("I don't care what you want anymore.",1050,540),
            line("You can just leave me alone!",1050,575)),1536,690))
        assertNull(GtGameNotice.find(listOf(
            line("What can you give me for this?",1050,540),
            line("I really need your help here.",1050,575)),1536,690))
    }
    @Test fun realMissionNoticeAndInstructionAreStillDetected() {
        val mission=GtGameNotice.find(listOf(
            line("New objective available",1040,545,310),
            line("Meet your contact at the docks.",1040,574,335)),1536,690)
        assertEquals("corner",mission!!.kind)
        val oneLine=GtGameNotice.find(listOf(
            line("Drive to the office slowly.",1080,550,330)),1536,690)
        assertEquals("corner",oneLine!!.kind)
    }
    @Test fun consoleAlertsAreIgnoredWhileNamedGameMessagesWork() {
        assertNull(GtGameNotice.find(listOf(
            line("PS5 sisteminiz kapatilmaya hazırlanıyor.",1020,540,410)),1536,690))
        val message=GtGameNotice.find(listOf(
            line("Moses",316,487,160),
            line("Clients stiffed me when it",220,539,350),
            line("was time to pay up. Trashed",219,571,350),
            line("my shop, too. They wanna...",222,603,350)),1536,690)
        assertEquals("Moses",message!!.title)
    }
    @Test fun selectedColorKeepsSourceAlignedBackdrop() {
        val renderer=java.io.File("src/main/java/com/example/altyazi/GtExactOverlay.kt").readText()
        assertTrue(renderer.contains("setLabels(lastRenderedLabels)"))
        assertTrue(renderer.contains("lastRenderedLabels=snapshot"))
        assertTrue(renderer.contains("val card=snapshot.getOrNull(i)"))
        assertTrue(renderer.contains("tv.setTextColor(style.yaziRengi)"))
        assertTrue(renderer.contains("Color.argb(248,17,24,38)"))
        assertFalse(renderer.contains("boxes.forEach(::hudStyle)"))
    }
    @Test fun allTranslationRegionsAndPreviousCleanUiRemainEnabled() {
        val service=java.io.File("src/main/java/com/example/altyazi/CaptureService.kt").readText()
        val activity=java.io.File("src/main/java/com/example/altyazi/MainActivity.kt").readText()
        assertTrue(service.contains("processSubtitle(full)"))
        assertTrue(service.contains("processGameNotice(full,noticeProbe)"))
        assertTrue(service.contains("processMapDetailPanels(full,noticeProbe)"))
        assertTrue(service.contains("SubtitleStyle.yaziRengi(prefs.subtitleColor)"))
        assertTrue(activity.contains("private fun showUiPage(settings:Boolean)"))
        assertFalse(service.contains("gtQuestBoxesOnly"))
    }
}
