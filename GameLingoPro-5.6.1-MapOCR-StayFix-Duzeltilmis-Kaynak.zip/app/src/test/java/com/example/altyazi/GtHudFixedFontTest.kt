package com.example.altyazi
import org.junit.Assert.*
import org.junit.Test

class GtHudFixedFontTest {
    @Test fun everyGameHudCardUsesFixedSmallFont() {
        for (subtitleSize in listOf(12f, 16f, 20f, 28f, 34f, 60f)) {
            assertEquals(12f, GtStyleContract.hudSp(subtitleSize), .0001f)
        }
    }
    @Test fun bottomSubtitleKeepsSelectedSize() {
        assertEquals(14f, GtStyleContract.captionSp(14f), .0001f)
        assertEquals(28f, GtStyleContract.captionSp(28f), .0001f)
        assertEquals(34f, GtStyleContract.captionSp(60f), .0001f)
    }
    @Test fun liveRendererUsesIndependentContracts() {
        val code=java.io.File("src/main/java/com/example/altyazi/GtExactOverlay.kt").readText()
        val hud=code.substringAfter("private fun hudStyle(tv:TextView)")
            .substringBefore("fun show()")
        val subtitle=code.substringAfter("private fun subtitleStyle(tv:TextView)")
            .substringBefore("private fun hudStyle(tv:TextView)")
        assertTrue(hud.contains("GtStyleContract.hudSp(style.boyutSp)"))
        assertFalse(hud.contains("GtStyleContract.captionSp(style.boyutSp)"))
        assertTrue(subtitle.contains("GtStyleContract.captionSp(style.boyutSp)"))
        assertTrue(hud.contains("tv.setTextColor(style.yaziRengi)"))
    }
    @Test fun singleRendererStillActive() {
        val c=java.io.File("src/main/java/com/example/altyazi/CaptureService.kt").readText()
        assertTrue(c.contains("overlay = GtExactOverlay(this)"))
        assertFalse(c.contains("overlay = Overlay(this)"))
    }
}
