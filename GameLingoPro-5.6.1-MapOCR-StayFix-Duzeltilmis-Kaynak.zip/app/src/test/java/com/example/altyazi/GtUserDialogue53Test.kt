package com.example.altyazi
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import java.io.File

class GtUserDialogue53Test {
    @Test fun pureSoundScenesDoNotUseTranslationEngines()=runBlocking {
        var api=0
        for(raw in listOf("[ominous music]","[grand music swells]",
          "[camera crackles] [haunting music]")) {
            assertNull(GtNativeEngine.translateWith(raw,
              { api++; "hatali" },{ api++; "yedek" }))
        }
        assertEquals(0,api)
    }
    @Test fun stageDirectionsRemovedButSpeakerNameRetained()=runBlocking {
        var body=""
        val out=GtNativeEngine.translateWith(
            "[camera beeps] [Adam] --When you take her out for the fifth time",
            { body=it; "Onu beşinci kez dışarı çıkardığında" },
            {"yedek"})
        assertEquals("When you take her out for the fifth time",body)
        assertEquals("[Adam] Onu beşinci kez dışarı çıkardığında",out)
        assertEquals("Fine.",
            GtDialogueQuality.removeSceneDirections("[Vaggie sighs]) Fine."))
    }
    @Test fun naturalTurkishAgainstExactUserLogErrors() {
        assertEquals("Vay be, müthiş!",
            GtDialogueQuality.polish("Whoa, Badass!","Vay, Baş belası!"))
        assertEquals("Harika iş, tehlikeli memeler! Yumruk tokuşturalım!",
            GtDialogueQuality.polish("Awesome job, danger tits! Pound it.",
            "Harika iş, tehlikeli memeler! Vur onu."))
        assertEquals("Pekâlâ.",
            GtDialogueQuality.polish("Now then.","Şimdi o zaman."))
        assertEquals("Yoksa Charlie döndüğünde ortada hiçbir şey kalmayacak!",
            GtDialogueQuality.polish(
            "Or... Charlie can come back to absolutely nothing!",
            "Veya... Charlie kesinlikle hiçbir şeye geri dönebilir!"))
        assertEquals("Bu yıl tam 275 tane, efendim.",
            GtDialogueQuality.polish("Got a good 275 this year, sir.",
            "Bu yıl iyi bir 275 aldım efendim."))
    }
    @Test fun ocrRepairsNarrowAndNegationPreserved() {
        assertEquals("Lute, how many demons did you kill this year?",
            GtDialogueQuality.repairOcr("Lute, ho W many demons did you kill this year?"))
        assertEquals("Ohh! Well, that's not a problem! We got that covered.",
            GtDialogueQuality.repairOcr(
            "Ohh! Wet, that's not a problem! We not that covered."))
        assertEquals("We are not buying it.",
            GtDialogueQuality.repairOcr("We are not buying it."))
    }
    @Test fun allPriorRegionsAndNewBrandStillEnabled() {
        val ui=File("src/main/res/layout/activity_main.xml").readText()
        val c=File("src/main/java/com/example/altyazi/CaptureService.kt").readText()
        assertTrue(ui.contains("GAMELINGOPRO · ALTYAZI ALANLARI"))
        assertTrue(c.contains("processSubtitle(full)"))
        assertTrue(c.contains("processGameNotice(full,noticeProbe)"))
        assertTrue(c.contains("processMapDetailPanels(full,noticeProbe)"))
        assertFalse(c.contains("gtQuestBoxesOnly"))
    }
}
