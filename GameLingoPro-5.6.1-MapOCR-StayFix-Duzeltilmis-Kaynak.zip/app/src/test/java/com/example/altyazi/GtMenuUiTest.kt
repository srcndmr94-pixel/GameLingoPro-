package com.example.altyazi
import org.junit.Assert.*
import org.junit.Test
class GtMenuUiTest {
    private fun line(t:String,x:Int,y:Int,w:Int=190):GtAllHud.Line =
        GtAllHud.Line(t,x,y,x+w,y+22)

    @Test fun detectsTheMapMenuFromRealScreenshotLabels() {
        val rows=listOf(line("JASON & LUCIA",580,25),line("MAP",750,25),
            line("BRIEF",820,25),line("PROGRESS",940,25),
            line("TACO BOMB - GELLHORN",812,259))
        assertTrue(GtMenuUi.isGameMenu(rows))
    }
    @Test fun joinsDescriptionButNotTheStoreName() {
        val rows=listOf(line("MAP",730,25),
            line("BRIEF",820,25),line("PROGRESS",950,25),
            line("TACO BOMB - GELLHORN",815,250),
            line("Fast-food chain popular for its Mexican-",825,285,310),
            line("inspired culinary creations, with dine-in",825,309,310),
            line("and drive-thru options.",825,333,310),
            line("SECURITY",827,371),line("LOW",1090,371))
        val cards=GtMenuUi.group(rows,1536,690,.74f)
        val paragraph=cards.firstOrNull {it.text.startsWith("Fast-food")}
        assertNotNull(paragraph)
        assertTrue(paragraph!!.text.endsWith("drive-thru options."))
        assertFalse(cards.any {it.text.startsWith("TACO BOMB")})
    }
    @Test fun leftMenuAndRightButtonsAreIndependent() {
        val rows=listOf(line("Map",183,142),line("Game",183,187),
            line("Store",183,231),line("Settings",183,361),
            line("RECENTER L3",1232,522),line("SET DESTINATION X",1217,612))
        val out=GtMenuUi.group(rows,1536,690,.74f)
        assertEquals(6,out.size)
        assertTrue(out.any{it.text=="Settings"})
        assertTrue(out.any{it.text.startsWith("RECENTER")})
    }
    @Test fun translationOfKnownMenuItemsPreservesButton() {
        assertEquals("Harita",GtMenuUi.localized("Map"))
        assertEquals("Hedef belirle X",GtMenuUi.localized("SET DESTINATION X"))
    }
    @Test fun lowerCenterSpeechStaysInSubtitlePipeline() {
        val row=line("Don't translate this spoken subtitle again",600,628,370)
        assertTrue(GtMenuUi.group(listOf(row),1536,690,.75f).isEmpty())
    }
}
