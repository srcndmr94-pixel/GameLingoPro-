package com.example.altyazi
import org.junit.Assert.*
import org.junit.Test
import kotlinx.coroutines.runBlocking
class GtNativeEngineTest {
 @Test fun fixesObservedOCR() {
  val s=GtNativeEngine.normalize("At the center standśa Three-Eyed Puppet. The tightly shutey on its forehead.")
  assertTrue(s.contains("stands a Three-Eyed Puppet"));assertTrue(s.contains("shut eye"))
 }
 @Test fun preservesLongClauseAndFallsBack()=runBlocking {
  val input="At the center stands a Three-Eyed Puppet. The tightly shut eye on its forehead seems different."
  val sent=mutableListOf<String>()
  GtNativeEngine.translateWith(input,{sent.add(it);null},{"Ortada üç gözlü kukla duruyor."})
  assertEquals(1,sent.size);assertEquals(input,sent[0])
 }
}
