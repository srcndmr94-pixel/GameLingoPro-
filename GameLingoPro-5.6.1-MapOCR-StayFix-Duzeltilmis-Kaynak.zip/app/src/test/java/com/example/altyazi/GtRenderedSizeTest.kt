package com.example.altyazi
import org.junit.Assert.*
import org.junit.Test
class GtRenderedSizeTest {
  private val overlay by lazy {
    java.io.File("src/main/java/com/example/altyazi/Overlay.kt").readText()
  }
  @Test fun noHardcodedSmallSubtitleSizes() {
    assertFalse(overlay.contains("val gtSize"))
    assertFalse(overlay.contains("15.5f"))
    assertTrue(overlay.contains("stil.boyutSp.coerceIn(12f, 60f)"))
    assertTrue(overlay.contains("t.setTextColor(stil.yaziRengi)"))
    assertTrue(overlay.contains("Color.red(stil.arkaRenk)"))
  }
  @Test fun everyHudCardReadsSelectedSize() {
    assertTrue(overlay.contains("stil.boyutSp * .90f"))
    assertTrue(overlay.contains("stil.boyutSp*.90f"))
  }
}
