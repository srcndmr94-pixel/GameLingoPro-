package com.example.altyazi
import org.junit.Assert.*
import org.junit.Test

class GtUserColor52Test {
    @Test fun selectedColorActuallyReachesCaptionAndEveryTranslatedHudLabel() {
        val ui=java.io.File("src/main/java/com/example/altyazi/MainActivity.kt").readText()
        val renderer=java.io.File("src/main/java/com/example/altyazi/GtExactOverlay.kt").readText()
        val prefs=java.io.File("src/main/java/com/example/altyazi/CaptureService.kt").readText()
        assertTrue(ui.contains("prefs.subtitleColor=when(cgSubColor.checkedChipId)"))
        assertTrue(ui.contains("tvPreview.setTextColor(SubtitleStyle.yaziRengi(renkSecim))"))
        assertTrue(renderer.contains("target.setTextColor(style.yaziRengi)"))
        assertTrue(renderer.contains("tv.setTextColor(style.yaziRengi)"))
        assertFalse(renderer.contains("Color.rgb(111,235,244)"))
        assertFalse(renderer.contains("Color.rgb(105,232,242)"))
        assertTrue(prefs.contains("SubtitleStyle.yaziRengi(prefs.subtitleColor)"))
    }
    @Test fun subtitleAfterOrientationChangeNotMisclassifiedAsSingleLineNotice() {
        val speech=GtGameNotice.find(listOf(
            GtAllHud.Line("Or... Charlie can come back to absolutely nothing!",
                650,1400,920,1440)), 960,2142)
        assertNull(speech)
        val single=GtGameNotice.find(listOf(
            GtAllHud.Line("Or... Charlie can come back to absolutely nothing!",
                1040,580,1450,605)), 1536,690)
        assertNull(single)
    }
    @Test fun genuineGameMissionNoticeStillDetected() {
        val notice=GtGameNotice.find(listOf(
            GtAllHud.Line("New objective available",1040,545,1350,570),
            GtAllHud.Line("Meet your contact at the docks.",1040,574,1370,600)),
            1536,690)
        assertNotNull(notice)
        assertEquals("corner",notice!!.kind)
    }
    @Test fun naturalSpokenWarningDoesNotSwitchSubject() {
        assertEquals("Yerinde olsam bunu denemezdim, canım.",
            GtDialogueQuality.polish("I wouldn't try that my dear.",
                "Bunu denemeyeceğim canım."))
    }
    @Test fun allTranslationCategoriesAndStyledUiAreStillActive() {
        val capture=java.io.File("src/main/java/com/example/altyazi/CaptureService.kt").readText()
        val ui=java.io.File("src/main/java/com/example/altyazi/MainActivity.kt").readText()
        assertTrue(capture.contains("processSubtitle(full)"))
        assertTrue(capture.contains("processGameNotice(full,noticeProbe)"))
        assertTrue(capture.contains("processMapDetailPanels(full,noticeProbe)"))
        assertTrue(ui.contains("private fun showUiPage(settings:Boolean)"))
        assertFalse(capture.contains("gtQuestBoxesOnly"))
    }
}
