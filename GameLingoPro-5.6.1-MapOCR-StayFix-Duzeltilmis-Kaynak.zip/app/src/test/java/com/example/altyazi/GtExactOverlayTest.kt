package com.example.altyazi
import org.junit.Assert.*
import org.junit.Test
class GtExactOverlayTest {
 @Test fun noLegacyYellowLayerIsCreated() {
   val code=java.io.File("src/main/java/com/example/altyazi/CaptureService.kt").readText()
   assertTrue(code.contains("overlay = GtExactOverlay(this)"))
   assertFalse(code.contains("overlay = Overlay(this)"))
 }
 @Test fun twoDifferentGtStylesAreUsed() {
   val code=java.io.File("src/main/java/com/example/altyazi/GtExactOverlay.kt").readText()
   assertTrue(code.contains("GtStyleContract.subtitleAlpha(style.arkaAlfa)"))
   assertTrue(code.contains("GtStyleContract.hudAlpha(style.arkaAlfa)"))
   assertTrue(code.contains("SpannableString"))
   assertFalse(code.contains("ONCEKI_ORAN"))
 }
 @Test fun userSelectionsArePreserved() {
   val prefs=java.io.File("src/main/java/com/example/altyazi/Prefs.kt").readText()
   assertFalse(prefs.contains("gtExactRendererV30Reset"))
 }
}
