package com.example.altyazi
import org.junit.Assert.*
import org.junit.Test

class GtSelectedMapPanelTest {
    private fun line(t:String,x:Int,y:Int,w:Int=240,h:Int=19) =
        GtAllHud.Line(t,x,y,x+w,y+h)
    private val tabs=listOf(line("MAP",730,20),line("BRIEF",800,20),
        line("PROGRESS",890,20))
    @Test fun selectedPawnGunBoxOnly() {
        val screen=tabs+listOf(
            line("PAWN & GUN - PORT GELLHORN",825,280,300,22),
            line("Ammu-Nation distributor that stocks",827,321,308,21),
            line("guns, mods, ammo, and equipment.",827,346,310,21),
            line("INVENTORY",826,384,130),line("STANDARD",1070,384,115))
        assertTrue(GtSelectedMapPanel.isMap(screen,1536,690))
        val panel=GtSelectedMapPanel.panels(screen,1536,690).first()
        assertEquals("right",panel.slot)
        assertEquals("PAWN & GUN - PORT GELLHORN",panel.title)
        assertEquals("Ammu-Nation distributor that stocks guns, mods, ammo, and equipment.",panel.body)
        assertEquals(2,panel.rows)
    }
    @Test fun titleRemainsReadableWhenTranslatedBodyCoversEnglish() {
        val rows=tabs+listOf(line("NINE1NINE",826,285,160),
            line("FEATURES",826,405,115))
        val panel=GtSelectedMapPanel.panels(rows,1536,690).first()
        assertEquals("NINE1NINE",panel.title)
        assertEquals("",panel.body)
    }
    @Test fun unrelatedMapNamesDoNotChangeSelectedBoxIdentity() {
        val one=GtSelectedMapPanel.panels(tabs+listOf(
            line("RIDEOUT CUSTOMS",826,250,250),
            line("Mod shop known for custom rims",826,297,310)),1536,690)
        val two=GtSelectedMapPanel.panels(tabs+listOf(
            line("RIDEOUT CUSTOMS",826,250,250),
            line("Mod shop known for custom rims",826,297,310),
            line("Catalan Island",1260,400)),1536,690)
        assertEquals(one.first().identity,two.first().identity)
    }
    @Test fun gameplayWithoutMapDoesNotCreateBoxOverlay() {
        assertFalse(GtSelectedMapPanel.isMap(
            listOf(line("STEAL A VEHICLE",730,530)),1536,690))
    }
}
