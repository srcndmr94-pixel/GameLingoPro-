package com.example.altyazi
import org.junit.Assert.*
import org.junit.Test
import kotlinx.coroutines.runBlocking
class GtDialogueQuality48Test {
    @Test fun ocrMisreadIAndScriptAreRepairedBeforeDedup() {
        assertEquals("Dr. Bill: I, uh, I don't have any change.",
            GtDialogueQuality.repairOcr("Dr Bill: 1, uh, I don't have any change."))
        assertEquals("Dr. Bill: Hey, uh, I forgot my wallet.",
            GtDialogueQuality.repairOcr("Dr. Bill: Hey, uh, -T forgot my wallet."))
        assertEquals("Dunk: Dr. Bill, it's Dunk. How many scripts you write for me?",
            GtDialogueQuality.repairOcr(
                "Dunk Dr. Bill, it's Dunk. How many ser I pts you write for me?"))
        assertEquals("Dr. Bill: I'm-I'm here to see Declan.",
            GtDialogueQuality.repairOcr("Dr Bill: Tm-I'm-I'm here to see Declan."))
        assertEquals("I'll sort this whole thing out.",
            GtDialogueQuality.repairOcr("Ill sort this whole thing out."))
    }
    @Test fun fixesRecordedDialogueIdiomsWithoutRewritingUnrelatedSentences() {
        assertEquals("Takma kafana.",GtDialogueQuality.polish("Don't sweat.","Terleme."))
        assertEquals("O safkan.",GtDialogueQuality.polish("She's pedigree.","O bir soyağacı."))
        assertEquals("Ben bu işte yokum. Ne?",
            GtDialogueQuality.polish("I'm out. What?","Ben dışarıdayım. Ne?"))
        assertEquals("Tamam...",GtDialogueQuality.polish("Okay...","Tamam aşkım..."))
        assertEquals("Hızlıca terlemeden gel.",GtDialogueQuality.polish(
            "Run without sweat!","Hızlıca terlemeden gel."))
        assertEquals("Elinde olduklarını biliyorum.",GtDialogueQuality.polish(
            "I know you got 'em","Onları aldığını biliyorum."))
    }
    @Test fun noTokenCostAndSpeakerTagPreserved()= runBlocking {
        var calls=0
        val result=GtNativeEngine.translateWith("Dunk: Don't sweat.",
            { calls++; "Terleme." }, { "Yedek." })
        assertEquals("Dunk: Takma kafana.",result)
        assertEquals(1,calls)
    }
    @Test fun originalUserColorsHudAndEnginesAreNotTouched() {
        val capture=java.io.File("src/main/java/com/example/altyazi/CaptureService.kt").readText()
        val render=java.io.File("src/main/java/com/example/altyazi/GtExactOverlay.kt").readText()
        val engine=java.io.File("src/main/java/com/example/altyazi/GtNativeEngine.kt").readText()
        assertTrue(capture.contains("processSubtitle(full)"))
        assertTrue(capture.contains("processGameNotice(full,noticeProbe)"))
        assertTrue(capture.contains("processMapDetailPanels(full,noticeProbe)"))
        assertFalse(capture.contains("gtQuestBoxesOnly"))
        assertTrue(render.contains("if(card.questHeading)Typeface.BOLD else Typeface.NORMAL"))
        assertTrue(render.contains("tv.setTextColor(style.yaziRengi)"))
        assertTrue(engine.contains("GoogleGtxTranslator"))
        assertTrue(engine.contains("MlKitTranslator"))
    }
}
