package com.example.altyazi
import org.junit.Assert.*
import org.junit.Test
class GtActualAppearanceTest {
    @Test fun preferenceFieldsRemainLive() {
        val source = java.io.File("src/main/java/com/example/altyazi/Overlay.kt").readText()
        assertTrue(source.contains("t.setTextColor(stil.yaziRengi)"))
        assertTrue(source.contains("boyutSp.coerceIn(12f, 60f)"))
        assertTrue(source.contains("Color.red(stil.arkaRenk)"))
        assertTrue(source.contains("stiliUygula(tv,(stil.boyutSp*.90f)"))
        assertFalse(source.contains("val compactSize = if (landscape)"))
    }
    @Test fun settingsStillBindToService() {
        val source = java.io.File("src/main/java/com/example/altyazi/CaptureService.kt").readText()
        assertTrue(source.contains("yaziRengi = SubtitleStyle.yaziRengi(prefs.subtitleColor)"))
        assertTrue(source.contains("boyutSp = if (tv)"))
        assertTrue(source.contains("lastGTStyle"))
    }
}
