package com.example.altyazi

import org.junit.Assert.*
import org.junit.Test
import java.io.File

class GtBrandIdentity522Test {
    @Test fun applicationScreenHasOnlyGameLingoProBrand() {
        val xml=File("src/main/res/layout/activity_main.xml").readText()
        assertTrue(xml.contains("GAMELINGOPRO · ALTYAZI ALANLARI"))
        assertTrue(xml.contains("GameLingoPro otomatik tarama"))
        assertTrue(xml.contains("GameLingoPro · yazı rengi"))
        assertTrue(xml.contains("GameLingoPro · koyu arka plan"))
        assertFalse(xml.contains("GAMETRANSLATOR ALANLARI"))
        assertFalse(xml.contains("GameTranslator otomatik tarama"))
        assertFalse(xml.contains("GameTranslator ·"))
    }
    @Test fun otherUserFacingLabelsAgreeWithProductName() {
        val activity=File("src/main/java/com/example/altyazi/MainActivity.kt").readText()
        val service=File("src/main/java/com/example/altyazi/CaptureService.kt").readText()
        val strings=File("src/main/res/values/strings.xml").readText()
        assertTrue(strings.contains("<string name=\"app_name\">GameLingoPro</string>"))
        assertTrue(activity.contains("cbGoogle.text=\"GameLingoPro · Google GTX"))
        assertTrue(service.contains("GameLingoPro çalışıyor…"))
    }
    @Test fun licensedEngineProvenanceIsPreserved() {
        assertTrue(File("src/main/assets/GameTranslator-LICENSE.txt").exists())
        assertTrue(File("src/main/assets/GameTranslator-NOTICE.txt").exists())
        val source=File("src/main/java/com/example/altyazi/GtNativeEngine.kt").readText()
        assertTrue(source.contains("GameTranslator v1.8.49"))
        val service=File("src/main/java/com/example/altyazi/CaptureService.kt").readText()
        assertTrue(service.contains("Google GTX → ML Kit"))
        assertTrue(service.contains("processSubtitle(full)"))
        assertTrue(service.contains("processMapDetailPanels(full"))
    }
}
