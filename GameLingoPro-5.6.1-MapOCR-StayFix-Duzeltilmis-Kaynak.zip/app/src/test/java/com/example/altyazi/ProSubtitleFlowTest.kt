package com.example.altyazi
import org.junit.Assert.*
import org.junit.Test
class ProSubtitleFlowTest {
    @Test fun detectsTruncatedSentences() {
        assertTrue(ProSubtitleAssembler.likelyContinued("The map points to the northern mountains... and so did the"))
        assertTrue(ProSubtitleAssembler.likelyContinued("I was planning to eavesdrop, but that henchman of his"))
        assertTrue(ProSubtitleAssembler.likelyContinued("Press +to [Drink], restoring Sha-Chi and entering"))
        assertFalse(ProSubtitleAssembler.likelyContinued("Please... end my suffering..."))
    }
    @Test fun expandedOcrOnlyAcceptsSameBeginning() {
        val first="Landing an attack inflicts Bleeding and builds the enemy's Bleed Gauge."
        val full=first+" When the gauge is full, it triggers Blood Loss."
        assertEquals(full,ProSubtitleAssembler.fuller(first,full))
        assertEquals(first,ProSubtitleAssembler.fuller(first,"Sweeping Blade consumes 1 point."))
    }
    @Test fun glitchDoesNotReplaceCleanText() {
        val a=ProSubtitleAssembler()
        a.accept("Go on...let me rest...",100L)
        assertEquals("Go on...let me rest...",a.accept("Go onsoolet merest...",250L))
    }
    @Test fun separateSpeakersAreNotGlued() {
        val a=ProSubtitleAssembler()
        a.accept("Vicki: Wait for me.",100L)
        assertEquals("Lucia: Let's go.",a.accept("Lucia: Let's go.",300L))
    }
}
