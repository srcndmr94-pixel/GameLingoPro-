package com.example.altyazi
import org.junit.Assert.*
import org.junit.Test

class GtAllHudTest {
  @Test fun leftGameTipIsOneCard() {
    val lines=listOf(
      GtAllHud.Line("Tip: Suppressors and tactical",180,178,450,204),
      GtAllHud.Line("flashlights can be equipped and",182,205,460,229),
      GtAllHud.Line("removed in your loadout.",183,232,420,255))
    val cards=GtAllHud.group(lines,1536,700,.74f)
    assertEquals(1,cards.size)
    assertEquals("left-top",cards[0].zone)
    assertTrue(cards[0].text.contains("removed in your loadout"))
  }
  @Test fun rightBottomRewardIsNotIgnored() {
    val card=GtAllHud.Line("Bucked You $50",1120,612,1480,664)
    val out=GtAllHud.group(listOf(card),1536,700,.74f)
    assertEquals(1,out.size)
    assertEquals("right-bottom",out[0].zone)
  }
  @Test fun bottomCenterSpeechIsNotDuplicated() {
    val speech=GtAllHud.Line("This is a subtitle not a HUD notice.",420,622,1120,656)
    assertTrue(GtAllHud.group(listOf(speech),1536,700,.74f).isEmpty())
  }
  @Test fun nearbyRowsDoNotJoinAcrossSides() {
    val lines=listOf(GtAllHud.Line("Go to the docks",120,220,390,244),
       GtAllHud.Line("Inventory updated",1180,220,1490,244))
    assertEquals(2,GtAllHud.group(lines,1536,700,.74f).size)
  }
  @Test fun screenCenterHudWorksAboveSubtitle() {
    val line=GtAllHud.Line("Press E to interact",630,250,910,278)
    assertEquals("center",GtAllHud.group(listOf(line),1536,700,.74f).single().zone)
  }
}
