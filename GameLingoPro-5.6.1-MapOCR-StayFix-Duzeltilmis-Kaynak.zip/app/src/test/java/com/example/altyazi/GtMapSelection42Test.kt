package com.example.altyazi
import org.junit.Assert.*
import org.junit.Test
class GtMapSelection42Test {
    private fun line(t:String,x:Int,y:Int,w:Int=200,h:Int=20)=
        GtAllHud.Line(t,x,y,x+w,y+h)
    private val map=listOf(line("MAP",735,25),line("RECENTER",1260,522))
    @Test fun mapRemainsDetectedWithSingleTabAndMapControl() {
        assertTrue(GtSelectedMapPanel.isMap(map,1536,690))
        assertFalse(GtSelectedMapPanel.isMap(listOf(line("MAP",735,25)),1536,690))
    }
    @Test fun previousStarletMotelOverlayCannotReplaceNine1nineTitle() {
        val rows=map+listOf(line("NINE1NINE",826,271,170),
            line("STARLET MOTEL",936,285,181),
            line("Vice City's very own ultra nightclub-strip",828,303,300),
            line("club hybrid where luxury hospitality is",827,332,300))
        val panel=GtSelectedMapPanel.panels(rows,1536,690).first()
        assertEquals("NINE1NINE",panel.title)
        assertEquals("right",panel.slot)
        assertFalse(panel.identity.contains("starlet"))
    }
    @Test fun lateUiPostsAndOldTitleTextAreGuarded() {
        val service=java.io.File("src/main/java/com/example/altyazi/CaptureService.kt").readText()
        val view=java.io.File("src/main/java/com/example/altyazi/GtExactOverlay.kt").readText()
        assertTrue(service.contains("gtPanelTranslatedTitle[slot]==gtPanelKeys[slot]"))
        assertTrue(service.contains("HARİTA SEÇİMİ DEĞİŞTİ"))
        assertTrue(view.contains("gtLabelGeneration.get()!=generation"))
    }
}
