package com.example.altyazi
import org.junit.Assert.*
import org.junit.Test
class GtMenuPriorityTest {
    @Test fun rightInformationBodyBeatsMapPlaceNames() {
        val info=GtAllHud.Card("menu-panel",
            "Vice City's very own ultra nightclub-strip club hybrid where luxury hospitality is delivered to private VIP lounges.",
            820,285,1130,400,5)
        val place=GtAllHud.Card("menu-panel","Atlantic Ocean",
            1200,250,1340,275,1)
        assertTrue(GtMenuPriority.score(info,1536f,690f)>
            GtMenuPriority.score(place,1536f,690f))
    }
    @Test fun primaryMissionIsHigherPriorityThanMapLabels() {
        val mission=GtAllHud.Card("menu-left",
            "Vicki said a mechanic named Moses could set you up with a ride.",
            260,140,573,205,3)
        val label=GtAllHud.Card("menu-panel","Catalan Bay",915,517,1080,540,1)
        assertTrue(GtMenuPriority.score(mission,1536f,690f)>
            GtMenuPriority.score(label,1536f,690f))
    }
    @Test fun translationOutputIsIncrementalInSingleOverlay() {
        val s=java.io.File("src/main/java/com/example/altyazi/CaptureService.kt").readText()
        assertTrue(s.contains("GtMenuPriority.score(card"))
        assertTrue(s.contains("if(fullMenuDetected) {\n                // First translated panel"))
        assertTrue(s.contains("if(fullMenuDetected && newCalls>=3)continue"))
        assertTrue(s.contains("overlay = GtExactOverlay(this)"))
    }
}
