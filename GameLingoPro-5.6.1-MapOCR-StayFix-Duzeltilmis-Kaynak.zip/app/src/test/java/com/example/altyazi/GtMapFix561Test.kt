package com.example.altyazi
import org.junit.Assert.*
import org.junit.Test
import kotlinx.coroutines.*

class GtMapFix561Test {
    @Test fun sameObjectiveRetriesTimeoutEmptyAndEcho() = runBlocking {
        val waits=mutableListOf<Long>()
        var calls=0
        val result=GtObjectiveTranslation.translate("Go north", {
            when(++calls) {
                1 -> { delay(1000); "late" }
                2 -> null
                3 -> "Go north"
                else -> "Kuzeye git"
            }
        }, { waits.add(it) }, 50)
        assertEquals("Kuzeye git",result)
        assertEquals(listOf(1000L,2000L,4000L), waits)
    }
    @Test fun leavingTheMapCancelsPendingRetry() = runBlocking {
        val waiting=CompletableDeferred<Unit>()
        var calls=0
        val job=launch {
            GtObjectiveTranslation.translate("Go north", { calls++; null }, {
                waiting.complete(Unit)
                awaitCancellation()
            })
        }
        waiting.await()
        job.cancelAndJoin()
        assertEquals(1,calls)
    }
    @Test fun aDirectionOrNumberChangesTheTaskEvenInLongSentences() {
        for ((a,b) in listOf("Go north" to "Go south",
            "Return to the north gate" to "Return to the south gate",
            "Find car 2" to "Find car 3","Turn it on" to "Turn it off"))
            assertTrue(GtMapMotion50.newBody(a,b))
        assertFalse(GtMapMotion50.newBody("GO NORTH!", "Go north."))
    }
    @Test fun shortInstructionsAreReadInBothLocations() {
        fun row(text:String,x:Int,y:Int) = GtAllHud.Line(text,x,y,x+95,y+18)
        for(text in listOf("Go north","Go south")) {
            assertEquals(text,GtSelectedMapPanel.objective(listOf(row(text,700,560)),1536,680)?.text)
            assertEquals(text,GtSelectedMapPanel.panels(listOf(row("MISSION",790,175),
                row(text,790,200)),1536,680).single().body)
        }
    }
    @Test fun aStationaryMapDoesNotHideLabelsEveryOtherFrame() {
        for(ms in 0L..7900L step 100L) assertFalse(GtMapMotion50.needsProbe(false,0,ms))
        assertTrue(GtMapMotion50.needsProbe(false,0,8000))
        assertTrue(GtMapMotion50.needsProbe(true,0,500))
        assertTrue(GtMapMotion50.needsProbe(false,1,500))
    }
}
