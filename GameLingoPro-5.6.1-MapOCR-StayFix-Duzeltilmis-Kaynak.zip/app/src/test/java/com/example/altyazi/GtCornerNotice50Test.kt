package com.example.altyazi
import org.junit.Assert.*
import org.junit.Test
class GtCornerNotice50Test {
    private fun row(t:String,x:Int,y:Int,w:Int=300,h:Int=24)=
        GtAllHud.Line(t,x,y,x+w,y+h)
    @Test fun findsEnglishRightBottomAlertWithoutNumbersOrIcons() {
        val rows=listOf(
            row("New objective available",1040,545,310),
            row("Meet your contact at the docks.",1040,574,330),
            row("+100",1400,590,60))
        val n=GtGameNotice.find(rows,1536,690)
        assertNotNull(n)
        assertEquals("corner",n!!.kind)
        assertTrue(n.body.contains("Meet your contact"))
        assertFalse(n.body.contains("+100"))
    }
    @Test fun neverTreatsPs5NativeAlertAsGameMessage() {
        assertNull(GtGameNotice.find(listOf(
            row("Güç",1040,530,250),
            row("PS5 sisteminiz kapatilmaya hazırlanıyor.",1035,563,410)),
            1536,690))
    }
    @Test fun preservesOriginalCharacterSenderAndInGameMessage() {
        val n=GtGameNotice.find(listOf(
            row("Moses",316,487,160),
            row("Clients stiffed me when it",220,539,350),
            row("was time to pay up. Trashed",219,571,350),
            row("my shop, too. They wanna...",222,603,350)),
            1536,690)
        assertEquals("Moses",n!!.title)
        assertFalse(n.body.startsWith("Moses"))
    }
    @Test fun phoneSpokenCaptionsStillRunDuringNotices() {
        val cap=java.io.File("src/main/java/com/example/altyazi/CaptureService.kt").readText()
        assertTrue(cap.contains("processSubtitle(full) // caption always has priority"))
        assertFalse(cap.contains("if(!gtMapPanelMode)processSubtitle(full)"))
        assertTrue(cap.contains("processGameNotice(full,noticeProbe)"))
        assertFalse(cap.contains("gtQuestBoxesOnly"))
    }
    @Test fun sourceMaskUsesTranslucentBackdropAndReadableSizing() {
        val v=java.io.File("src/main/java/com/example/altyazi/GtExactOverlay.kt").readText()
        assertTrue(v.contains("Color.argb(248,17,24,38)"))
        assertTrue(v.contains("val displayW=if(useRect)"))
        assertTrue(v.contains("val displayH=if(useRect)"))
        assertTrue(v.contains("if(card.questHeading)Typeface.BOLD else Typeface.NORMAL"))
    }
}
