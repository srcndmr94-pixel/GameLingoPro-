package com.example.altyazi
import org.junit.Assert.*
import org.junit.Test

class GtOriginalBoundsTest {
    @Test fun originalSourceBoxDoesNotBecomeFullScreen() {
        assertEquals(328,GtSourceBox.width(320,2142,8))
        assertEquals(96,GtSourceBox.width(88,2142,8))
    }
    @Test fun fontIsBasedOnSourceHeightNotChosenSubtitleSize() {
        assertTrue(GtSourceBox.fontPx(72,3,2f)<28f)
        assertEquals(GtSourceBox.fontPx(72,3,2f),
            GtSourceBox.fontPx(72,3,2f),.001f)
    }
    @Test fun englishIsStillVisibleSoOcrMissKeepsTranslation() {
        assertTrue(GtSourceBox.hold(1,300L))
        assertFalse(GtSourceBox.hold(3,5500L))
        assertFalse(GtSourceBox.hold(50,30000L))
    }
    @Test fun bottomObjectiveBelongsToGameHud() {
        assertTrue(GtObjectiveLine.matches("Steal a suitable vehicle"))
        assertFalse(GtObjectiveLine.matches("Are you stealing a suitable vehicle?"))
        val line=GtAllHud.Line("Steal a suitable vehicle",650,624,920,648)
        assertEquals("center-objective",
            GtAllHud.region(line,1536,700,.78f))
    }
    @Test fun differentCardsCannotOverwriteAcrossScreen() {
        assertFalse(GtSourceBox.nearby(220,170,1280,170,1536,690))
        assertTrue(GtSourceBox.nearby(220,170,223,171,1536,690))
    }
    @Test fun gtRendererReallyUsesRectanglesAndOneLayer() {
        val code=java.io.File("src/main/java/com/example/altyazi/GtExactOverlay.kt").readText()
        assertTrue(code.contains("card.bottomY"))
        assertTrue(code.contains("GtSourceBox.fontPx"))
        assertFalse(code.contains("overlay = Overlay(this)"))
    }
}
