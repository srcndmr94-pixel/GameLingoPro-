package com.example.altyazi
import org.junit.Assert.*
import org.junit.Test

class GtStyleContractTest {
 @Test fun chosenSizeIsNotOverridden() {
   assertEquals(28f,GtStyleContract.captionSp(28f),.001f)
   assertEquals(16f,GtStyleContract.captionSp(16f),.001f)
   assertEquals(12f,GtStyleContract.hudSp(28f),.001f)
   assertEquals(12f,GtStyleContract.hudSp(16f),.001f)
 }
 @Test fun backgroundModesRemainDistinct() {
   assertEquals(0,GtStyleContract.subtitleAlpha(0))
   assertEquals(190,GtStyleContract.subtitleAlpha(190))
   assertEquals(255,GtStyleContract.subtitleAlpha(255))
   assertEquals(0,GtStyleContract.hudAlpha(0))
   assertEquals(255,GtStyleContract.hudAlpha(255))
   assertTrue(GtStyleContract.hudAlpha(190)<255)
 }
 @Test fun originalOverlayCannotBeCreated() {
   val cap=java.io.File("src/main/java/com/example/altyazi/CaptureService.kt").readText()
   assertTrue(cap.contains("overlay = GtExactOverlay(this)"))
   assertFalse(cap.contains("overlay = Overlay(this)"))
 }
 @Test fun selectedColorAndSizeActuallyReachRuntime() {
   val exact=java.io.File("src/main/java/com/example/altyazi/GtExactOverlay.kt").readText()
   assertTrue(exact.contains("tv.setTextColor(style.yaziRengi)"))
   assertTrue(exact.contains("GtStyleContract.captionSp(style.boyutSp)"))
   assertTrue(exact.contains("GtStyleContract.hudSp(style.boyutSp)"))
   assertFalse(exact.contains("chosen=style.boyutSp.coerceIn(12f,26f)"))
 }
}
