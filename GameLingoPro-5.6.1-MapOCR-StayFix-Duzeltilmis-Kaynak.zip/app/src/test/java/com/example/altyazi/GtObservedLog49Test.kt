package com.example.altyazi
import org.junit.Assert.*
import org.junit.Test
class GtObservedLog49Test {
    private fun line(text:String,x:Int,y:Int,w:Int=350,h:Int=22)=
        GtAllHud.Line(text,x,y,x+w,y+h)

    @Test fun suppressesPlayStationSystemAndNativeTurkishAlerts() {
        assertNull(GtGameNotice.find(listOf(
            line("Güç",316,487,160),
            line("PS5 sisteminiz kapatilmaya hazırlanıyor.",220,539)),
            1536,690))
        assertNull(GtGameNotice.find(listOf(
            line("FIFA",316,487,160),
            line("PlayStation bildirimi görüntüleniyor.",220,539)),
            1536,690))
        assertNull(GtGameNotice.find(listOf(
            line("Güç",316,487,160),
            line("Konsolunuz kapanmaya hazırlanıyor.",220,539)),
            1536,690))
    }
    @Test fun originalEnglishMosesGameMessageStillWorks() {
        val notice=GtGameNotice.find(listOf(
            line("Moses",316,487,160),
            line("Clients stiffed me when it",220,539),
            line("was time to pay up. Trashed",219,571),
            line("my shop, too. They wanna...",222,603)),1536,690)
        assertNotNull(notice)
        assertEquals("sms",notice!!.kind)
        assertEquals("Moses",notice.title)
        assertTrue(notice.body.contains("stiffed me"))
    }
    @Test fun EnglishInGameTutorialStillWorks() {
        val n=GtGameNotice.find(listOf(
            line("Long guns can be stored",130,275,345),
            line("in your trunk and taken out",130,304,354),
            line("when you need them.",130,333,290)),1536,690)
        assertEquals("tip",n!!.kind)
    }
    @Test fun fixesDemonstratedIncorrectSlangWithoutChangingUnrelatedWords() {
        assertEquals("Dostum, ot arabamız nerede?",
            GtDialogueQuality.polish("Dude, where's our smoke boat?",
                "Dostum, duman teknemiz nerede?"))
        assertEquals("Arabanı çektirdim dostum. Zaten bok gibiydi!",
            GtDialogueQuality.polish(
                "I had them tow your whip, man. That thing was ugly as fuck!",
                "Kırbacını çekmelerini sağladım dostum. O şey çok çirkindi!"))
        assertEquals("Aracın çekildiği otoparka koşmamız lazım!",
            GtDialogueQuality.polish("We gotta book it to the impound!",
                "Hapishaneye kayıt ettirmeliyiz!"))
        assertEquals("Bir saat içinde malımızı satacağız!",
            GtDialogueQuality.polish("We'll be slinging our shit within the hour!",
                "Bir saat içinde bokumuzu atacağız!"))
        assertEquals("Bu bataklıkta çok sayıda ot içen insan var.",
            GtDialogueQuality.polish("There's plenty of stoners in this swamp.",
                "Bu bataklıkta çok sayıda taşçı var."))
        assertEquals("O büyük iguana memelerini görünce aklım başımdan gitti.",
            GtDialogueQuality.polish(
                "I totally spaced out when I saw them big iguana titties.",
                "O büyük iguana memelerini görünce tamamen uzaklaştım."))
        assertEquals("Mantıklıymış.",
            GtDialogueQuality.polish("Sounds like a plan.",
                "Bir plana benziyor."))
        assertEquals("Bu arabanın kırbacı değişmiş.",
            GtDialogueQuality.polish("This car's whip has changed.",
                "Bu arabanın kırbacı değişmiş."))
    }
    @Test fun colorsAndAllTranslationModesRemainActive() {
        val renderer=java.io.File("src/main/java/com/example/altyazi/GtExactOverlay.kt").readText()
        val capture=java.io.File("src/main/java/com/example/altyazi/CaptureService.kt").readText()
        val native=java.io.File("src/main/java/com/example/altyazi/GtNativeEngine.kt").readText()
        assertTrue(renderer.contains("if(card.questHeading)Typeface.BOLD else Typeface.NORMAL"))
        assertTrue(renderer.contains("tv.setTextColor(style.yaziRengi)"))
        assertTrue(capture.contains("processGameNotice(full,noticeProbe)"))
        assertTrue(capture.contains("processMapDetailPanels(full,noticeProbe)"))
        assertTrue(capture.contains("processSubtitle(full)"))
        assertFalse(capture.contains("gtQuestBoxesOnly"))
        assertTrue(native.contains("GoogleGtxTranslator"))
        assertTrue(native.contains("MlKitTranslator"))
    }
}
