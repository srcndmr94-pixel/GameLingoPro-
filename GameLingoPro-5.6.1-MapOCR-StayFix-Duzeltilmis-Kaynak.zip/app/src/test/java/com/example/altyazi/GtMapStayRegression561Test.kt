package com.example.altyazi

import org.junit.Assert.*
import org.junit.Test

/** Each test verifies user-visible persistence or a real map-exit condition. */
class GtMapStayRegression561Test {
    private fun row(t: String, y:Int=200) = GtAllHud.Line(t,100,y,400,y+25)

    @Test fun oneLostMapScanKeepsTranslation() {
        assertFalse(GtMapStay55.shouldExitMap(true,1,true))
    }
    @Test fun threeLostMapScansStillKeepTranslation() {
        assertFalse(GtMapStay55.shouldExitMap(true,3,true))
    }
    @Test fun manyOcrMissesWithoutSceneEvidenceKeepTranslation() {
        assertFalse(GtMapStay55.shouldExitMap(true,100,false))
    }
    @Test fun fourMissesWithStrongSceneEvidenceClearMap() {
        assertTrue(GtMapStay55.shouldExitMap(true,4,true))
    }
    @Test fun stickyQuestSurvivesOcrFlicker() {
        assertFalse(GtMapStay55.shouldForgetQuest(true,100))
    }
    @Test fun optOutClearsAfterTwoMissingMapScans() {
        assertFalse(GtMapStay55.shouldExitMap(false,1,false))
        assertTrue(GtMapStay55.shouldExitMap(false,2,false))
    }
    @Test fun optOutClearsQuestAfterTwoMissingScans() {
        assertTrue(GtMapStay55.shouldForgetQuest(false,2))
    }
    @Test fun dialogueAloneIsNotEvidenceOfMapExit() {
        assertFalse(GtMapStay55.differentScreenEvidence(listOf(row("We have to go")),1536,690))
    }
    @Test fun gameplayMenuIsEvidenceOfDifferentScreen() {
        assertTrue(GtMapStay55.differentScreenEvidence(listOf(row("PAUSED",120),
            row("RESUME GAME",160),row("SETTINGS",200),row("EXIT TO MAIN MENU",240)),1536,690))
    }
    @Test fun visibleMapTabStopsMenuEvidence() {
        assertFalse(GtMapStay55.differentScreenEvidence(listOf(row("MAP",20),
            row("RESUME GAME",160),row("SETTINGS",200),row("EXIT TO MAIN MENU",240),
            row("PAUSED",280)),1536,690))
    }
}
