package com.example.altyazi
import org.junit.Assert.*
import org.junit.Test
class GtColorsAllTranslation47Test {
    @Test fun allTranslatedAreasUseUserSelectedColors() {
        val code=java.io.File("src/main/java/com/example/altyazi/GtExactOverlay.kt").readText()
        assertTrue(code.contains("target.setTextColor(style.yaziRengi)"))
        assertTrue(code.contains("tv.setTextColor(style.yaziRengi)"))
        assertFalse(code.contains("Color.rgb(111,235,244)"))
        assertFalse(code.contains("Color.rgb(105,232,242)"))
        assertTrue(code.contains("Color.argb(248,17,24,38)"))
    }
    @Test fun subtitlesSmsMapAndOtherHudRemainEnabled() {
        val code=java.io.File("src/main/java/com/example/altyazi/CaptureService.kt").readText()
        assertTrue(code.contains("processSubtitle(full)"))
        assertTrue(code.contains("processGameNotice(full,noticeProbe)"))
        assertTrue(code.contains("processMapDetailPanels(full,noticeProbe)"))
        assertTrue(code.contains("GtAllHud.group"))
        assertFalse(code.contains("gtQuestBoxesOnly()"))
    }
    @Test fun originalOcrGeometryIsNotAltered() {
        val code=java.io.File("src/main/java/com/example/altyazi/GtExactOverlay.kt").readText()
        assertTrue(code.contains("val useRect=card.fitSourceBox"))
        assertTrue(code.contains("val sourceW=if(useRect)originalWidth.coerceAtMost(w)"))
        assertTrue(code.contains("val sourceH=if(useRect)originalHeight.coerceAtMost(h)"))
    }
    @Test fun titleAndObjectiveRolesAreIndependentAndOptional() {
        assertTrue(Overlay.Label("Başlık",0,0,questHeading=true).questHeading)
        assertTrue(Overlay.Label("Hedef",0,0,questObjective=true).questObjective)
        assertFalse(Overlay.Label("Normal",0,0).questHeading)
    }
}
