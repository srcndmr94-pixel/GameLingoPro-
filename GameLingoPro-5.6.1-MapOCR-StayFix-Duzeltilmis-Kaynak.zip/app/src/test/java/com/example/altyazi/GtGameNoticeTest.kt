package com.example.altyazi
import org.junit.Assert.*
import org.junit.Test

class GtGameNoticeTest {
    private fun row(text:String,x:Int,y:Int,w:Int=350,h:Int=22) =
        GtAllHud.Line(text,x,y,x+w,y+h)
    @Test fun recognizesMosesIncomingPopupWithoutManualSelection() {
        val sample=listOf(
            row("Moses",316,487,160),
            row("Clients stiffed me when it",220,539),
            row("was time to pay up. Trashed",219,571),
            row("my shop, too. They wanna...",222,603))
        val notice=GtGameNotice.find(sample,1536,690)
        assertNotNull(notice)
        assertEquals("sms",notice!!.kind)
        assertEquals("Moses",notice.title)
        assertEquals(3,notice.rows)
        assertTrue(notice.body.contains("Trashed"))
        assertEquals(219,notice.left)
    }
    @Test fun senderHeaderStillSignalsNotificationUnderTranslatedBody() {
        val item=GtGameNotice.find(listOf(row("Moses",316,487,160)),
            1536,690,"Moses")
        assertNotNull(item)
        assertEquals("",item!!.body)
    }
    @Test fun tutorialTipIsSeparateFromDialogue() {
        val tip=GtGameNotice.find(listOf(
            row("Long guns can be stored",130,275,345),
            row("in your trunk and taken out",130,304,354),
            row("when you need them.",130,333,290)),1536,690)
        assertEquals("tip",tip!!.kind)
        assertTrue(tip.body.contains("trunk"))
        val speech=GtGameNotice.find(listOf(
            row("Where are you going?",600,622,320),
            row("Wait for me!",600,652,200)),1536,690)
        assertNull(speech)
    }
    @Test fun noticeUsesOneOriginalSizeOverlayAndClearsWhenAbsent() {
        val service=java.io.File("src/main/java/com/example/altyazi/CaptureService.kt").readText()
        val overlay=java.io.File("src/main/java/com/example/altyazi/GtExactOverlay.kt").readText()
        assertTrue(service.contains("resetGameNotice()"))
        assertTrue(service.contains("mapProbe || (!gtMapPanelMode && gtNoticeMode"))
        assertTrue(service.contains("gameNotice=true"))
        assertTrue(overlay.contains("if(card.gameNotice)"))
    }
}
