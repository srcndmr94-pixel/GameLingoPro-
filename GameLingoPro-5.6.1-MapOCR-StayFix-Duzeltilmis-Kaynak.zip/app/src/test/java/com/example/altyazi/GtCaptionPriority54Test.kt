package com.example.altyazi
import org.junit.Assert.*
import org.junit.Test
import java.io.File
class GtCaptionPriority54Test {
    private fun row(t:String,x:Int,y:Int,w:Int=350,h:Int=24)=
        GtAllHud.Line(t,x,y,x+w,y+h)
    @Test fun staticImageCannotSuppressOcrForever() {
        assertTrue(GtCaptionScanPolicy54.shouldRunOcr(false,1L))
        assertFalse(GtCaptionScanPolicy54.shouldRunOcr(true,200L))
        assertFalse(GtCaptionScanPolicy54.shouldRunOcr(true,419L))
        assertTrue(GtCaptionScanPolicy54.shouldRunOcr(true,420L))
        assertTrue(GtCaptionScanPolicy54.shouldRunOcr(true,1500L))
    }
    @Test fun mapSelectionDoesNotDisableSpeech() {
        val s=File("src/main/java/com/example/altyazi/CaptureService.kt").readText()
        assertTrue(s.contains("processSubtitle(full) // caption always has priority"))
        assertFalse(s.contains("if(!gtMapPanelMode)processSubtitle(full)"))
        assertTrue(s.contains("val sutun = 48"))
        assertTrue(s.contains("val satir = 12"))
        assertTrue(s.contains("enBuyukFark < 7"))
        assertTrue(s.contains("ALTYAZI TARAMA: OCR"))
    }
    @Test fun normalVideoDialoguesAreNotTutorials() {
        assertNull(GtGameNotice.find(listOf(
            row("There's a reason I can only trust you",130,285,420),
            row("with this, and you know why.",130,320,350)),1536,690))
        assertNull(GtGameNotice.find(listOf(
            row("This is a puzzle buried in centuries",130,280,420),
            row("of silence and mystery, you know.",130,314,350)),1536,690))
    }
    @Test fun genuineGameTutorialAndMessagesStillWork() {
        assertEquals("tip",GtGameNotice.find(listOf(
            row("Long guns can be stored",130,275,345),
            row("in your trunk and taken out",130,304,354),
            row("when you need them.",130,333,290)),1536,690)!!.kind)
        assertEquals("sms",GtGameNotice.find(listOf(
            row("Moses",316,487,160),
            row("Clients stiffed me when it",220,539,350),
            row("was time to pay up. Trashed",219,571,350),
            row("my shop, too. They wanna...",222,603,350)),1536,690)!!.kind)
    }
    @Test fun originalTranslationColorsAndBrandArePreserved() {
        val ui=File("src/main/res/layout/activity_main.xml").readText()
        val overlay=File("src/main/java/com/example/altyazi/GtExactOverlay.kt").readText()
        val engine=File("src/main/java/com/example/altyazi/GtNativeEngine.kt").readText()
        assertTrue(ui.contains("GAMELINGOPRO · ALTYAZI ALANLARI"))
        assertTrue(overlay.contains("style.yaziRengi"))
        assertTrue(engine.contains("GoogleGtxTranslator"))
        assertTrue(engine.contains("MlKitTranslator"))
    }
}
