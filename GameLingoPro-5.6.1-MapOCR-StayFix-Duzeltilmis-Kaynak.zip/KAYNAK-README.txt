GameLingoPro 5.6.1 MapOCR-StayFix · Android telefon uygulaması
Paket kimliği com.gamelingo.pro · sürüm kodu 20261232

Proje kökünü Android Studio ile açabilirsiniz. Komut satırı derlemesi için JDK 17, Gradle 8.13, Android SDK Platform 35 ve Build Tools 34.0.0 gerekir.
Uygulama ve test kaynakları app/src dizinindedir. Eski yama betikleri tools altında geçmiş kayıt olarak yer alır. Güncel kaynak doğrudan derlenir.

İmzalama
Mevcut kurulumun üzerine güncelleme üretmek için aynı imza anahtarı gerekir. Yetkili anahtarınızı app/debug.keystore konumuna yerleştirin.
Bağımsız test kurulumu için yeni bir yerel anahtar oluşturabilirsiniz:
keytool -genkeypair -keystore app/debug.keystore -storetype JKS -storepass android -keypass android -alias androiddebugkey -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=Android Debug,O=Android,C=US"

Proje kökünde çalıştırın:
gradle :app:testDebugUnitTest :app:assembleDebug

APK çıktısı:
app/build/outputs/apk/debug/app-debug.apk

DÜZELTME NOTU (MapOCR-StayFix)
- Harita görev çevirisini sabit tut seçeneği artık varsayılan açık.
- Etkinken bir veya çok sayıda geçici OCR kaybı, harita/görev çevirisini silmez.
- Haritadan çıkış için en az dört ardışık harita OCR kaybı ve gerçek ekran değişikliği kanıtı gerekir.
- Ayarı kapatan kullanıcı için iki ardışık başarısız taramada eski otomatik temizleme korunur.
- Farklı ekran OCR analizi artık gerçekten çalıştırılır; yanlışlıkla sabit false değildir.
- Kaynak dosyalarına 10 yeni regresyon testi eklendi.
- Paket adı ve imzalama kimliği değiştirilmedi; eski APK üstüne güncelleme yalnızca aynı anahtarla mümkündür.
- Bu ZIP kaynak kodudur. Android SDK/Gradle olmadan burada APK derlenmiş veya cihazda denenmiş değildir.
