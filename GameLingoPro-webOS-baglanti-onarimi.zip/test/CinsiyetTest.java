import java.util.*;
import java.util.regex.*;
import java.io.*;
import java.nio.file.*;

/**
 * KonusanCinsiyeti.kt mantığının testi.
 * Ad listeleri Kotlin kaynağından okunur; iki yerde ayrı liste tutulmasın.
 */
public class CinsiyetTest {

    static final int BILINMIYOR = 0, ERKEK = 1, KADIN = 2;
    static final Locale TR = new Locale("tr", "TR");

    static final Pattern AD_ONEKI =
        Pattern.compile("^(\\p{Lu}[\\p{L}.'\\-]{1,19}(?:\\s\\p{Lu}[\\p{L}.'\\-]{1,19})?)\\s*:\\s+");

    static Set<String> ERKEK_ADLARI = new HashSet<>(), KADIN_ADLARI = new HashSet<>();

    static void listeleriOku(String yol) throws IOException {
        String t = new String(Files.readAllBytes(Paths.get(yol)), "UTF-8");
        ERKEK_ADLARI = blok(t, "ERKEK_ADLARI");
        KADIN_ADLARI = blok(t, "KADIN_ADLARI");
    }

    static Set<String> blok(String t, String ad) {
        int b = t.indexOf("private val " + ad + " = setOf(");
        String blok = t.substring(b);
        blok = blok.substring(0, blok.indexOf("\n    )"));
        Set<String> out = new HashSet<>();
        Matcher m = Pattern.compile("\"([^\"]+)\"").matcher(blok);
        while (m.find()) out.add(m.group(1));
        return out;
    }

    static String adiAyikla(String satir) {
        if (satir == null || satir.trim().isEmpty()) return null;
        Matcher m = AD_ONEKI.matcher(satir.trim());
        if (!m.find()) return null;
        String ad = m.group(1).trim();
        return ad.isEmpty() ? null : ad;
    }

    static int tahmin(String ad) {
        if (ad == null || ad.trim().isEmpty()) return BILINMIYOR;
        String temiz = ad.trim();
        while (!temiz.isEmpty() && ".,!?\"'".indexOf(temiz.charAt(0)) >= 0) temiz = temiz.substring(1);
        while (!temiz.isEmpty() && ".,!?\"'".indexOf(temiz.charAt(temiz.length()-1)) >= 0)
            temiz = temiz.substring(0, temiz.length()-1);
        if (temiz.isEmpty()) return BILINMIYOR;
        String ilk = temiz.contains(" ") ? temiz.substring(0, temiz.indexOf(' ')) : temiz;
        if (ilk.isEmpty()) return BILINMIYOR;
        LinkedHashSet<String> anahtarlar = new LinkedHashSet<>();
        anahtarlar.add(ilk.toLowerCase(Locale.ROOT));
        anahtarlar.add(ilk.toLowerCase(TR));
        for (String a : anahtarlar) {
            if (ERKEK_ADLARI.contains(a)) return ERKEK;
            if (KADIN_ADLARI.contains(a)) return KADIN;
        }
        return BILINMIYOR;
    }

    static int gecti = 0, kaldi = 0;
    static void esit(String ad, Object bek, Object gel) {
        boolean ok = bek == null ? gel == null : bek.equals(gel);
        if (ok) { gecti++; System.out.println("  OK   " + ad); }
        else { kaldi++; System.out.println("  HATA " + ad + "  beklenen=[" + bek + "] gelen=[" + gel + "]"); }
    }
    static String c(int x) { return x == ERKEK ? "ERKEK" : x == KADIN ? "KADIN" : "BILINMIYOR"; }

    public static void main(String[] a) throws Exception {
        listeleriOku(a.length > 0 ? a[0]
            : "/home/claude/src_zip/app/src/main/java/com/example/altyazi/KonusanCinsiyeti.kt");
        System.out.println("liste: erkek=" + ERKEK_ADLARI.size() + " kadin=" + KADIN_ADLARI.size());

        System.out.println("== ad ayiklama ==");
        esit("basit", "JASON", adiAyikla("JASON: Arabaya bin."));
        esit("normal yazim", "Lucia", adiAyikla("Lucia: Buradan gidelim."));
        esit("iki kelime", "John Marston", adiAyikla("John Marston: Hadi."));
        esit("bosluksuz", "LUCIA", adiAyikla("LUCIA: Tamam."));
        esit("ad yok", null, adiAyikla("Arabaya bin."));
        esit("cumle ortasi iki nokta", null, adiAyikla("Sana bir sey diyecegim: kac."));
        esit("saat", null, adiAyikla("Saat 10:30'da buradayim."));
        esit("null", null, adiAyikla(null));

        System.out.println("== cinsiyet: buyuk harf tuzagi ==");
        esit("IRENE (ROOT gerekir)", "KADIN", c(tahmin("IRENE")));
        esit("IVAN (ROOT gerekir)", "ERKEK", c(tahmin("IVAN")));
        esit("ISAAC", "ERKEK", c(tahmin("ISAAC")));
        esit("IRIS", "KADIN", c(tahmin("IRIS")));

        System.out.println("== cinsiyet: turkce harf ==");
        esit("ISMAIL", "ERKEK", c(tahmin("ISMAIL")));
        esit("Ismail", "ERKEK", c(tahmin("Ismail")));
        esit("ZEYNEP", "KADIN", c(tahmin("ZEYNEP")));
        esit("Ozlem", "KADIN", c(tahmin("ozlem")));

        System.out.println("== cinsiyet: oyun karakterleri ==");
        esit("JASON", "ERKEK", c(tahmin("JASON")));
        esit("Lucia", "KADIN", c(tahmin("Lucia")));
        esit("Arthur", "ERKEK", c(tahmin("Arthur")));
        esit("John Marston (ilk kelime)", "ERKEK", c(tahmin("John Marston")));
        esit("Sarah Connor", "KADIN", c(tahmin("Sarah Connor")));

        System.out.println("== bilinmeyen zorlanmaz ==");
        esit("Kratos", "BILINMIYOR", c(tahmin("Kratos")));
        esit("Zagreus", "BILINMIYOR", c(tahmin("Zagreus")));
        esit("bos", "BILINMIYOR", c(tahmin("")));
        esit("null", "BILINMIYOR", c(tahmin(null)));
        esit("noktalama", "ERKEK", c(tahmin("James.")));

        System.out.println("== uctan uca: satirdan cinsiyete ==");
        esit("erkek satir", "ERKEK", c(tahmin(adiAyikla("JASON: Arabaya bin."))));
        esit("kadin satir", "KADIN", c(tahmin(adiAyikla("Lucia: Beni dinle."))));
        esit("adsiz satir", "BILINMIYOR", c(tahmin(adiAyikla("Arabaya bin."))));

        System.out.println("\nGecti: " + gecti + " · Kaldi: " + kaldi);
        if (kaldi > 0) System.exit(1);
    }
}
