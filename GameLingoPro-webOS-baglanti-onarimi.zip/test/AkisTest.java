import java.util.*;

/** CaptureService.seslendir() mantığının birebir simülasyonu; sahte saat ve kuyruk. */
public class AkisTest {

    static final long TASLAK_SES_BEKLE = 1600L;
    static final long SES_KARARLILIK_TAM = 220L;
    static final long SES_KARARLILIK_YARIM = 520L;

    static boolean cumleTamamMi(String m){
        String t = m.replaceAll("\\s+$","");
        if (t.isEmpty()) return false;
        char c = t.charAt(t.length()-1);
        return ".!?\u2026\"'\u00bb".indexOf(c) >= 0;
    }

    // --- taklit edilen durum
    String shownValue = "", shownSource = "", sesSonKaynak = "", sesOkunanKaynak = "";
    List<String> okunanlar = new ArrayList<>();   // sese giden cumleler, sirayla
    String sonOkunanSade = "";                    // SesliOku icindeki tekrar engeli

    // sahte zamanlayici: (zaman, is)
    Long bekleyenZaman = null; String bekleyenValue = null, bekleyenKaynak = null;
    long simdi = 0;

    void iptal() { bekleyenZaman = null; bekleyenValue = null; bekleyenKaynak = null; }

    void oku(String v) {
        String sade = SesTest.sade(SesTest.temizle(v, true) == null ? v : SesTest.temizle(v, true));
        if (sade.equals(sonOkunanSade)) return;   // SesliOku: ayni yazi iki kez okunmaz
        sonOkunanSade = sade;
        okunanlar.add(v);
    }

    /** CaptureService: shownSource/shownValue atanir, sonra showSubtitle -> seslendir */
    void satir(String source, String value, boolean refined, boolean draft) {
        shownSource = source; shownValue = value;
        seslendir(value, refined, draft);
    }

    void temizle() { shownValue = ""; seslendir(null, false, false); }

    void seslendir(String value, boolean refined, boolean draft) {
        iptal();
        if (value == null) { sesSonKaynak = ""; sesOkunanKaynak = ""; sonOkunanSade = ""; return; }
        if (!SesTest.okunurMu(value)) return;
        String kaynak = shownSource;
        if (!kaynak.isEmpty() && kaynak.equals(sesSonKaynak)) return;
        // UZANTI: okunan cumlenin devami
        if (!sesOkunanKaynak.isEmpty() && kaynak.length() > sesOkunanKaynak.length()
                && kaynak.startsWith(sesOkunanKaynak)) return;
        long bekleme = (draft && !refined) ? TASLAK_SES_BEKLE
                : cumleTamamMi(value) ? SES_KARARLILIK_TAM : SES_KARARLILIK_YARIM;
        bekleyenZaman = simdi + bekleme;
        bekleyenValue = value; bekleyenKaynak = kaynak;
    }

    /** Saati ilerletir, vakti gelen bekleyen okumayi calistirir. */
    void ilerle(long ms) {
        long hedef = simdi + ms;
        if (bekleyenZaman != null && bekleyenZaman <= hedef) {
            simdi = bekleyenZaman;
            if (shownValue.equals(bekleyenValue) && shownSource.equals(bekleyenKaynak)) {
                sesSonKaynak = bekleyenKaynak;
                sesOkunanKaynak = bekleyenKaynak;
                oku(bekleyenValue);
            }
            iptal();
        }
        simdi = hedef;
    }

    static int gecti = 0, kaldi = 0;
    static void esit(String ad, List<String> beklenen, List<String> gercek) {
        if (beklenen.equals(gercek)) { gecti++; System.out.println("  OK   " + ad); }
        else { kaldi++; System.out.println("  HATA " + ad + "\n        beklenen: " + beklenen + "\n        gelen   : " + gercek); }
    }

    public static void main(String[] a) {
        System.out.println("== A) Anlik mod: kararlilik beklemesinden sonra okunur ==");
        AkisTest t = new AkisTest();
        t.satir("Get in the car.", "Arabaya bin.", false, false);
        esit("hemen okunmaz", List.of(), t.okunanlar);
        t.ilerle(250);
        esit("220 ms sonra okunur (cumle tam)", List.of("Arabaya bin."), t.okunanlar);

        System.out.println("== B) Taslak -> farkli duzeltme 1600 ms ICINDE: yalniz duzeltme ==");
        t = new AkisTest();
        t.satir("Get in the car.", "Arabanin icine gir.", false, true);
        t.ilerle(900);
        t.satir("Get in the car.", "Arabaya bin.", true, false);
        t.ilerle(3000);
        esit("yalniz duzeltilmis", List.of("Arabaya bin."), t.okunanlar);

        System.out.println("== C) Taslak -> ayni duzeltme: bir kez ==");
        t = new AkisTest();
        t.satir("Yes.", "Evet.", false, true);
        t.ilerle(800);
        t.satir("Yes.", "Evet.", true, false);
        t.ilerle(3000);
        esit("tek okuma", List.of("Evet."), t.okunanlar);

        System.out.println("== D) Taslak -> duzeltme GELMEZ: 1600 ms sonra taslak okunur ==");
        t = new AkisTest();
        t.satir("Lights out.", "Isiklar kapandi.", false, true);
        esit("henuz okunmadi", List.of(), t.okunanlar);
        t.ilerle(1599);
        esit("1599 ms: hala okunmadi", List.of(), t.okunanlar);
        t.ilerle(2);
        esit("1600 ms: taslak okundu", List.of("Isiklar kapandi."), t.okunanlar);

        System.out.println("== E) Taslak okundu, SONRA duzeltme gelir: tekrar OKUNMAZ ==");
        t = new AkisTest();
        t.satir("He is lying to you.", "O sana yalan soyluyor.", false, true);
        t.ilerle(1700);                                  // taslak okundu
        t.satir("He is lying to you.", "Sana yalan atiyor.", true, false);
        t.ilerle(2000);
        esit("yalniz taslak, duzeltme sessiz", List.of("O sana yalan soyluyor."), t.okunanlar);

        System.out.println("== F) Hizli konusma: bekleyen taslak yeni replikle DUSER ==");
        t = new AkisTest();
        t.satir("Wait here.", "Burada bekle.", false, true);
        t.ilerle(500);
        t.satir("No, follow me.", "Hayir, beni takip et.", false, true);
        t.ilerle(1700);
        esit("yalniz son replik", List.of("Hayir, beni takip et."), t.okunanlar);

        System.out.println("== G) Ekran temizlenince bekleyen okuma iptal ==");
        t = new AkisTest();
        t.satir("Something.", "Bir sey.", false, true);
        t.ilerle(600);
        t.temizle();
        t.ilerle(3000);
        esit("hic okunmadi", List.of(), t.okunanlar);

        System.out.println("== H) Uyari ve durum satirlari okunmaz ==");
        t = new AkisTest();
        t.satir("x", "⚠ Ekranda yazi okunamiyor. Altyazi bolgesini kontrol edin.", false, false);
        t.ilerle(800);
        t.satir("y", "GameLingo calisiyor…", false, false);
        t.ilerle(800);
        t.satir("Go.", "Gidelim.", false, false);
        t.ilerle(800);
        esit("yalniz gercek replik", List.of("Gidelim."), t.okunanlar);

        System.out.println("== I) Uc replik ust uste: her biri bir kez, sirayla ==");
        t = new AkisTest();
        t.satir("One.", "Bir.", false, false);
        t.ilerle(800);
        t.satir("Two.", "Iki.", false, false);
        t.ilerle(800);
        t.satir("Three.", "Uc.", false, false);
        t.ilerle(800);
        esit("sirayla uc okuma", List.of("Bir.", "Iki.", "Uc."), t.okunanlar);

        System.out.println("== J) HECELEME: OCR satiri buyutuyor, TEK KEZ okunmali ==");
        t = new AkisTest();
        t.satir("Come", "Gel", false, false);
        t.ilerle(200);
        t.satir("Come here", "Buraya gel", false, false);
        t.ilerle(200);
        t.satir("Come here and", "Buraya gel ve", false, false);
        t.ilerle(200);
        t.satir("Come here and open the door.", "Buraya gel ve kapıyı aç.", false, false);
        t.ilerle(1500);
        esit("yalniz tam cumle, bir kez", List.of("Buraya gel ve kapıyı aç."), t.okunanlar);

        System.out.println("== K) Okunduktan SONRA gelen uzanti atlanir ==");
        t = new AkisTest();
        t.satir("I think we should go", "Bence gitmeliyiz", false, false);
        t.ilerle(800);                       // okundu
        t.satir("I think we should go now.", "Bence şimdi gitmeliyiz.", false, false);
        t.ilerle(1500);
        esit("uzanti tekrar okunmaz", List.of("Bence gitmeliyiz"), t.okunanlar);

        System.out.println("== L) Gercekten YENI replik kesinlikle okunur ==");
        t = new AkisTest();
        t.satir("Get down!", "Eğil!", false, false);
        t.ilerle(800);
        t.satir("They are shooting at us.", "Bize ateş ediyorlar.", false, false);
        t.ilerle(800);
        esit("iki ayri replik", List.of("Eğil!", "Bize ateş ediyorlar."), t.okunanlar);

        System.out.println("== M) Kisa surede gecen satir hic okunmaz ==");
        t = new AkisTest();
        t.satir("Blink", "Göz kırp", false, false);
        t.ilerle(300);
        t.satir("Totally different line here.", "Bambaşka bir satır.", false, false);
        t.ilerle(800);
        esit("yalniz kalici olan", List.of("Bambaşka bir satır."), t.okunanlar);

        System.out.println("== N) BILINCLI DAVRANIS: kararlilik suresinden kisa yasayan satir okunmaz ==");
        // Ekranda yarim saniye kalip kaybolan bir satir sese verilmez.
        // Bu kasitli: oyunda replikler 2-5 sn duruyor, bu kadar kisa
        // degisimler OCR titremesi oluyor ve okunsa heceleme geri gelirdi.
        t = new AkisTest();
        t.satir("Flicker", "Titreme", false, false);
        t.ilerle(400);
        t.temizle();
        t.ilerle(2000);
        esit("kisa omurlu satir atlanir", List.of(), t.okunanlar);

        System.out.println("== O) GECIKME: tam cumle kisa, yarim cumle uzun bekler ==");
        t = new AkisTest();
        t.satir("Get in.", "Arabaya bin.", false, false);
        t.ilerle(219);
        esit("219 ms: henuz okunmadi", List.of(), t.okunanlar);
        t.ilerle(2);
        esit("221 ms: okundu (nokta ile bitiyor)", List.of("Arabaya bin."), t.okunanlar);

        t = new AkisTest();
        t.satir("Get in and", "Arabaya bin ve", false, false);
        t.ilerle(300);
        esit("yarim cumle 300 ms'de okunmaz", List.of(), t.okunanlar);
        t.ilerle(250);
        esit("520 ms'de okunur", List.of("Arabaya bin ve"), t.okunanlar);

        System.out.println("== P) Heceleme HALA onlenmis (asil koruma uzanti atlama) ==");
        t = new AkisTest();
        t.satir("Come", "Gel", false, false);
        t.ilerle(100);
        t.satir("Come here", "Buraya gel", false, false);
        t.ilerle(100);
        t.satir("Come here and open the door.", "Buraya gel ve kapıyı aç.", false, false);
        t.ilerle(600);
        esit("yalniz tam cumle, bir kez", List.of("Buraya gel ve kapıyı aç."), t.okunanlar);

        System.out.println("\nGecti: " + gecti + " · Kaldi: " + kaldi);
        if (kaldi > 0) System.exit(1);
    }
}
