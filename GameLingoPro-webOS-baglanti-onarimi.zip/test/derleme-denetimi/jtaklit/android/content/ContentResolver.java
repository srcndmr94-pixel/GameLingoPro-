package android.content;
import java.io.InputStream;
import java.io.OutputStream;
public class ContentResolver {
    public InputStream openInputStream(android.net.Uri uri) { return null; }
    public OutputStream openOutputStream(android.net.Uri uri) { return null; }
}
