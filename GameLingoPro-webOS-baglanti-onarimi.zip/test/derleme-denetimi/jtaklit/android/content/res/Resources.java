package android.content.res;
public class Resources {
    public int getColor(int id, Object theme) { return 0; }
    public float getDisplayMetricsDensity() { return 3f; }
    public android.util.DisplayMetrics getDisplayMetrics() { return new android.util.DisplayMetrics(); }
}
