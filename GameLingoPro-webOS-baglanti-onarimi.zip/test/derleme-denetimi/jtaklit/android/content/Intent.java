package android.content;
public class Intent {
    public Intent() {}
    public Intent(Context c, Class<?> cls) {}
    public static final String ACTION_BATTERY_CHANGED = "battery";
    public Intent putExtra(String name, String value) { return this; }
    public Intent putExtra(String name, boolean value) { return this; }
    public Intent putExtra(String name, int value) { return this; }
    public String getStringExtra(String name) { return null; }
    public boolean getBooleanExtra(String name, boolean def) { return def; }
}
