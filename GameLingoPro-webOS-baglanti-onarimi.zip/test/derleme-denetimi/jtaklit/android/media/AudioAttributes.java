package android.media;
public class AudioAttributes { public static final int USAGE_GAME = 14, USAGE_MEDIA = 1; }
