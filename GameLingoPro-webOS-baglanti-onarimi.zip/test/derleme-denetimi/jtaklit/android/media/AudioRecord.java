package android.media;
public class AudioRecord {
    public static final int STATE_INITIALIZED = 1, RECORDSTATE_RECORDING = 3, READ_BLOCKING = 0;
    public static int getMinBufferSize(int sr, int ch, int enc) { return 4096; }
    public int getState() { return STATE_INITIALIZED; }
    public int getRecordingState() { return RECORDSTATE_RECORDING; }
    public void startRecording() {}
    public void stop() {}
    public void release() {}
    public int read(short[] b, int off, int size, int mode) { return 0; }
    public static class Builder {
        public Builder setAudioFormat(AudioFormat f) { return this; }
        public Builder setBufferSizeInBytes(int n) { return this; }
        public Builder setAudioPlaybackCaptureConfig(AudioPlaybackCaptureConfiguration c) { return this; }
        public Builder setAudioSource(int s) { return this; }
        public AudioRecord build() { return new AudioRecord(); }
    }
}
