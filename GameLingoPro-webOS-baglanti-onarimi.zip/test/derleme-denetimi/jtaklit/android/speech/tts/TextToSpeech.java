package android.speech.tts;
import java.util.Locale;
import java.util.Set;
import java.io.File;
import android.content.Context;
import android.os.Bundle;
public class TextToSpeech {
    public interface OnInitListener { void onInit(int status); }
    public TextToSpeech(Context c, OnInitListener l) {}
    public int setLanguage(Locale loc) { return 0; }
    public int setSpeechRate(float r) { return 0; }
    public int setPitch(float p) { return 0; }
    public Set<Voice> getVoices() { return null; }
    public Voice getVoice() { return null; }
    public int setVoice(Voice v) { return 0; }
    public int speak(CharSequence text, int queueMode, Bundle params, String utteranceId) { return 0; }
    public int synthesizeToFile(CharSequence text, Bundle params, File file, String utteranceId) { return 0; }
    public int setOnUtteranceProgressListener(UtteranceProgressListener l) { return 0; }
    public int stop() { return 0; }
    public void shutdown() {}
    public static final int SUCCESS = 0;
    public static final int ERROR = -1;
    public static final int QUEUE_FLUSH = 0;
    public static final int LANG_AVAILABLE = 0;
    public static final int LANG_COUNTRY_AVAILABLE = 1;
    public static final int LANG_COUNTRY_VAR_AVAILABLE = 2;
    public static final int LANG_NOT_SUPPORTED = -2;
    public static final int LANG_MISSING_DATA = -1;
    public static class Engine {
        public static final String KEY_PARAM_VOLUME = "volume";
        public static final String KEY_PARAM_STREAM = "streamType";
    }
}
