package android.text;
public interface InputType {
    int TYPE_CLASS_NUMBER = 2;
    int TYPE_CLASS_TEXT = 1;
}
