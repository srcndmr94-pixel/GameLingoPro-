package android.widget;
public abstract class AdapterView<T extends Adapter> extends android.view.View {
    public void setSelection(int pos) {}
    public int getSelectedItemPosition() { return 0; }
    public void setOnItemSelectedListener(OnItemSelectedListener l) {}
    public OnItemSelectedListener getOnItemSelectedListener() { return null; }
    public interface OnItemSelectedListener {
        void onItemSelected(AdapterView<?> parent, android.view.View view, int position, long id);
        void onNothingSelected(AdapterView<?> parent);
    }
}
