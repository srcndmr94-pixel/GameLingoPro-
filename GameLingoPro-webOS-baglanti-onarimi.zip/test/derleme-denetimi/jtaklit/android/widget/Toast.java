package android.widget;
public class Toast {
    public static final int LENGTH_SHORT = 0, LENGTH_LONG = 1;
    public static Toast makeText(android.content.Context c, CharSequence t, int d) { return new Toast(); }
    public void show() {}
}
