package android.widget;
public class RadioGroup extends LinearLayout {
    public RadioGroup(android.content.Context c) { super(c); }
    public int getCheckedRadioButtonId() { return 0; }
    public void check(int id) {}
    public void setOnCheckedChangeListener(OnCheckedChangeListener l) {}
    public interface OnCheckedChangeListener { void onCheckedChanged(RadioGroup group, int checkedId); }
}
