package android.widget;
public class TextView extends android.view.View {
    public TextView() {}
    public TextView(android.content.Context c) {}
    public void setText(CharSequence t) {}
    public CharSequence getText() { return ""; }
    public void setTextSize(float s) {}
    public float getTextSize() { return 14f; }
    public void setTextColor(int color) {}
    public void setTextIsSelectable(boolean b) {}
    public android.graphics.Typeface getTypeface() { return null; }
    public void setTypeface(android.graphics.Typeface tf, int style) {}
}
