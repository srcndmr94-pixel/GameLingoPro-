package android.widget;
public class Spinner extends AdapterView<SpinnerAdapter> {
    public Spinner() {}
    public Spinner(android.content.Context c) {}
    public void setAdapter(SpinnerAdapter a) {}
    public SpinnerAdapter getAdapter() { return null; }
    public void setSelection(int position) {}
}
