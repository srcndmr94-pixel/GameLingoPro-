package com.example.altyazi;
public final class R {
    public static final class id {
        public static final int ayarBaslikCubugu = 1000;
        public static final int ayarMenu = 1001;
        public static final int ayarOzet1 = 1002;
        public static final int ayarOzet2 = 1003;
        public static final int ayarOzet3 = 1004;
        public static final int ayarOzet4 = 1005;
        public static final int ayarOzet5 = 1006;
        public static final int ayarOzet6 = 1007;
        public static final int ayarOzet7 = 1008;
        public static final int ayarOzet8 = 1009;
        public static final int ayarSatir1 = 1010;
        public static final int ayarSatir2 = 1011;
        public static final int ayarSatir3 = 1012;
        public static final int ayarSatir4 = 1013;
        public static final int ayarSatir5 = 1014;
        public static final int ayarSatir6 = 1015;
        public static final int ayarSatir7 = 1016;
        public static final int ayarSatir8 = 1017;
        public static final int boxDuygu = 1018;
        public static final int boxOzel = 1019;
        public static final int boxSesCinsiyet = 1020;
        public static final int btnAyarGeri = 1021;
        public static final int btnDuyguDene = 1022;
        public static final int btnOzelAktar = 1023;
        public static final int btnOzelSablon = 1024;
        public static final int btnOzelSil = 1025;
        public static final int btnSesDogalAyar = 1026;
        public static final int btnSesKaydiKopyala = 1027;
        public static final int btnSesKaydiTemizle = 1028;
        public static final int btnYanSag = 1029;
        public static final int btnYanSol = 1030;
        public static final int cbDuygu = 1031;
        public static final int cbDuyguCumle = 1032;
        public static final int cbDuyguTr = 1033;
        public static final int cbDuyguUnlem = 1034;
        public static final int cbMenuModu = 1035;
        public static final int cbSesAdsizAtla = 1036;
        public static final int cbSesKaydi = 1037;
        public static final int cbSesTekrarSuz = 1038;
        public static final int cbYanSag = 1039;
        public static final int cbYanSol = 1040;
        public static final int navHelp = 1041;
        public static final int navHistory = 1042;
        public static final int navHome = 1043;
        public static final int navSettings = 1044;
        public static final int rbAkisBitir = 1045;
        public static final int rbAkisHizlan = 1046;
        public static final int rbAkisKes = 1047;
        public static final int rbDuyguAtla = 1048;
        public static final int rbDuyguCanli = 1049;
        public static final int rbDuyguKisik = 1050;
        public static final int rgDuyguNot = 1051;
        public static final int rgSesAkis = 1052;
        public static final int sbDuyguSiddet = 1053;
        public static final int scroll = 1054;
        public static final int secAdvanced = 1055;
        public static final int secAi = 1056;
        public static final int secContent = 1057;
        public static final int secDuygu = 1058;
        public static final int secLook = 1059;
        public static final int secOzel = 1060;
        public static final int secRegion = 1061;
        public static final int secSes = 1062;
        public static final int secSettings = 1063;
        public static final int segMode = 1064;
        public static final int tileAi = 1065;
        public static final int tileDict = 1066;
        public static final int tileLook = 1067;
        public static final int tileRegion = 1068;
        public static final int tvAyarBaslik = 1069;
        public static final int tvDogalDurum = 1070;
        public static final int tvDuyguDurum = 1071;
        public static final int tvDuyguOrnek = 1072;
        public static final int tvDuyguSiddet = 1073;
        public static final int tvOzelDurum = 1074;
        public static final int tvSesAkisOzet = 1075;
        public static final int tvSesCinsiyetOzet = 1076;
        public static final int tvYanSag = 1077;
        public static final int tvYanSol = 1078;
    }
    public static final class layout {
        public static final int activity_main = 1;
    }
    public static final class color {
        public static final int lingo_ok = 1, lingo_warn = 2, lingo_bad = 3,
            lingo_primary = 4, lingo_on_primary = 5, lingo_on_surface_variant = 6;
    }
    public static final class drawable {
        public static final int tv_odak = 1, bg_seg_on = 2, bg_seg_off = 3;
    }
}
