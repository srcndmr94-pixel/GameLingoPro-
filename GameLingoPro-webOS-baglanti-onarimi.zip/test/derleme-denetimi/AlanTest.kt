/** processMenu alan filtresinin birebir mantigi. */
fun icerdeMi(relX: Float, relY: Float, acik: Boolean,
             l: Int, t: Int, r: Int, b: Int, subtitleTop: Float, menuZone: Float): Boolean {
    if (acik) {
        if (relY < t / 100f) return false
        if (relY > b / 100f) return false
        if (relX < l / 100f) return false
        if (relX > r / 100f) return false
        if (relY >= subtitleTop) return false
        return true
    }
    return relY < minOf(subtitleTop, menuZone)
}

var gecti = 0; var kaldi = 0
fun dogru(ad: String, ok: Boolean) {
    if (ok) { gecti++; println("  OK   $ad") } else { kaldi++; println("  HATA $ad") }
}

fun main() {
    val ust = 0.74f; val zone = 0.5f
    println("== Alan KAPALI: eski davranis birebir ==")
    dogru("ust yarida okunur", icerdeMi(0.5f, 0.2f, false, 0,0,100,50, ust, zone))
    dogru("yarinin altinda okunmaz", !icerdeMi(0.5f, 0.6f, false, 0,0,100,50, ust, zone))
    dogru("altyazi seridinde okunmaz", !icerdeMi(0.5f, 0.8f, false, 0,0,100,50, ust, zone))

    println("== Alan ACIK: sag kenar secilmis (yatay %70-100, dikey %10-65) ==")
    val l=70; val t=10; val r=100; val b=65
    dogru("sagda, aralikta: okunur", icerdeMi(0.85f, 0.30f, true, l,t,r,b, ust, zone))
    dogru("solda: okunmaz", !icerdeMi(0.20f, 0.30f, true, l,t,r,b, ust, zone))
    dogru("cok yukarida: okunmaz", !icerdeMi(0.85f, 0.05f, true, l,t,r,b, ust, zone))
    dogru("cok asagida: okunmaz", !icerdeMi(0.85f, 0.70f, true, l,t,r,b, ust, zone))
    dogru("tam sag kenar: okunur", icerdeMi(1.0f, 0.30f, true, l,t,r,b, ust, zone))

    println("== Alan ACIK: ustun yarisindan asagisi da okunabilir (eski kuralin yapamadigi) ==")
    dogru("relY 0.60 okunur (eskiden okunmuyordu)", icerdeMi(0.85f, 0.60f, true, l,t,r,b, ust, zone))
    dogru("ayni nokta alan kapaliyken okunmaz", !icerdeMi(0.85f, 0.60f, false, l,t,r,b, ust, zone))

    println("== Altyazi seridi her durumda disarida ==")
    dogru("alan altyaziya tassa bile okunmaz",
        !icerdeMi(0.85f, 0.80f, true, 70,10,100,95, ust, zone))

    println("== Sol kenar secilmesi ==")
    dogru("solda okunur", icerdeMi(0.10f, 0.40f, true, 0,10,30,65, ust, zone))
    dogru("sagda okunmaz", !icerdeMi(0.90f, 0.40f, true, 0,10,30,65, ust, zone))

    println()
    println("ALAN TESTI -> Gecti: $gecti · Kaldi: $kaldi")
    if (kaldi > 0) kotlin.system.exitProcess(1)
}
