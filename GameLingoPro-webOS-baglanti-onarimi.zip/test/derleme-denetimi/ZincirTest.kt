import com.example.altyazi.CeviriZinciriDenetim

fun main() {
    val z = CeviriZinciriDenetim()
    var gecti = 0
    var kaldi = 0
    fun esit(ad: String, b: String, g: String) {
        if (b == g) gecti++ else { kaldi++; println("  KALDI: $ad beklenen=<$b> gercek=<$g>") }
    }
    println("== tam zincir: kullanicinin gercek satirlari ==")
    esit("After you", "Jason: Önce sen.", z.render("Jason: After you.", "Jason: Önce siz."))
    esit("Through there", "Jason: Şurada.", z.render("Jason: Through there.", "Jason: Oradan geçin."))
    esit("You calling", "Jason: Hıh. Bir şey için mi aradın?",
        z.render("Jason: Uh-huh. You calling about something?", "Jason: Hıh. Bir şey için mi aradınız?"))
    esit("imagination", "Jason: eğer hayal gücünü kullanırsan...",
        z.render("Jason: if you use your imagination..", "Jason: eğer hayal gücünüzü kullanırsanız..."))
    esit("bring it back", "Donnie: Bak, ürünü bulduğunda, onu buraya getir, tamam?",
        z.render("Donnie: Look, just when you find the product, bring it back here, okay?",
            "Donnie: Bak, ürünü bulduğunuzda, onu buraya getirin, tamam?"))
    esit("fuck yeah", "Jason: Oh, evet be!", z.render("Jason: Ooh, fuck yeah.", "Jason: Ooh, sikiş evet."))
    esit("the fuck you going", "Lucia: Nereye gidiyorsun lan?",
        z.render("Lucia: The fuck you going?", "Lucia: Siktir git gidiyor mu?"))
    esit("Whoops", "Lucia: Hoop, köpek!", z.render("Lucia: Whoops, dog!", "Lucia: Whoops, köpek!"))
    esit("jailbird", "Donnie: Dün gece o eski mahkûm yanında seni görmek tatlıydı.",
        z.render("Donnie: So fuckin' cute seeing you round your jailbird last night.",
            "Donnie: Dün gece o hırsızın yanında seni görmek tatlıydı."))
    esit("cogul korunur", "Kenton: Bu takım elbiseler size uygun mu?",
        z.render("Kenton: Those suits okay for you, boys?", "Kenton: Bu takım elbiseler size uygun mu?"))
    esit("ilgisiz satir", "Lucia: Bu ne?", z.render("Lucia: What's this?", "Lucia: Bu ne?"))

    println("== kaynak zinciri ==")
    esit("Y-you", "you flew the plane?", z.kaynakZinciri("Y-you flew the plane?"))
    esit("Butiyou", "But you don't...", z.kaynakZinciri("Butiyou don't..."))
    z.kaynakZinciri("Lucia: Just play.")
    esit("eksik iki nokta", "Lucia: Stop!", z.kaynakZinciri("Lucia Stop!"))
    esit("saglam satir", "Jason: Hey, be careful!", z.kaynakZinciri("Jason: Hey, be careful!"))

    println()
    println("GECTI: $gecti   KALDI: $kaldi")
    if (kaldi > 0) System.exit(1)
}
