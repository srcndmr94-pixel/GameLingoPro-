import com.example.altyazi.HitapTekil

var gecti = 0
var kaldi = 0
fun kontrol(ad: String, k: Boolean, ek: String = "") {
    if (k) gecti++ else { kaldi++; println("  KALDI: $ad  $ek") }
}
fun esit(ad: String, b: Any?, g: Any?) = kontrol(ad, b == g, "beklenen=<$b> gercek=<$g>")

fun main() {
    println("== kullanicinin kaydindaki gercek hatalar ==")
    esit("After you", "Önce sen.", HitapTekil.duzelt("After you.", "Önce siz."))
    esit("Through there", "Oradan geç.", HitapTekil.duzelt("Through there.", "Oradan geçin."))
    esit("You calling about something?", "Hıh. Bir şey için mi aradın?",
        HitapTekil.duzelt("Uh-huh. You calling about something?", "Hıh. Bir şey için mi aradınız?"))
    esit("use your imagination", "eğer hayal gücünü kullanırsan...",
        HitapTekil.duzelt("if you use your imagination..", "eğer hayal gücünüzü kullanırsanız..."))
    esit("bring it back here", "Bak, ürünü bulduğunda, onu buraya getir, Brian'e değil, tamam?",
        HitapTekil.duzelt(
            "Look, just when you find the product, bring it back here, not to Brian, okay?",
            "Bak, ürünü bulduğunuzda, onu buraya getirin, Brian'e değil, tamam?"))

    println("== zamirler ==")
    esit("siz", "sen", HitapTekil.tekille("siz"))
    esit("Siz buyuk harf", "Sen", HitapTekil.tekille("Siz"))
    esit("sizi", "seni", HitapTekil.tekille("sizi"))
    esit("size", "sana", HitapTekil.tekille("size"))
    esit("sizin", "senin", HitapTekil.tekille("sizin"))
    esit("sizinle", "seninle", HitapTekil.tekille("sizinle"))
    esit("sizce", "sence", HitapTekil.tekille("sizce"))
    esit("cumle icinde", "Bu sana kalmış.", HitapTekil.tekille("Bu size kalmış."))

    println("== kesin cekimler ==")
    esit("hazirsiniz", "hazırsın", HitapTekil.tekille("hazırsınız"))
    esit("iyisiniz", "iyisin", HitapTekil.tekille("iyisiniz"))
    esit("geliyorsunuz", "geliyorsun", HitapTekil.tekille("geliyorsunuz"))
    esit("aradiniz", "aradın", HitapTekil.tekille("aradınız"))
    esit("gittiniz", "gittin", HitapTekil.tekille("gittiniz"))
    esit("gordunuz", "gördün", HitapTekil.tekille("gördünüz"))
    esit("gidecegsiniz", "gideceksin", HitapTekil.tekille("gideceksiniz"))
    esit("yapacaksiniz", "yapacaksın", HitapTekil.tekille("yapacaksınız"))
    esit("gitmelisiniz", "gitmelisin", HitapTekil.tekille("gitmelisiniz"))
    esit("yapmalisiniz", "yapmalısın", HitapTekil.tekille("yapmalısınız"))
    esit("misiniz", "iyi misin", HitapTekil.tekille("iyi misiniz"))
    esit("musunuz", "duyuyor musun", HitapTekil.tekille("duyuyor musunuz"))
    esit("hal eki ile", "hazırsındır", HitapTekil.tekille("hazırsınızdır"))

    println("== iyelik ==")
    esit("gucunuzu", "gücünü", HitapTekil.tekille("gücünüzü"))
    esit("evinizde", "evinde", HitapTekil.tekille("evinizde"))
    esit("arkadasiniza", "arkadaşına", HitapTekil.tekille("arkadaşınıza"))
    esit("kafaniza", "kafana", HitapTekil.tekille("kafanıza"))

    println("== YASAK: bozulmamasi gerekenler ==")
    esit("deniz", "deniz", HitapTekil.tekille("deniz"))
    esit("denizde", "denizde", HitapTekil.tekille("denizde"))
    esit("denize", "denize", HitapTekil.tekille("denize"))
    esit("yalniz", "yalnız", HitapTekil.tekille("yalnız"))
    esit("yalnizca", "yalnızca", HitapTekil.tekille("yalnızca"))
    esit("yalnizlik", "yalnızlık", HitapTekil.tekille("yalnızlık"))
    esit("geniz", "genizden", HitapTekil.tekille("genizden"))
    esit("beniz", "benizde", HitapTekil.tekille("benizde"))
    esit("temiz", "temizle", HitapTekil.tekille("temizle"))
    esit("serin", "serin", HitapTekil.tekille("serin"))
    esit("derin", "derin", HitapTekil.tekille("derin"))
    esit("icin", "için", HitapTekil.tekille("için"))
    esit("benim", "benim", HitapTekil.tekille("benim"))
    esit("sensiz", "sensiz", HitapTekil.tekille("sensiz"))
    esit("evsiz", "evsiz", HitapTekil.tekille("evsiz"))
    esit("iz", "iz", HitapTekil.tekille("iz"))
    esit("niz tek basina", "nız", HitapTekil.tekille("nız"))

    println("== supheli emirler: kanit yoksa dokunulmaz ==")
    esit("alin tek basina korunur", "Alın kanıyor.", HitapTekil.tekille("Alın kanıyor."))
    esit("gelin tek basina korunur", "Gelin geldi.", HitapTekil.tekille("Gelin geldi."))
    esit("sorun tek basina korunur", "Sorun ne?", HitapTekil.tekille("Sorun ne?"))
    kontrol("kanit varsa supheli emir de cevrilir",
        HitapTekil.tekille("Sizi bekliyorum, gelin.") == "Seni bekliyorum, gel.",
        HitapTekil.tekille("Sizi bekliyorum, gelin."))
    kontrol("kesin cekim kanit sayilir",
        HitapTekil.tekille("Hazırsınız, alın şunu.") == "Hazırsın, al şunu.",
        HitapTekil.tekille("Hazırsınız, alın şunu."))

    println("== kesin emirler: kanit gerekmez ==")
    esit("gecin", "Geç.", HitapTekil.tekille("Geçin."))
    esit("getirin", "Getir.", HitapTekil.tekille("Getirin."))
    esit("bakin", "Bak.", HitapTekil.tekille("Bakın."))
    esit("bekleyin", "Bekle.", HitapTekil.tekille("Bekleyin."))
    esit("dinleyin", "Dinle.", HitapTekil.tekille("Dinleyin."))
    esit("cekilin", "Çekil!", HitapTekil.tekille("Çekilin!"))
    esit("unutmayin", "Unutma.", HitapTekil.tekille("Unutmayın."))
    esit("affedersiniz", "Affedersin.", HitapTekil.tekille("Affedersiniz."))

    println("== COGUL KORUNUR: kaynak cok kisiye sesleniyor ==")
    esit("you guys", "Size uygun mu?", HitapTekil.duzelt("You guys okay with that?", "Size uygun mu?"))
    esit("boys", "Bu takım elbiseler size uygun mu?",
        HitapTekil.duzelt("Those suits okay for you, boys?", "Bu takım elbiseler size uygun mu?"))
    esit("everyone", "Hepiniz hazır mısınız?",
        HitapTekil.duzelt("Is everyone ready?", "Hepiniz hazır mısınız?"))
    esit("y'all", "Nasılsınız?", HitapTekil.duzelt("How y'all doing?", "Nasılsınız?"))
    esit("all of you", "Sizi görüyorum.", HitapTekil.duzelt("I see all of you.", "Sizi görüyorum."))
    esit("guys", "Beni iyi dinleyin.", HitapTekil.duzelt("Okay, guys, listen here.", "Beni iyi dinleyin."))
    esit("ladies", "Buyurun.", HitapTekil.duzelt("After you, ladies.", "Buyurun."))
    kontrol("tekilMi: guys -> false", !HitapTekil.tekilMi("Hey guys"))
    kontrol("tekilMi: normal -> true", HitapTekil.tekilMi("After you."))
    kontrol("tekilMi: bos -> true", HitapTekil.tekilMi(""))
    kontrol("tekilMi: null -> true", HitapTekil.tekilMi(null))
    kontrol("guysy icinde gecmez", HitapTekil.tekilMi("The guysy thing"))

    println("== sart kipi ve 1. cogul korunmasi ==")
    esit("kullanirsaniz", "kullanırsan", HitapTekil.tekille("kullanırsanız"))
    esit("yapsaniz", "yapsan", HitapTekil.tekille("yapsanız"))
    esit("gitseniz", "gitsen", HitapTekil.tekille("gitseniz"))
    esit("deseniz", "desen", HitapTekil.tekille("deseniz"))
    esit("yorgunuz korunur", "Yorgunuz.", HitapTekil.tekille("Yorgunuz."))
    esit("memnunuz korunur", "Memnunuz.", HitapTekil.tekille("Memnunuz."))
    esit("eminiz korunur", "Eminiz.", HitapTekil.tekille("Eminiz."))
    esit("geliyoruz korunur", "Geliyoruz.", HitapTekil.tekille("Geliyoruz."))
    esit("eviniz yalin dokunulmaz", "eviniz", HitapTekil.tekille("eviniz"))

    println("== sinirlar ==")
    esit("bos ceviri", "", HitapTekil.duzelt("x", ""))
    esit("null ceviri", "", HitapTekil.duzelt("x", null))
    esit("noktalama korunur", "Sen, sana, senin!", HitapTekil.tekille("Siz, size, sizin!"))
    esit("dokunulmayan cumle", "Bugün hava çok güzel.", HitapTekil.tekille("Bugün hava çok güzel."))
    esit("kesme isareti", "Brian'e", HitapTekil.tekille("Brian'e"))
    esit("sayi ve isaret", "3 kişi — tamam?", HitapTekil.tekille("3 kişi — tamam?"))

    println()
    println("GECTI: $gecti   KALDI: $kaldi")
    if (kaldi > 0) System.exit(1)
}
