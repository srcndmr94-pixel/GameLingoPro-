import com.example.altyazi.DeyimDuzelt

var gecti = 0
var kaldi = 0
fun kontrol(ad: String, k: Boolean, ek: String = "") {
    if (k) gecti++ else { kaldi++; println("  KALDI: $ad  $ek") }
}
fun esit(ad: String, b: Any?, g: Any?) = kontrol(ad, b == g, "beklenen=<$b> gercek=<$g>")

fun main() {
    println("== kaynak onarimi (kekeleme ve OCR) ==")
    esit("Y-you", "you flew the plane?", DeyimDuzelt.kaynakOnar("Y-you flew the plane?"))
    esit("I-I", "I don't know", DeyimDuzelt.kaynakOnar("I-I don't know"))
    esit("w-what", "what?", DeyimDuzelt.kaynakOnar("w-what?"))
    esit("Butiyou", "But you don't...", DeyimDuzelt.kaynakOnar("Butiyou don't..."))
    esit("Yyou", "You flew", DeyimDuzelt.kaynakOnar("Yyou flew"))
    esit("youlre", "you're late", DeyimDuzelt.kaynakOnar("youlre late"))
    esit("A'ight -> alright", "alright. Let's go.", DeyimDuzelt.kaynakOnar("aight. Let's go."))
    esit("saglam satir degismez", "Hey, Mario!", DeyimDuzelt.kaynakOnar("Hey, Mario!"))
    esit("bos", "", DeyimDuzelt.kaynakOnar(""))
    esit("null", "", DeyimDuzelt.kaynakOnar(null))
    esit("tire korunur", "well-known guy", DeyimDuzelt.kaynakOnar("well-known guy"))
    esit("ayni harf olmayan tire", "T-shirt", DeyimDuzelt.kaynakOnar("T-shirt"))

    println("== bas sozcuk (kaynak kanitli) ==")
    esit("Well", "Yani, erkenden çıktın",
        DeyimDuzelt.basOnar("Well, you got out early", "Well, erkenden çıktın"))
    esit("Whoops", "Hoop, köpek!", DeyimDuzelt.basOnar("Whoops, dog!", "Whoops, köpek!"))
    esit("Look", "Bak, ürünü bul", DeyimDuzelt.basOnar("Look, just find the product", "Look, ürünü bul"))
    kontrol("kaynak baska sozcukle basliyorsa dokunulmaz",
        DeyimDuzelt.basOnar("Hey, listen", "Sorun ne?") == "Sorun ne?")
    kontrol("Turkce Sorun kesilmez",
        DeyimDuzelt.basOnar("What's the problem?", "Sorun ne?") == "Sorun ne?")
    kontrol("tabloda olmayan sozcuk dokunulmaz",
        DeyimDuzelt.basOnar("Mario, come here", "Mario, buraya gel") == "Mario, buraya gel")

    println("== deyim: tam satir ==")
    esit("fuck yeah", "Oh, evet be!", DeyimDuzelt.deyim("Ooh, fuck yeah.", "Ooh, sikiş evet."))
    esit("fuck yeah onek korunur", "Jason: Oh, evet be!",
        DeyimDuzelt.deyim("Jason: Ooh, fuck yeah.", "Jason: Ooh, sikiş evet."))
    esit("the fuck you going", "Lucia: Nereye gidiyorsun lan?",
        DeyimDuzelt.deyim("Lucia: The fuck you going?", "Lucia: Siktir git gidiyor mu?"))
    esit("picked up", "Jason: Öyle aldığım bir şey.",
        DeyimDuzelt.deyim("Jason: It's just something I picked up.",
            "Jason: Sadece bir şekilde öğrenmiş olduğum bir şey."))
    esit("holding up", "Jason: Dayanıyorlar.",
        DeyimDuzelt.deyim("Jason: They're hold in' up.", "Jason: İşleri gecikiyor."))
    esit("go round missing", "Donnie: Bunları kaybetmek olmaz.",
        DeyimDuzelt.deyim("Donnie: can't go round missing those.", "Donnie: Eyvah, - Bunları kaçırmaya gidemez."))
    esit("after you", "Jason: Önce sen.", DeyimDuzelt.deyim("Jason: After you.", "Jason: Önce siz."))
    esit("through there", "Jason: Şurada.", DeyimDuzelt.deyim("Jason: Through there.", "Jason: Oradan geçin."))
    esit("work detail", "Lucia: Kamu hizmeti.", DeyimDuzelt.deyim("Lucia: Work detail.", "Lucia: Çalışma ayrıntıları."))
    esit("koseli onek korunur", "[Jason] Önce sen.", DeyimDuzelt.deyim("[Jason] After you.", "[Jason] Önce siz."))

    println("== deyim: parca degisimi ==")
    esit("jailbird", "Dün gece o eski mahkûm yanında seni görmek tatlıydı.",
        DeyimDuzelt.deyim("So fuckin' cute seeing you round your jailbird last night.",
            "Dün gece o hırsızın yanında seni görmek tatlıydı."))
    esit("them others", "Cal, diğerlerini bulmak için çalışıyor",
        DeyimDuzelt.deyim("radio genius Cal is working on finding them others",
            "Cal, onlara başkalarını bulmak için çalışıyor"))
    esit("the aviators", "O Aviator'ları ile ilgili saçmalık",
        DeyimDuzelt.deyim("After that bullshit with the aviators",
            "O aviator gözlükleri ile ilgili saçmalık"))
    esit("mr fuckin busy", "Ah! Bay Çok Meşgul.",
        DeyimDuzelt.deyim("Oh! Mr. Fuckin' Busy.", "Ah! Bay Siktiğimin meşgul."))

    println("== KAYNAK KANITI OLMADAN DOKUNULMAZ ==")
    esit("gercek hirsiz korunur", "Hırsızı yakaladılar.",
        DeyimDuzelt.deyim("They caught the thief.", "Hırsızı yakaladılar."))
    esit("gercek gozluk korunur", "Aviator gözlükleri güzelmiş.",
        DeyimDuzelt.deyim("Those aviator sunglasses are nice.", "Aviator gözlükleri güzelmiş."))
    esit("gercek calisma ayrintisi korunur", "Çalışma ayrıntıları ekte.",
        DeyimDuzelt.deyim("The work details are attached.", "Çalışma ayrıntıları ekte."))
    esit("ilgisiz satir korunur", "Bugün hava güzel.",
        DeyimDuzelt.deyim("Nice weather today.", "Bugün hava güzel."))
    esit("kaynak null ise dokunulmaz", "Ooh, sikiş evet.", DeyimDuzelt.deyim(null, "Ooh, sikiş evet."))

    println("== birlesik duzelt ==")
    esit("deyim + bas sozcuk", "Hoop, köpek!", DeyimDuzelt.duzelt("Whoops, dog!", "Whoops, köpek!"))
    esit("bos ceviri", "", DeyimDuzelt.duzelt("x", ""))
    esit("null ceviri", "", DeyimDuzelt.duzelt("x", null))

    println("== onek yardimcilari ==")
    esit("adiAt iki nokta", "After you.", DeyimDuzelt.adiAt("Jason: After you."))
    esit("adiAt koseli", "After you.", DeyimDuzelt.adiAt("[Jason] After you."))
    esit("adiAt onek yok", "After you.", DeyimDuzelt.adiAt("After you."))
    esit("onekAl iki nokta", "Jason: ", DeyimDuzelt.onekAl("Jason: After you."))
    esit("onekAl koseli", "[Jason] ", DeyimDuzelt.onekAl("[Jason] After you."))
    esit("onekAl yok", "", DeyimDuzelt.onekAl("After you."))

    println()
    println("GECTI: $gecti   KALDI: $kaldi")
    if (kaldi > 0) System.exit(1)
}
