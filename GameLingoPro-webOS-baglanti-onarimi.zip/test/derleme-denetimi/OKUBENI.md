# Derleme denetimi

Bu klasör, sesli okuma kodunun **gerçekten derlendiğini** ve **gerçek
sınıfların doğru çalıştığını** göstermek için kullanıldı.

## Nasıl yapıldı

Kotlin derleyicisi (kotlinc 2.0.21) indirildi. Android SDK olmadığı için
kullanılan Android sınıflarının **Java taklitleri** yazıldı (`jtaklit/`).
Taklitlerin Java olması önemli: Kotlin, Java sınıflarını "platform tipi"
olarak gördüğü için denetim gerçek SDK'daki gibi davranır. (İlk denemede
taklitler Kotlin yazılmıştı ve gerçekte olmayan dört tip hatası üretti.)

## Derlenen dosyalar — hepsi temiz

- `SesPerdeOlcer.kt`, `SesHavuzu.kt`, `KonusanCinsiyeti.kt`, `KarakterSesi.kt`
  — Android bağımlılığı yok, doğrudan derlendi
- `SesliOku.kt` — Java taklitleriyle derlendi
- `Prefs.kt` — derlendi
- `MainActivitySesDenetim.kt` — MainActivity'nin değiştirilen on ses
  fonksiyonu, gerçek gövdeleriyle
- `CaptureServiceSesDenetim.kt` — CaptureService'in değiştirilen dört
  fonksiyonu, gerçek gövdeleriyle

Tek çıktı: `Locale("tr","TR")` için JDK 21 kullanımdan kaldırma uyarısı.
Android'de bu yapıcı kullanımdan kaldırılmış değil; hata değil.

## GercekTest.kt

Önceki testler Java kopyalarını sınıyordu. Bu test uygulamanın **kendi
Kotlin sınıflarını** çağırıyor: 56 kontrol, hepsi geçti.

Çalıştırma:

    kotlinc jtaklit-derlenmis-sinif-yolu ...
    kotlinc GercekTest.kt -cp "jout:sesli.jar" -include-runtime -d gercek.jar
    java -cp "gercek.jar:sesli.jar:jout" GercekTestKt
