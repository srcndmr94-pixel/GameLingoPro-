import com.example.altyazi.OzelAyar

var gecti = 0
var kaldi = 0
fun kontrol(ad: String, k: Boolean, ek: String = "") {
    if (k) { gecti++ } else { kaldi++; println("  KALDI: $ad  $ek") }
}
fun esit(ad: String, b: Any?, g: Any?) = kontrol(ad, b == g, "beklenen=<$b> gercek=<$g>")

fun main() {
    println("== tur eslemesi ==")
    esit("anahtar", OzelAyar.T_ANAHTAR, OzelAyar.tur("anahtar"))
    esit("switch", OzelAyar.T_ANAHTAR, OzelAyar.tur("switch"))
    esit("ac-kapa", OzelAyar.T_ANAHTAR, OzelAyar.tur("Aç-Kapa"))
    esit("kaydirak", OzelAyar.T_KAYDIRAK, OzelAyar.tur("kaydırak"))
    esit("slider", OzelAyar.T_KAYDIRAK, OzelAyar.tur("Slider"))
    esit("yuzde", OzelAyar.T_KAYDIRAK, OzelAyar.tur("yüzde"))
    esit("sayi", OzelAyar.T_SAYI, OzelAyar.tur("sayı"))
    esit("number", OzelAyar.T_SAYI, OzelAyar.tur("number"))
    esit("liste", OzelAyar.T_LISTE, OzelAyar.tur("liste"))
    esit("secim", OzelAyar.T_LISTE, OzelAyar.tur("seçim"))
    esit("yazi", OzelAyar.T_YAZI, OzelAyar.tur("yazı"))
    esit("taninmayan yaziya duser", OzelAyar.T_YAZI, OzelAyar.tur("zırt pırt"))

    println("== anahtar adi ==")
    esit("turkce harf sadelesir", "ozel_kufru_yumusat", OzelAyar.anahtarAdi("Küfrü yumuşat"))
    esit("ayni ayar tek anahtar", OzelAyar.anahtarAdi("Küfrü yumuşat"), OzelAyar.anahtarAdi("KÜFRÜ YUMUŞAT"))
    esit("bosluk alt cizgi", "ozel_altyazi_gecikmesi", OzelAyar.anahtarAdi("Altyazı gecikmesi"))
    kontrol("onek var", OzelAyar.anahtarAdi("X").startsWith("ozel_"))

    println("== noktali virgul ==")
    val a = OzelAyar.coz("Altyazı gecikmesi;kaydırak;0;Ekran alanı")
    esit("tek satir", 1, a.size)
    esit("ad", "Altyazı gecikmesi", a[0].ad)
    esit("tur", OzelAyar.T_KAYDIRAK, a[0].tur)
    esit("varsayilan", "0", a[0].varsayilan)
    esit("bolum", "Ekran alanı", a[0].bolum)
    esit("sayi degeri", 0, a[0].varsayilanSayi)

    println("== virgul ve sekme ==")
    esit("virgul", 1, OzelAyar.coz("Satır sayısı,sayı,2,Görünüm").size)
    esit("sekme", 1, OzelAyar.coz("Satır sayısı\tsayı\t2\tGörünüm").size)
    esit("sekme bolum", "Görünüm", OzelAyar.coz("Satır sayısı\tsayı\t2\tGörünüm")[0].bolum)
    esit("tirnak atilir", "Satır sayısı", OzelAyar.coz("\"Satır sayısı\";sayı;2;Görünüm")[0].ad)

    println("== baslik ve yorum ==")
    val b = OzelAyar.coz("# yorum\nAd;Tür;Varsayılan;Bölüm\nKüfrü yumuşat;anahtar;kapalı;Dil\n\n")
    esit("baslik ve yorum atlandi", 1, b.size)
    esit("kalan satir", "Küfrü yumuşat", b[0].ad)
    esit("kapali -> false", false, b[0].varsayilanAcik)
    esit("acik -> true", true, OzelAyar.coz("X;anahtar;açık;Y")[0].varsayilanAcik)
    esit("evet -> true", true, OzelAyar.coz("X;anahtar;evet;Y")[0].varsayilanAcik)
    esit("1 -> true", true, OzelAyar.coz("X;anahtar;1;Y")[0].varsayilanAcik)
    esit("true -> true", true, OzelAyar.coz("X;anahtar;TRUE;Y")[0].varsayilanAcik)

    println("== liste secenekleri ==")
    val l = OzelAyar.coz("Fısıltı sesi;liste;ahm-local|efu-local|ede-local;Sesli okuma")
    esit("secenek sayisi", 3, l[0].secenekler.size)
    esit("ilk secenek varsayilan", "ahm-local", l[0].varsayilan)
    esit("besinci sutun secenek", 2,
        OzelAyar.coz("X;liste;a;Y;a|b")[0].secenekler.size)
    esit("tek secenek", 1, OzelAyar.coz("X;liste;tek;Y")[0].secenekler.size)

    println("== sinirlar ==")
    esit("bos metin", 0, OzelAyar.coz("").size)
    esit("null", 0, OzelAyar.coz(null).size)
    esit("adsiz satir atlanir", 0, OzelAyar.coz(";anahtar;açık;Y").size)
    esit("tek sutun da gecerli", 1, OzelAyar.coz("Sadece ad").size)
    esit("tek sutun turu yazi", OzelAyar.T_YAZI, OzelAyar.coz("Sadece ad")[0].tur)
    esit("bolum bossa Diger", "Diğer", OzelAyar.coz("Sadece ad")[0].bolum)
    esit("ayni ad iki kez tek kayit", 1, OzelAyar.coz("X;anahtar;1;A\nX;sayı;2;B").size)
    esit("eksi sayi", -5, OzelAyar.coz("X;sayı;-5;Y")[0].varsayilanSayi)
    esit("yuzde isaretli", 70, OzelAyar.coz("X;kaydırak;%70;Y")[0].varsayilanSayi)
    esit("sayisiz varsayilan 0", 0, OzelAyar.coz("X;sayı;yok;Y")[0].varsayilanSayi)

    println("== bolumleme ==")
    val c = OzelAyar.coz(
        "A;anahtar;1;Ekran alanı\nB;sayı;2;Sesli okuma\nC;anahtar;0;Ekran alanı"
    )
    val g = OzelAyar.bolumler(c)
    esit("iki bolum", 2, g.size)
    esit("ilk bolum sirasi", "Ekran alanı", g[0].first)
    esit("ilk bolum iki ayar", 2, g[0].second.size)
    esit("ikinci bolum", "Sesli okuma", g[1].first)

    println("== sablon ==")
    val sab = OzelAyar.coz(OzelAyar.sablon())
    esit("sablon 5 ayar", 5, sab.size)
    kontrol("sablon turleri taninir", sab.all { it.tur != OzelAyar.T_YAZI || it.ad == "" },
        sab.joinToString { it.ad + "=" + it.tur })
    kontrol("ozet bos", OzelAyar.ozet(emptyList()).contains("yüklenmedi"))
    kontrol("ozet dolu", OzelAyar.ozet(sab).contains("5 ayar"), OzelAyar.ozet(sab))

    println()
    println("GECTI: $gecti   KALDI: $kaldi")
    if (kaldi > 0) System.exit(1)
}
