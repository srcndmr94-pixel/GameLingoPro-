import com.example.altyazi.SesAkisi

/**
 * GERÇEK KAYIT TESTİ
 *
 * Kullanıcının 19 Kasım 2026 ses çalışma kaydındaki 15 TAM okumanın
 * ölçülmüş değerleri. Tahminci bu ölçümlerden öğrendikten sonra aynı
 * replikleri ne kadar hatayla tahmin ediyor?
 *
 * 10.55'teki tek parametreli model bu veride ortalama 487 ms
 * yanılıyordu (uygulamanın o an verdiği tahminler). Bu test iki
 * parametreli modelin belirgin biçimde daha iyi olduğunu sabitler;
 * biri modeli bozarsa test düşer.
 */

// harf, hız, gerçek ms  —  kayıttan birebir
val OLCUMLER = listOf(
    Triple(39, 1.76f, 1800L),
    Triple(28, 1.61f, 1800L),
    Triple(12, 1.43f, 1100L),
    Triple(17, 1.43f, 1400L),
    Triple(20, 1.61f, 1400L),
    Triple(46, 1.52f, 2000L),
    Triple(33, 1.61f, 2000L),
    Triple(27, 1.52f, 1800L),
    Triple(30, 1.52f, 2100L),
    Triple(24, 1.43f, 1500L),
    Triple(35, 1.43f, 1900L),
    Triple(23, 1.34f, 1600L),
    Triple(16, 1.25f, 1200L),
    Triple(20, 1.15f, 2200L),
    Triple(11, 1.15f, 1100L),
)

var gecti = 0
var kaldi = 0
fun kontrol(ad: String, k: Boolean, ek: String = "") {
    if (k) gecti++ else { kaldi++; println("  KALDI: $ad  $ek") }
}

fun main() {
    val tc = SesAkisi.Tahminci()
    for ((harf, hiz, ms) in OLCUMLER) tc.ekle(harf, ms, hiz)

    println("ogrenilen: %.1f harf/sn · taban %.0f ms".format(tc.harfSn(), tc.tabanMs()))
    kontrol("harfSn makul aralikta (15-26)", tc.harfSn() in 15.0..26.0, tc.harfSn().toString())
    kontrol("taban makul aralikta (400-1300 ms)", tc.tabanMs() in 400.0..1300.0, tc.tabanMs().toString())

    var toplamHata = 0.0
    var enKotu = 0L
    println()
    println("%5s %6s %9s %9s %8s".format("harf", "hiz", "gercek", "tahmin", "hata"))
    for ((harf, hiz, ms) in OLCUMLER) {
        val t = tc.tahminMs("x".repeat(harf), hiz)
        val h = t - ms
        toplamHata += kotlin.math.abs(h).toDouble()
        if (kotlin.math.abs(h) > enKotu) enKotu = kotlin.math.abs(h)
        println("%5d %6.2f %7d ms %7d ms %+6d ms".format(harf, hiz, ms, t, h))
    }
    val ort = toplamHata / OLCUMLER.size
    println()
    println("ortalama mutlak hata: %.0f ms · en kotu %d ms".format(ort, enKotu))
    // 10.55'in gercek hatasi 487 ms'ydi.
    kontrol("ortalama hata 487 ms'den belirgin iyi (<260)", ort < 260.0, "%.0f ms".format(ort))
    kontrol("en kotu tahmin 700 ms'yi gecmiyor", enKotu < 700L, "$enKotu ms")

    // Tek parametreli eski model ayni veride ne yapiyordu?
    var eskiHata = 0.0
    for ((harf, hiz, ms) in OLCUMLER) {
        val eski = 250.0 + harf * 1000.0 / (10.4 * hiz)   // 10.55'in ogrendigi deger
        eskiHata += kotlin.math.abs(eski - ms)
    }
    val eskiOrt = eskiHata / OLCUMLER.size
    println("eski tek parametreli model ayni veride: %.0f ms".format(eskiOrt))
    kontrol("yeni model eskisinden iyi", ort < eskiOrt, "%.0f < %.0f".format(ort, eskiOrt))

    // Butce ve ongorulu hizlanma gercek araliklarla
    val ARALIKLAR = listOf(
        1066L, 2386L, 3099L, 3313L, 1743L, 2936L, 1309L, 2679L, 1829L, 1087L,
        615L, 472L, 344L, 2192L, 1160L, 3300L, 3201L, 5081L, 2717L, 2230L,
        7658L, 2021L, 3061L, 1251L, 2839L, 1264L, 2903L,
    )
    val ao = SesAkisi.AralikOlcer()
    for (a in ARALIKLAR) ao.ekle(a)
    println()
    println("gercek araliklar: ortanca %d ms · butce %d ms".format(ao.ortancaMs(), ao.butceMs()))
    kontrol("butce 1-3 sn arasi", ao.butceMs() in 1000L..3000L, ao.butceMs().toString())
    kontrol("butce ortancadan kucuk", ao.butceMs() < ao.ortancaMs())

    // 79 harflik en uzun replik: bastan hizlanmali
    val uzun = tc.tahminMs("x".repeat(79), 1.0f)
    val c = SesAkisi.ongoruluCarpan(uzun, ao.butceMs())
    println("79 harf -> tahmin %d ms · ongorulu carpan x%.2f".format(uzun, c))
    kontrol("en uzun replik bastan hizlanir", c == SesAkisi.EN_YUKSEK_CARPAN, c.toString())
    val kisa = tc.tahminMs("x".repeat(11), 1.0f)
    kontrol("11 harflik replik hizlanmaz", SesAkisi.ongoruluCarpan(kisa, ao.butceMs()) == 1f,
        SesAkisi.ongoruluCarpan(kisa, ao.butceMs()).toString())

    println()
    println("GECTI: $gecti   KALDI: $kaldi")
    if (kaldi > 0) System.exit(1)
}
