import com.example.altyazi.SesAkisi

/**
 * GERÇEK KAYIT BENZETİMİ
 *
 * Kullanıcının 19 Kasım ses kaydındaki 28 repliğin GERÇEK geliş
 * zamanları ve harf sayıları, uygulamanın GERÇEK karar fonksiyonundan
 * (SesAkisi.karar) geçirilir. Ses çıkışı dinlenemediği için en yakın
 * doğrulama bu: hangi modda kaç replik baştan sona okunuyor, kaçı
 * bölünüyor, kaçı hiç duyulmuyor.
 *
 * Replik süreleri, aynı kayıttan öğrenilen modelle hesaplanır:
 * 811 ms + (harf/hız) × 49,2 ms.
 */

// (geliş anı ms, harf) — kayıttan birebir
val GELIS = listOf(
    0L to 40, 1066L to 21, 3452L to 39, 6551L to 28, 9864L to 28,
    11607L to 12, 14543L to 39, 15852L to 17, 18531L to 25, 20360L to 52,
    21447L to 35, 22062L to 79, 22534L to 12, 22878L to 20, 25070L to 23,
    26230L to 46, 29530L to 33, 32731L to 27, 37812L to 30, 40529L to 24,
    42759L to 35, 50417L to 23, 52438L to 16, 55499L to 31, 56750L to 54,
    59589L to 36, 60853L to 20, 63756L to 11,
)

const val TABAN = 811.0
const val PER_HARF_SN = 20.3

fun gercekSure(harf: Int, hiz: Float): Long =
    SesAkisi.tahmin("x".repeat(harf), hiz, PER_HARF_SN, TABAN)

class Sonuc(val tam: Int, val kesik: Int, val atlanan: Int, val ortHiz: Double)

fun benzet(mod: Int): Sonuc {
    val tahminci = SesAkisi.Tahminci()
    val sayac = SesAkisi.Sayac()
    val aralikOlcer = SesAkisi.AralikOlcer()
    var okunuyor = false
    var bas = 0L
    var tahminAktif = 0L
    var harfAktif = 0
    var hizAktif = 1f
    var tam = 0
    var kesik = 0
    var atlanan = 0
    var hizToplam = 0.0
    var hizAdet = 0
    var sonGelis = -1L

    for ((an, harf) in GELIS) {
        // Okuma kendiliğinden bittiyse kapat ve öğrenmeye kat.
        if (okunuyor && an - bas >= tahminAktif) {
            val gercek = gercekSure(harfAktif, hizAktif)
            tahminci.ekle(harfAktif, gercek, hizAktif)
            sayac.replik(false, gercek, tahminAktif)
            tam++
            okunuyor = false
        }
        if (sonGelis >= 0L) aralikOlcer.ekle(an - sonGelis)
        sonGelis = an

        val metin = "x".repeat(harf)
        val tahmin = tahminci.tahminMs(metin, 1f)
        val gecen = if (okunuyor) an - bas else 0L
        val karar = SesAkisi.karar(
            mod, okunuyor, gecen, tahminAktif, sayac.oran(),
            yeniTahminMs = tahmin, butceMs = aralikOlcer.butceMs(),
        )
        if (!karar.oku) {
            atlanan++
            sayac.atlandi()
            continue
        }
        if (karar.kes && okunuyor) {
            kesik++
            sayac.replik(true, gecen, tahminAktif)
        }
        hizToplam += karar.hizCarpani
        hizAdet++
        harfAktif = harf
        hizAktif = karar.hizCarpani
        tahminAktif = gercekSure(harf, karar.hizCarpani)
        bas = an
        okunuyor = true
    }
    if (okunuyor) tam++
    return Sonuc(tam, kesik, atlanan, if (hizAdet == 0) 1.0 else hizToplam / hizAdet)
}

fun main() {
    println("gercek kayit: ${GELIS.size} replik · ${GELIS.last().first / 1000} sn")
    println()
    println("%-26s %5s %7s %9s %8s".format("mod", "tam", "bolunen", "duyulmayan", "ort.hiz"))
    for ((mod, ad) in listOf(
        SesAkisi.BITIR_ATLA to "cumleyi bitir+hizlan",
        SesAkisi.HIZLAN to "yalniz hizlan",
        SesAkisi.KES to "kes ve gec",
    )) {
        val s = benzet(mod)
        val n = GELIS.size
        println(
            "%-26s %4d%%%-2.0f %5d%%%-2.0f %7d%%%-2.0f %8.2f".format(
                ad, s.tam, s.tam * 100.0 / n, s.kesik, s.kesik * 100.0 / n,
                s.atlanan, s.atlanan * 100.0 / n, s.ortHiz
            )
        )
    }
    println()
    println("sayilar: adet ve yuzde")
}
