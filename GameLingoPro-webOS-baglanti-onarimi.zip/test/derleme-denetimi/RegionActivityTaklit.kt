package com.example.altyazi

/** YALNIZ DERLEME DENETIMI. */
class RegionActivity {
    companion object {
        const val EK_MENU_ALANI = "menuAlani"
        const val EK_ALAN = "alan"
        const val ALAN_ALTYAZI = "altyazi"
        const val ALAN_YAN = "yan"
        const val ALAN_SOL = "sol"
        const val ALAN_SAG = "sag"
    }
}
