import com.example.altyazi.KonusanIkiNokta as K

var gecti = 0
var kaldi = 0
fun kontrol(ad: String, k: Boolean, ek: String = "") { if (k) gecti++ else { kaldi++; println("  KALDI: $ad  $ek") } }
fun esit(ad: String, b: Any?, g: Any?) = kontrol(ad, b == g, "beklenen=<$b> gercek=<$g>")

fun main() {
    println("== ogrenme ==")
    K.temizle()
    esit("basta bos", "ad yok", K.durum())
    K.ogren("Lucia: Just play.")
    kontrol("iki noktali ad ogrenildi", "Lucia" in K.bilinenler(), K.durum())
    K.ogren("[Jeremy] That's it?")
    kontrol("koseli ad ogrenildi", "Jeremy" in K.bilinenler(), K.durum())
    K.ogren("Man in Black: No shape.")
    kontrol("uc sozcuklu ad", "Man in Black" in K.bilinenler(), K.durum())
    K.ogren("Bu sıradan bir cümle.")
    kontrol("sıradan cumleden ad ogrenilmez", K.bilinenler().size == 3, K.durum())
    K.ogren(null)
    K.ogren("")
    kontrol("null ve bos guvenli", K.bilinenler().size == 3)

    println("== onarim ==")
    esit("Lucia Stop! onarilir", "Lucia: Stop!", K.onar("Lucia Stop!"))
    esit("uzun cumle onarilir", "Lucia: First trip out since beautiful Juliana came through.",
        K.onar("Lucia First trip out since beautiful Juliana came through."))
    esit("koseli ad da onarilir", "Jeremy: Wait what?", K.onar("Jeremy Wait what?"))
    esit("uc sozcuklu ad onarilir", "Man in Black: No shape.", K.onar("Man in Black No shape."))

    println("== DOKUNULMAYANLAR ==")
    esit("bilinmeyen ad dokunulmaz", "Kenton First trip out.", K.onar("Kenton First trip out."))
    esit("zaten iki nokta var", "Lucia: Stop!", K.onar("Lucia: Stop!"))
    esit("zaten koseli", "[Lucia] Stop!", K.onar("[Lucia] Stop!"))
    esit("kucuk harfle baslayan dokunulmaz", "lucia Stop!", K.onar("lucia Stop!"))
    esit("ikinci sozcuk kucukse dokunulmaz", "Lucia stop!", K.onar("Lucia stop!"))
    esit("tek sozcuk dokunulmaz", "Lucia", K.onar("Lucia"))
    esit("bos", "", K.onar(""))
    esit("null", "", K.onar(null))
    esit("sıradan cumle", "Bu Ankara'da oldu.", K.onar("Bu Ankara'da oldu."))

    println("== isle: onar + ogren ==")
    K.temizle()
    esit("ad yoksa dokunulmaz", "Kat See you!", K.isle("Kat See you!"))
    K.isle("Kat: Have fun.")
    esit("sonra onarilir", "Kat: See you!", K.isle("Kat See you!"))

    println("== siniri asma ==")
    K.temizle()
    val harfler = ('A'..'Z').toList()
    val adlar = ArrayList<String>()
    for (a in harfler) for (b in harfler) if (adlar.size < 60) adlar.add("Ad$a$b")
    for (ad in adlar) K.ogren("$ad: merhaba.")
    kontrol("defter siniri", K.bilinenler().size <= 40, K.bilinenler().size.toString())
    kontrol("en yenisi defterde", adlar.last() in K.bilinenler(), adlar.last() + " / " + K.bilinenler().size)

    println()
    println("GECTI: $gecti   KALDI: $kaldi")
    if (kaldi > 0) System.exit(1)
}
