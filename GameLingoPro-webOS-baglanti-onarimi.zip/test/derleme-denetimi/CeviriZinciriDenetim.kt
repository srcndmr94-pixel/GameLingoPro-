package com.example.altyazi

/**
 * SALT DERLEME DENETIMI: 10.57'de degisen iki zincir, gercek
 * cagrilariyla. Cevresindeki nesneler taklit.
 */
object OfflineFixT { fun translate(s: String, f: (String) -> String?): String? = null }
object TurkishFixT { fun duzelt(s: String): String = s }
object NameFixT { fun koru(a: String, b: String): String = b }
object AiGuardT { fun hitapDuzelt(a: String, b: String): String = b }
object DialogueT { fun repair(a: String, b: String): String = b }
object OcrOnarT { fun onar(s: String): String = s }
object EtiketOnarT { fun onar(s: String): String = s }
object AdDefteriT { fun acikEtiketKapat(s: String): String = s }
object KonusanOnEkiT { fun uygula(s: String): String = s }
object TextFixT { fun clean(s: String): String = s }
object OcrTextCleanerT { fun clean(s: String): String = s }
object SoundTagsT { fun repair(s: String): String = s }
object SubtitlePreparationT { fun repair(s: String): String = s }

class CeviriZinciriDenetim {

    /** CaptureService.render ile BIREBIR ayni govde. */
    fun render(body: String, candidate: String): String =
        HitapTekil.duzelt(
            body,
            DeyimDuzelt.duzelt(
                body,
                DialogueT.repair(
                    body, AiGuardT.hitapDuzelt(body, NameFixT.koru(body, TurkishFixT.duzelt(candidate)))
                ),
            ),
        )

    /** CaptureService.clean'in degisen ilk iki satiri. */
    fun kaynakZinciri(raw: String): String {
        val onarilmis = KonusanIkiNokta.isle(DeyimDuzelt.kaynakOnar(raw))
        return SubtitlePreparationT.repair(SoundTagsT.repair(OcrTextCleanerT.clean(TextFixT.clean(
            KonusanOnEkiT.uygula(AdDefteriT.acikEtiketKapat(EtiketOnarT.onar(OcrOnarT.onar(onarilmis))))))))
    }
}
