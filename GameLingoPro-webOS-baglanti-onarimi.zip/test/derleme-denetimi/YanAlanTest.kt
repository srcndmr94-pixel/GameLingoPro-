import com.example.altyazi.YanAlan
import com.example.altyazi.YanAlan.Kutu
import com.example.altyazi.SesAkisi
import com.example.altyazi.SesHavuzu
import com.example.altyazi.DuyguSesi
import com.example.altyazi.TvYerlesim

var gecti = 0
var kaldi = 0
fun kontrol(ad: String, k: Boolean, ek: String = "") { if (k) gecti++ else { kaldi++; println("  KALDI: $ad  $ek") } }
fun esit(ad: String, b: Any?, g: Any?) = kontrol(ad, b == g, "beklenen=<$b> gercek=<$g>")

val SOL = Kutu(true, 0, 10, 30, 70)
val SAG = Kutu(true, 70, 10, 100, 70)
val KAPALI = Kutu(false, 0, 0, 100, 100)
const val ALT = 0.5f      // altyazı şeridi %50'den başlıyor
const val ZONE = 0.35f

fun main() {
    println("== iki ayri kutu ==")
    kontrol("solda yazi -> sol kutu", YanAlan.icinde(0.10f, 0.30f, ALT, false, ZONE, listOf(SOL, SAG)))
    kontrol("sagda yazi -> sag kutu", YanAlan.icinde(0.85f, 0.30f, ALT, false, ZONE, listOf(SOL, SAG)))
    kontrol("ortada yazi -> disarida", !YanAlan.icinde(0.50f, 0.30f, ALT, false, ZONE, listOf(SOL, SAG)))
    kontrol("solda ama cok yukarida", !YanAlan.icinde(0.10f, 0.05f, ALT, false, ZONE, listOf(SOL, SAG)))
    kontrol("yalniz sol acikken sag disarida",
        !YanAlan.icinde(0.85f, 0.30f, ALT, false, ZONE, listOf(SOL, SAG.copy(acik = false))))
    kontrol("yalniz sag acikken sag icerde",
        YanAlan.icinde(0.85f, 0.30f, ALT, false, ZONE, listOf(SOL.copy(acik = false), SAG)))

    println("== altyazi seridi her zaman dista ==")
    kontrol("seridin icindeki yazi atlanir",
        !YanAlan.icinde(0.10f, 0.60f, ALT, false, ZONE, listOf(SOL, SAG)))
    kontrol("menu modunda da serit dista",
        !YanAlan.icinde(0.50f, 0.60f, ALT, true, ZONE, listOf()))
    kontrol("tam serit sinirinda dista",
        !YanAlan.icinde(0.10f, 0.50f, ALT, false, ZONE, listOf(SOL)))

    println("== menu modu ==")
    kontrol("menu modu ortayi da tarar", YanAlan.icinde(0.50f, 0.30f, ALT, true, ZONE, listOf()))
    kontrol("menu modu kutulari yok sayar",
        YanAlan.icinde(0.50f, 0.45f, ALT, true, ZONE, listOf(SOL, SAG)))
    kontrol("menu modu en ustte de tarar", YanAlan.icinde(0.02f, 0.02f, ALT, true, ZONE, listOf()))

    println("== hic kutu yok: eski davranis ==")
    kontrol("ust bolge taranir", YanAlan.icinde(0.50f, 0.20f, ALT, false, ZONE, listOf(KAPALI)))
    kontrol("ust bolgenin altinda taranmaz", !YanAlan.icinde(0.50f, 0.40f, ALT, false, ZONE, listOf(KAPALI)))
    kontrol("bos liste de eski davranis", YanAlan.icinde(0.50f, 0.20f, ALT, false, ZONE, listOf()))

    println("== gecersiz kutu ==")
    val ters = Kutu(true, 80, 10, 20, 70)
    kontrol("ters kutu gecersiz", !ters.gecerli)
    kontrol("ters kutu yok sayilir, eski davranisa doner",
        YanAlan.icinde(0.50f, 0.20f, ALT, false, ZONE, listOf(ters)))
    kontrol("gecerli kutu", SOL.gecerli)
    esit("ozet kapali", "kapalı", YanAlan.ozet(KAPALI))
    esit("ozet gecersiz", "geçersiz seçim", YanAlan.ozet(ters))
    kontrol("ozet gecerli", YanAlan.ozet(SOL).contains("%0") && YanAlan.ozet(SOL).contains("%30"), YanAlan.ozet(SOL))

    println("== tekrar suzgeci ==")
    esit("ayni satir", true, SesAkisi.benzerMi(
        "Teşekkürler. Posta kutuna \$\$\$.", "teşekkürler. Posta kutunda \$\$\$."))
    esit("ucuncu bicim de ayni", true, SesAkisi.benzerMi(
        "Teşekkürler. Posta kutuna \$\$\$.", "Teşekkürler. Posta kutuna \$\$\$ gönderilecek."))
    esit("birebir ayni", true, SesAkisi.benzerMi("Üniversite korkaklar içindir", "Üniversite korkaklar içindir"))
    esit("farkli satirlar", false, SesAkisi.benzerMi(
        "Özür dilerim, seni uyandırdım mı?", "Fleeca, Laguna, Lane"))
    esit("kisa ve farkli", false, SesAkisi.benzerMi("hey", "eyvah"))
    kontrol("ortusme 0..1", SesAkisi.ortusme("a bb cc", "bb cc dd") in 0.0..1.0)
    val sz = SesAkisi.TekrarSuzgeci()
    esit("ilk kez okunur", false, sz.tekrarMi("Teşekkürler. Posta kutuna para.", 1000L))
    esit("ikinci bicim tekrar", true, sz.tekrarMi("teşekkürler. Posta kutunda para.", 2000L))
    esit("farkli satir gecer", false, sz.tekrarMi("Günaydın dostum nasılsın.", 3000L))
    esit("pencere dolunca yeniden okunur", false,
        sz.tekrarMi("Teşekkürler. Posta kutuna para.", 1000L + SesAkisi.BENZERLIK_PENCERESI + 1L))

    println("== elle cinsiyet ==")
    val kayitlar = listOf(
        SesHavuzu.Kayit("tr-tr-x-tmc-network", 190.0, 2, true),
        SesHavuzu.Kayit("tr-tr-x-ahm-local", 120.0, 1, false),
    )
    val elle = SesHavuzu.elleOku("tr-tr-x-tmc-network=1")
    esit("elle okundu", 1, elle.size)
    esit("elle deger", 1, elle["tr-tr-x-tmc-network"])
    val son = SesHavuzu.elleUygula(kayitlar, elle)
    esit("olcum ezildi", 1, son[0].cinsiyet)
    esit("isaretlenmeyen degismedi", 1, son[1].cinsiyet)
    esit("bos elle -> degisiklik yok", kayitlar, SesHavuzu.elleUygula(kayitlar, emptyMap()))
    esit("yaz-oku dongusu", elle, SesHavuzu.elleOku(SesHavuzu.elleYaz(elle)))
    esit("gecersiz deger alinmaz", 0, SesHavuzu.elleOku("a=5;b=0;c=").size)
    kontrol("ozet isaretli sayar", SesHavuzu.elleOzet(kayitlar, elle).contains("1 tanesi elle"),
        SesHavuzu.elleOzet(kayitlar, elle))
    kontrol("ozet bos havuz", SesHavuzu.elleOzet(emptyList(), elle).contains("taranmadı"))

    println("== dogallik sinirlari ==")
    for (t in listOf("KOŞ! ARKANDA!", "Gidiyorum...", "Ahaha!", "Ahhhhhh!", "Ne?! Nasıl olur?")) {
        val r = DuyguSesi.hazirla(t, siddet = 1f)
        kontrol("$t perde sinirinda", r.perde in DuyguSesi.PERDE_EN_AZ..DuyguSesi.PERDE_EN_COK,
            r.perde.toString())
        kontrol("$t hiz sinirinda", r.hiz in DuyguSesi.HIZ_EN_AZ..DuyguSesi.HIZ_EN_COK, r.hiz.toString())
    }
    kontrol("varsayilan siddet dusuruldu",
        DuyguSesi.hazirla("Ahaha!").perde < DuyguSesi.hazirla("Ahaha!", siddet = 1f).perde)
    esit("hizlanma ust siniri", 1.25f, SesAkisi.EN_YUKSEK_CARPAN)
    kontrol("hizlanma ust sinira oturur",
        SesAkisi.hizlanmaCarpani(1.0) == 1.25f, SesAkisi.hizlanmaCarpani(1.0).toString())

    println("== TV yerlesimi ==")
    esit("1080p kenar boslugu", (1080 * 0.03f).toInt(), TvYerlesim.overscanPx(1920, 1080))
    esit("4K kirpilir (96 ust sinir)", 64, TvYerlesim.overscanPx(3840, 2160))
    esit("kucuk ekran", 7, TvYerlesim.overscanPx(1280, 240))
    esit("sifir guvenli", 0, TvYerlesim.overscanPx(0, 0))
    kontrol("bosluk hic eksi olmaz", TvYerlesim.overscanPx(-100, -100) >= 0)
    kontrol("calisanlar listesi oyun yayinlarini sayar",
        TvYerlesim.tvCalisanlar().contains("GeForce NOW") &&
            TvYerlesim.tvCalisanlar().contains("Steam Link") &&
            TvYerlesim.tvCalisanlar().contains("Chiaki"))
    kontrol("calismayanlar listesi DRM uygulamalarini sayar",
        TvYerlesim.tvCalisanlar().contains("Netflix") &&
            TvYerlesim.tvCalisanlar().contains("HDMI"))

    println()
    println("GECTI: $gecti   KALDI: $kaldi")
    if (kaldi > 0) System.exit(1)
}
