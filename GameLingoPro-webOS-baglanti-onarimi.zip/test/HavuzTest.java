import java.util.*;

/** SesHavuzu.kt ve karakter başına gerçek ses dağıtımının simülasyonu. */
public class HavuzTest {

    static final int BELIRSIZ=0, ERKEK=1, KADIN=2;

    static class Kayit {
        final String ad; final double hz; final int cinsiyet; final boolean ag;
        Kayit(String a,double h,int c,boolean g){ad=a;hz=h;cinsiyet=c;ag=g;}
        public String toString(){ return ad; }
    }

    static String yaz(List<Kayit> k){
        StringBuilder sb=new StringBuilder();
        for(int i=0;i<k.size();i++){
            if(i>0) sb.append("\n");
            sb.append(k.get(i).ad).append("|").append((int)k.get(i).hz)
              .append("|").append(k.get(i).cinsiyet).append("|").append(k.get(i).ag?1:0);
        }
        return sb.toString();
    }

    static List<Kayit> oku(String metin){
        List<Kayit> out=new ArrayList<>();
        if(metin==null||metin.trim().isEmpty()) return out;
        for(String satir: metin.split("\n")){
            String[] p=satir.split("\\|");
            if(p.length<4) continue;
            String ad=p[0].trim(); if(ad.isEmpty()) continue;
            Double hz; Integer c;
            try { hz=Double.parseDouble(p[1].trim()); } catch(Exception e){ continue; }
            try { c=Integer.parseInt(p[2].trim()); } catch(Exception e){ continue; }
            out.add(new Kayit(ad,hz,c,p[3].trim().equals("1")));
        }
        return out;
    }

    static List<Kayit> havuz(List<Kayit> k,int cinsiyet,Set<String> mevcut,boolean internet){
        List<Kayit> u=new ArrayList<>();
        for(Kayit x:k) if(mevcut.contains(x.ad) && x.cinsiyet==cinsiyet && (internet||!x.ag)) u.add(x);
        if(cinsiyet==KADIN) u.sort((a,b)->Double.compare(b.hz,a.hz));
        else u.sort((a,b)->Double.compare(a.hz,b.hz));
        return u;
    }

    /** KarakterSesi.Dagitici.yuva() */
    static class Dagitici {
        final Map<String,Integer> atanan=new HashMap<>();
        final Map<String,String> yuvalar=new HashMap<>();
        String anahtar(String ad){
            if(ad==null||ad.trim().isEmpty()) return null;
            String t=ad.trim();
            if(t.contains(" ")) t=t.substring(0,t.indexOf(' '));
            t=t.toLowerCase(Locale.ROOT);
            return t.isEmpty()?null:t;
        }
        int yuva(String ad,String grup,int boy){
            if(boy<=0) return -1;
            String a=anahtar(ad); if(a==null) return -1;
            String tam=grup+"|"+a;
            Integer v=atanan.get(tam);
            if(v!=null) return v<boy ? v : v%boy;
            int tercih=Math.floorMod(a.hashCode(),boy);
            int sira=tercih;
            for(int i=0;i<boy;i++){
                int aday=(tercih+i)%boy;
                if(yuvalar.get(grup+"|"+aday)==null){ sira=aday; break; }
            }
            yuvalar.put(grup+"|"+sira,a);
            atanan.put(tam,sira);
            return sira;
        }
    }

    static int gecti=0,kaldi=0;
    static void dogru(String ad,boolean k,String ek){
        if(k){gecti++;System.out.println("  OK   "+ad+(ek.isEmpty()?"":"  "+ek));}
        else{kaldi++;System.out.println("  HATA "+ad+"  "+ek);}
    }

    /** Kullanicinin telefonundaki gercek ses listesine benzer bir kurgu. */
    static List<Kayit> ornekHavuz(){
        return Arrays.asList(
            new Kayit("tr-tr-x-ama-local",118,ERKEK,false),
            new Kayit("tr-tr-x-cfs-local",205,KADIN,false),
            new Kayit("tr-tr-x-efu-local",212,KADIN,false),
            new Kayit("tr-tr-x-mfm-local",132,ERKEK,false),
            new Kayit("tr-tr-x-tmc-local",108,ERKEK,false),
            new Kayit("tr-tr-x-star05-local",225,KADIN,false),
            new Kayit("tr-tr-x-star08-local",141,ERKEK,false),
            new Kayit("tr-tr-x-ama-network",120,ERKEK,true),
            new Kayit("tr-tr-x-cfs-network",207,KADIN,true),
            new Kayit("tr-TR-language",0,BELIRSIZ,false));
    }
    static Set<String> mevcut(List<Kayit> k){
        Set<String> s=new HashSet<>(); for(Kayit x:k) s.add(x.ad); return s;
    }

    public static void main(String[] a){
        List<Kayit> h = ornekHavuz();
        Set<String> mv = mevcut(h);

        System.out.println("== A) Yaz / oku dongusu ==");
        List<Kayit> geri = oku(yaz(h));
        dogru("kayit sayisi korunur", geri.size()==h.size(), geri.size()+"/"+h.size());
        boolean ayni=true;
        for(int i=0;i<h.size();i++){
            Kayit x=h.get(i), y=geri.get(i);
            if(!x.ad.equals(y.ad)||(int)x.hz!=(int)y.hz||x.cinsiyet!=y.cinsiyet||x.ag!=y.ag) ayni=false;
        }
        dogru("alanlar korunur", ayni, "");
        dogru("bos metin bos liste", oku("").isEmpty() && oku(null).isEmpty(), "");
        dogru("bozuk satir atlanir", oku("abc\ntr-x|120|1|0\n|||").size()==1, "");

        System.out.println("== B) Havuz: internet KAPALI ==");
        List<Kayit> e = havuz(h,ERKEK,mv,false);
        List<Kayit> k = havuz(h,KADIN,mv,false);
        dogru("4 erkek yerel ses", e.size()==4, e.toString());
        dogru("3 kadin yerel ses", k.size()==3, k.toString());
        dogru("network sesler elendi", !e.toString().contains("network") && !k.toString().contains("network"), "");

        System.out.println("== C) Havuz: internet ACIK ==");
        List<Kayit> e2 = havuz(h,ERKEK,mv,true);
        List<Kayit> k2 = havuz(h,KADIN,mv,true);
        dogru("5 erkek ses", e2.size()==5, e2.toString());
        dogru("4 kadin ses", k2.size()==4, k2.toString());

        System.out.println("== D) Siralama: erkekte en kalin, kadinda en ince basta ==");
        dogru("erkek basi en dusuk Hz", e.get(0).ad.equals("tr-tr-x-tmc-local"), e.get(0)+" ("+(int)e.get(0).hz+" Hz)");
        dogru("kadin basi en yuksek Hz", k.get(0).ad.equals("tr-tr-x-star05-local"), k.get(0)+" ("+(int)k.get(0).hz+" Hz)");

        System.out.println("== E) Silinmis ses havuzdan duser ==");
        Set<String> eksik = new HashSet<>(mv); eksik.remove("tr-tr-x-tmc-local");
        List<Kayit> e3 = havuz(h,ERKEK,eksik,false);
        dogru("3 erkek kaldi", e3.size()==3 && !e3.toString().contains("tmc"), e3.toString());

        System.out.println("== F) Dort erkek karakter: DORDU DE AYRI GERCEK SES ==");
        Dagitici d = new Dagitici();
        String[] erkekler = {"James","Arthur","Dutch","Micah"};
        Set<String> verilen = new LinkedHashSet<>();
        for(String ad: erkekler) verilen.add(e.get(d.yuva(ad,"ses"+ERKEK,e.size())).ad);
        dogru("dort farkli ses", verilen.size()==4, verilen.toString());

        System.out.println("== G) Ayni karakter hep AYNI ses ==");
        int s1=d.yuva("James","ses"+ERKEK,e.size());
        int s2=d.yuva("james","ses"+ERKEK,e.size());
        int s3=d.yuva("JAMES","ses"+ERKEK,e.size());
        dogru("James = james = JAMES", s1==s2 && s2==s3, "yuva="+s1);

        System.out.println("== H) Havuzdan fazla karakter: cokmez, paylasim olur ==");
        for(String ad: new String[]{"Bill","Javier","Sean","Lenny"}) {
            int y = d.yuva(ad,"ses"+ERKEK,e.size());
            if (y<0 || y>=e.size()) { dogru("yuva gecerli ("+ad+")", false, "y="+y); }
        }
        dogru("tum yuvalar gecerli aralikta", true, "");

        System.out.println("== I) Erkek ve kadin dagitimi birbirine karismaz ==");
        Dagitici d2 = new Dagitici();
        int ey = d2.yuva("James","ses"+ERKEK,e.size());
        int ky = d2.yuva("Lucia","ses"+KADIN,k.size());
        dogru("ayri gruplar", ey>=0 && ky>=0 && ey<e.size() && ky<k.size(), "erkek="+ey+" kadin="+ky);

        System.out.println("== J) Havuz bos: -1 doner, cagiran eski yola duser ==");
        dogru("bos havuz", new Dagitici().yuva("James","sesX",0)==-1, "");
        dogru("adsiz", new Dagitici().yuva(null,"sesX",4)==-1, "");

        System.out.println("\nGecti: "+gecti+" · Kaldi: "+kaldi);
        if(kaldi>0) System.exit(1);
    }
}
