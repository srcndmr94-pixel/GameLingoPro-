import java.util.*;

/** KarakterSesi.Dagitici mantığının simülasyonu. */
public class KarakterTest {

    static final int BILINMIYOR = 0, ERKEK = 1, KADIN = 2;

    static class Ton {
        final float perde, hiz; final String etiket; final boolean varsayilan;
        Ton(float p, float h, String e) { this(p,h,e,false); }
        Ton(float p, float h, String e, boolean v) { perde=p; hiz=h; etiket=e; varsayilan=v; }
        public String toString() { return etiket; }
    }

    static final List<Ton> ERKEK_H = Arrays.asList(
        new Ton(0.72f,0.90f,"derin ve ağır"), new Ton(0.82f,0.97f,"olgun"),
        new Ton(0.90f,1.00f,"normal",true), new Ton(0.98f,1.06f,"genç"));
    static final List<Ton> KADIN_H = Arrays.asList(
        new Ton(1.02f,0.92f,"olgun ve ağır"), new Ton(1.12f,0.99f,"olgun"),
        new Ton(1.22f,1.03f,"normal",true), new Ton(1.32f,1.08f,"genç"));
    static final List<Ton> NOTR_H = Arrays.asList(
        new Ton(0.88f,0.97f,"kalın"), new Ton(0.96f,1.00f,"normal",true),
        new Ton(1.06f,1.02f,"ince"), new Ton(1.14f,1.05f,"daha ince"));
    static Ton varsayilan(int c, boolean notr) {
        for (Ton t : havuz(c, notr)) if (t.varsayilan) return t;
        return havuz(c, notr).get(havuz(c, notr).size()/2);
    }

    static List<Ton> havuz(int c, boolean notr) {
        if (notr) return NOTR_H;
        if (c == ERKEK) return ERKEK_H;
        if (c == KADIN) return KADIN_H;
        return NOTR_H;
    }

    static class Dagitici {
        final Map<String,Integer> atanan = new HashMap<>();
        final Map<String,String> yuvalar = new HashMap<>();

        String adAnahtari(String ad) {
            if (ad == null || ad.trim().isEmpty()) return null;
            String t = ad.trim();
            while (!t.isEmpty() && ".,!?\"'".indexOf(t.charAt(0)) >= 0) t = t.substring(1);
            while (!t.isEmpty() && ".,!?\"'".indexOf(t.charAt(t.length()-1)) >= 0) t = t.substring(0,t.length()-1);
            if (t.contains(" ")) t = t.substring(0, t.indexOf(' '));
            t = t.toLowerCase(Locale.ROOT);
            return t.isEmpty() ? null : t;
        }

        Ton ton(String ad, int cinsiyet, boolean notr) {
            List<Ton> h = havuz(cinsiyet, notr);
            String anahtar = adAnahtari(ad);
            if (anahtar == null) return varsayilan(cinsiyet, notr);
            String tam = cinsiyet + "|" + anahtar;
            Integer v = atanan.get(tam);
            if (v != null) return h.get(v);
            int tercih = Math.floorMod(anahtar.hashCode(), h.size());
            int sira = tercih;
            for (int i = 0; i < h.size(); i++) {
                int aday = (tercih + i) % h.size();
                if (yuvalar.get(cinsiyet + "|" + aday) == null) { sira = aday; break; }
            }
            yuvalar.put(cinsiyet + "|" + sira, anahtar);
            atanan.put(tam, sira);
            return h.get(sira);
        }
        void unut() { atanan.clear(); yuvalar.clear(); }
    }

    static int gecti=0, kaldi=0;
    static void dogru(String ad, boolean k) {
        if (k) { gecti++; System.out.println("  OK   " + ad); }
        else { kaldi++; System.out.println("  HATA " + ad); }
    }

    public static void main(String[] a) {
        System.out.println("== A) Ayni karakter hep AYNI tonu alir ==");
        Dagitici d = new Dagitici();
        Ton t1 = d.ton("JASON", ERKEK, false);
        Ton t2 = d.ton("Jason", ERKEK, false);
        Ton t3 = d.ton("jason", ERKEK, false);
        dogru("JASON = Jason = jason", t1 == t2 && t2 == t3);

        System.out.println("== B) Ayni sahnedeki iki erkek FARKLI ton ==");
        d = new Dagitici();
        Ton j = d.ton("James", ERKEK, false);
        Ton ar = d.ton("Arthur", ERKEK, false);
        dogru("James != Arthur", j != ar);

        System.out.println("== C) Dort erkek: dordu de farkli ==");
        d = new Dagitici();
        String[] erkekler = {"James", "Arthur", "Michael", "Thomas"};
        Set<String> tonlar = new HashSet<>();
        for (String e : erkekler) tonlar.add(d.ton(e, ERKEK, false).etiket);
        dogru("dort ayri ton (" + tonlar + ")", tonlar.size() == 4);

        System.out.println("== D) Besinci erkek: havuz dolu, paylasim kacinilmaz ama COKMEZ ==");
        Ton besinci = d.ton("Robert", ERKEK, false);
        dogru("besinci de bir ton aldi", besinci != null);
        dogru("Robert sonra ayni tonu korur", d.ton("Robert", ERKEK, false) == besinci);

        System.out.println("== E) Erkek ve kadin havuzlari ayri sayilir ==");
        d = new Dagitici();
        for (String e : erkekler) d.ton(e, ERKEK, false);
        Set<String> kTon = new HashSet<>();
        for (String k : new String[]{"Lucia","Martha","Sarah","Emily"}) kTon.add(d.ton(k, KADIN, false).etiket);
        dogru("dort kadin da ayri ton", kTon.size() == 4);

        System.out.println("== F) Adsiz replik: normal ton, atama yapilmaz ==");
        d = new Dagitici();
        Ton adsiz = d.ton(null, ERKEK, false);
        dogru("adsiz -> normal", adsiz.etiket.equals("normal"));
        dogru("atama yapilmadi", d.atanan.isEmpty());

        System.out.println("== G) Notr havuz: iki ayri ses varken dar aralik ==");
        d = new Dagitici();
        Ton n = d.ton("James", ERKEK, true);
        dogru("notr havuzdan geldi", NOTR_H.contains(n));
        dogru("perde 0.88-1.14 arasi", n.perde >= 0.88f && n.perde <= 1.14f);

        System.out.println("== H) Perde ve hiz birlikte gidiyor (yas izlenimi) ==");
        boolean tutarli = true;
        for (List<Ton> h : Arrays.asList(ERKEK_H, KADIN_H, NOTR_H))
            for (int i = 1; i < h.size(); i++)
                if (!(h.get(i).perde > h.get(i-1).perde && h.get(i).hiz > h.get(i-1).hiz)) tutarli = false;
        dogru("perde artarken hiz da artiyor", tutarli);

        System.out.println("== I) unut(): yeni oyunda dagitim sifirlanir ==");
        d = new Dagitici();
        d.ton("James", ERKEK, false);
        d.unut();
        dogru("atama temizlendi", d.atanan.isEmpty() && d.yuvalar.isEmpty());

        System.out.println("== J) Erkek ve kadin tonlari cakismiyor ==");
        float enYuksekErkek = 0, enDusukKadin = 9;
        for (Ton t : ERKEK_H) enYuksekErkek = Math.max(enYuksekErkek, t.perde);
        for (Ton t : KADIN_H) enDusukKadin = Math.min(enDusukKadin, t.perde);
        dogru("erkek en ince (" + enYuksekErkek + ") < kadin en kalin (" + enDusukKadin + ")",
              enYuksekErkek < enDusukKadin);

        System.out.println("== K) Her havuzda TAM BIR varsayilan ton ==");
        for (List<Ton> h : Arrays.asList(ERKEK_H, KADIN_H, NOTR_H)) {
            int sayac = 0;
            for (Ton t : h) if (t.varsayilan) sayac++;
            dogru("havuzda tek varsayilan (" + h.get(0).etiket + " havuzu)", sayac == 1);
        }
        dogru("erkek varsayilani 'normal'", varsayilan(ERKEK,false).etiket.equals("normal"));
        dogru("kadin varsayilani 'normal'", varsayilan(KADIN,false).etiket.equals("normal"));
        dogru("notr varsayilani 'normal'", varsayilan(BILINMIYOR,true).etiket.equals("normal"));

        System.out.println("\nGecti: " + gecti + " · Kaldi: " + kaldi);
        if (kaldi > 0) System.exit(1);
    }
}
