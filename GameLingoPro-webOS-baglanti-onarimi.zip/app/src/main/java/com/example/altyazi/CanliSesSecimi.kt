package com.example.altyazi

/** Anlık ses ölçümü. Ham PCM, konuşma metni veya ses kaydı tutulmaz. */
object CanliSesSecimi {
    data class Olcum(
        val hz: Double,
        val cinsiyet: Int,
        val sesliCerceve: Int,
        val zamanMs: Long,
    )

    /**
     * Önce dahili ses: hoparlörden gelen oyunun kendisini mikrofondan tekrar
     * dinlemeye tercih eder. Yetersiz ölçümde mikrofonu dene.
     * F0 tek başına cinsiyeti veya konuşmacıyı kesin belirleyemez.
     */
    fun sec(dahili: Olcum?, mikrofon: Olcum?, simdiMs: Long): Int {
        for (olcum in listOf(dahili, mikrofon)) {
            if (olcum == null) continue
            if (olcum.zamanMs > simdiMs || simdiMs - olcum.zamanMs > 1600L) continue
            if (olcum.sesliCerceve < 14 || olcum.hz !in 70.0..320.0) continue
            if (olcum.cinsiyet == SesPerdeOlcer.ERKEK || olcum.cinsiyet == SesPerdeOlcer.KADIN) {
                return olcum.cinsiyet
            }
        }
        return SesPerdeOlcer.BELIRSIZ
    }
}
