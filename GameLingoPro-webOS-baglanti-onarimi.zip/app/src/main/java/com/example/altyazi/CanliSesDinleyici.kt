package com.example.altyazi

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.os.Build
import android.os.Process
import android.os.SystemClock
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.sqrt

/**
 * 10.51 (10.49'dan alındı): Kullanıcı açıkça etkinleştirdiğinde dahili oyun sesi ve mikrofonun
 * sadece ses perdesini ölçer. Mikrofonla OCR metni üretmez, konuşma kaydetmez.
 * Bu bir tam konuşmacı ayrıştırma (speaker diarization) modeli değildir.
 */
class CanliSesDinleyici(
    private val context: Context,
    private val projection: MediaProjection,
    private val log: (String) -> Unit,
) {
    private val aktif = AtomicBoolean(false)
    @Volatile private var dahili: CanliSesSecimi.Olcum? = null
    @Volatile private var mikrofon: CanliSesSecimi.Olcum? = null
    @Volatile private var sesiBastirMs = 0L
    private val kaydediciler = ArrayList<AudioRecord>(2)
    private val isler = ArrayList<Thread>(2)

    fun baslat() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q ||
            context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
        ) {
            log("CANLI SES: Android sürümü veya mikrofon izni yeterli değil")
            return
        }
        if (!aktif.compareAndSet(false, true)) return
        val dahiliKaydedici = try {
            val config = AudioPlaybackCaptureConfiguration.Builder(projection)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                // KENDİ SESİMİZİ HARİÇ TUT: uygulamanın okuduğu Türkçe de
                // USAGE_MEDIA ile çalıyor ve yakalamaya karışıyordu. Zaman
                // tabanlı baskılama (ttsBastir) tek başına yetmez; replik
                // uzunsa baskılama penceresi biter ve kendi sesimizi ölçeriz.
                .excludeUid(Process.myUid())
                .build()
            kaydediciYap(config, null)
        } catch (t: Throwable) {
            log("CANLI SES: dahili ses açılmadı (${t.javaClass.simpleName})")
            null
        }
        val micKaydedici = try {
            kaydediciYap(null, MediaRecorder.AudioSource.VOICE_RECOGNITION)
        } catch (t: Throwable) {
            log("CANLI SES: mikrofon açılmadı (${t.javaClass.simpleName})")
            null
        }
        if (dahiliKaydedici == null && micKaydedici == null) {
            aktif.set(false)
            return
        }
        dahiliKaydedici?.let { baslatKayit(it, true) }
        micKaydedici?.let { baslatKayit(it, false) }
        log("CANLI SES: dahili=${dahiliKaydedici != null}, mikrofon=${micKaydedici != null} · kayıt dosyası yok")
    }

    private fun kaydediciYap(
        capture: AudioPlaybackCaptureConfiguration?,
        micSource: Int?,
    ): AudioRecord? {
        val min = AudioRecord.getMinBufferSize(HZ, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) return null
        val builder = AudioRecord.Builder()
            .setAudioFormat(AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(HZ)
                .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                .build())
            .setBufferSizeInBytes(maxOf(min, HZ * 2))
        if (capture != null) builder.setAudioPlaybackCaptureConfig(capture)
        else builder.setAudioSource(micSource ?: MediaRecorder.AudioSource.MIC)
        val record = builder.build()
        if (record.state != AudioRecord.STATE_INITIALIZED) {
            record.release()
            return null
        }
        return record
    }

    private fun baslatKayit(record: AudioRecord, internal: Boolean) {
        try {
            record.startRecording()
            if (record.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                record.release(); return
            }
            synchronized(kaydediciler) { kaydediciler.add(record) }
            val thread = Thread({ okuDongusu(record, internal) }, if (internal) "gl-audio-internal" else "gl-audio-mic")
            thread.isDaemon = true
            synchronized(isler) { isler.add(thread) }
            thread.start()
        } catch (t: Throwable) {
            try { record.release() } catch (_: Throwable) { }
            log("CANLI SES: ${if (internal) "dahili" else "mikrofon"} başlatılamadı (${t.javaClass.simpleName})")
        }
    }

    private fun okuDongusu(record: AudioRecord, internal: Boolean) {
        val parca = ShortArray(HZ / 5)
        // Son 0.8 saniye; her 0.8 saniyede bir hafifletilmiş analiz.
        val birikim = ShortArray(HZ * 4 / 5)
        var yazilan = 0
        while (aktif.get()) {
            val n = try { record.read(parca, 0, parca.size, AudioRecord.READ_BLOCKING) }
            catch (_: Throwable) { break }
            if (n <= 0) {
                if (n < 0) break
                continue
            }
            val kopya = minOf(n, birikim.size - yazilan)
            System.arraycopy(parca, 0, birikim, yazilan, kopya)
            yazilan += kopya
            if (yazilan < birikim.size) continue
            yazilan = 0
            val simdi = SystemClock.elapsedRealtime()
            if (simdi < sesiBastirMs) {
                if (internal) dahili = null else mikrofon = null
                continue
            }
            // Sessizlik, çok düşük RMS ve sürekli synth notaları tamamen
            // ayırt edilemez: bu yüzden sonuç yalnız 'tahmin'dir.
            val rms = sqrt(birikim.fold(0.0) { acc, s ->
                val f = s / 32768.0; acc + f * f
            } / birikim.size)
            if (rms < 0.012) {
                if (internal) dahili = null else mikrofon = null
                continue
            }
            val floats = FloatArray(birikim.size) { birikim[it] / 32768f }
            val sonuc = SesPerdeOlcer.olc(floats, HZ)
            val olcum = if (sonuc.olculdu) CanliSesSecimi.Olcum(
                sonuc.hz, sonuc.cinsiyet, sonuc.sesliCerceve, simdi
            ) else null
            if (internal) dahili = olcum else mikrofon = olcum
        }
    }

    /** TTS sesi yakalanıp yeni karakterin sesine yanlışlıkla bağlanmasın. */
    fun ttsBastir(sureMs: Long = 1800L) {
        sesiBastirMs = SystemClock.elapsedRealtime() + sureMs
        dahili = null
        mikrofon = null
    }

    fun cinsiyet(): Int = CanliSesSecimi.sec(dahili, mikrofon, SystemClock.elapsedRealtime())

    fun durdur() {
        aktif.set(false)
        synchronized(kaydediciler) {
            for (record in kaydediciler) {
                try { record.stop() } catch (_: Throwable) { }
                try { record.release() } catch (_: Throwable) { }
            }
            kaydediciler.clear()
        }
        dahili = null
        mikrofon = null
    }

    companion object { private const val HZ = 16000 }
}
