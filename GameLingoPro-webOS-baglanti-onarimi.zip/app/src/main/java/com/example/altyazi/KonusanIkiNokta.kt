package com.example.altyazi

/**
 * EKSİK İKİ NOKTA (10.57)
 *
 * SORUN: Konuşan adından sonraki iki nokta OCR'da sık kayboluyor ve ad
 * cümlenin parçası sanılıp çevriliyor. Kullanıcının kayıtlarından:
 *
 *   "Lucia Stop!"                  -> "Lucia Durdurun!"   (Dur!)
 *   "Kenton First trip out since beautiful Juliana came through."
 *       -> "Güzel Juliana geldiği için Kenton ve First devre dışı kaldı."
 *
 * ÇÖZÜM: aynı oturumda o ad İKİ NOKTAYLA görülmüşse kesin kanıttır.
 * "Lucia:" satırlarca geçtiyse, "Lucia Stop!" satırında iki nokta
 * geri konur ve ad çeviriye hiç girmez.
 *
 * NEDEN AYRI BİR NESNE: [KonusanOnEki] parantezsiz adları iki satırın
 * ortak önekinden ÖĞRENİYOR; burada öğrenme yok, yalnız kanıtlanmış
 * adın eksik noktası onarılıyor. İkisi birbirinin yerine geçmiyor.
 *
 * Android bağımlılığı yok, tek başına sınanabiliyor.
 */
object KonusanIkiNokta {

    private val kilit = Any()

    /** İki noktayla görülmüş adlar (en çok [SINIR] tane). */
    private val bilinen = LinkedHashSet<String>()

    private const val SINIR = 40

    /**
     * Ad öbeği: "Lucia", "Man in Black", "Sir Todd Bancroft".
     *
     * ARA SÖZCÜK KÜÇÜK HARFLİ OLABİLİR. İlk denemede her sözcüğün
     * büyük harfle başlaması isteniyordu ve "Man in Black" hiç
     * öğrenilemiyordu.
     */
    private const val AD_OBEGI =
        "\\p{Lu}[\\p{L}.'\\-]{1,19}" +
            "(?:\\s(?:in|of|the|de|la|le|von|van|du|al|el|da|dos)\\s\\p{Lu}[\\p{L}.'\\-]{1,19}" +
            "|\\s\\p{Lu}[\\p{L}.'\\-]{1,19}){0,2}"

    /** "Lucia:" ya da "Man in Black:" — en çok üç sözcük. */
    private val ADLI_ONEK = Regex("^($AD_OBEGI)\\s*:\\s+")

    /** Köşeli etiket de kanıttır: "[Lucia] Stop!" */
    private val KOSELI_ONEK =
        Regex("^\\[\\s*(\\p{L}[\\p{L}.'\\-]{1,19}(?:\\s\\p{L}[\\p{L}.'\\-]{1,19}){0,2})\\s*\\]")

    /** Baştaki ad, ardından BÜYÜK harfle başlayan yeni cümle. */
    private val IKI_NOKTASIZ = Regex("^($AD_OBEGI)\\s+(?=\\p{Lu})")

    fun temizle() = synchronized(kilit) { bilinen.clear() }

    fun durum(): String = synchronized(kilit) {
        if (bilinen.isEmpty()) "ad yok" else bilinen.joinToString(", ")
    }

    fun bilinenler(): Set<String> = synchronized(kilit) { LinkedHashSet(bilinen) }

    /** Satırda iki noktayla ya da köşeli etiketle geçen adı deftere yazar. */
    fun ogren(satir: String?) {
        if (satir.isNullOrBlank()) return
        val t = satir.trimStart('-', '–', ' ', '"', '\'')
        val ad = ADLI_ONEK.find(t)?.groupValues?.get(1)
            ?: KOSELI_ONEK.find(t)?.groupValues?.get(1)
            ?: return
        val temiz = ad.trim().trimEnd('.', ',')
        if (temiz.length < 2) return
        synchronized(kilit) {
            if (bilinen.size >= SINIR && temiz !in bilinen) bilinen.remove(bilinen.first())
            bilinen += temiz
        }
    }

    /**
     * Baştaki ad deftere kayıtlıysa eksik iki noktayı geri koyar.
     * Ad bilinmiyorsa satıra dokunulmaz — tahminle cümle bölmek,
     * adın çevrilmesinden daha kötü olurdu.
     */
    fun onar(satir: String?): String {
        if (satir.isNullOrBlank()) return satir ?: ""
        val t = satir
        // Zaten iki nokta ya da köşeli etiket varsa iş yok.
        if (ADLI_ONEK.containsMatchIn(t.trimStart()) || KOSELI_ONEK.containsMatchIn(t.trimStart())) return t
        val m = IKI_NOKTASIZ.find(t.trimStart()) ?: return t
        val aday = m.groupValues[1].trim().trimEnd('.', ',')
        val kayitli = synchronized(kilit) { aday in bilinen }
        if (!kayitli) return t
        val bas = t.length - t.trimStart().length
        val onek = t.substring(0, bas)
        val kalan = t.trimStart().substring(m.value.length)
        if (kalan.isBlank()) return t
        return onek + aday + ": " + kalan
    }

    /** Hem öğrenir hem onarır; sıra önemli, önce onarım denenir. */
    fun isle(satir: String?): String {
        val onarilmis = onar(satir)
        ogren(onarilmis)
        return onarilmis
    }
}
