package com.example.altyazi

import java.util.Locale

/**
 * HİTAP TEKİLLEŞTİRME (10.57)
 *
 * SORUN: Oyun diyaloğunda karakterler birbirine "sen" der. DeepL ve
 * Google ise İngilizce "you"yu sık sık "siz" olarak çeviriyor ve
 * aynı sahnede ikisi karışıyor. Kullanıcının 19 Kasım kaydından:
 *
 *   "After you."                      -> "Önce siz."
 *   "Through there."                  -> "Oradan geçin."
 *   "You calling about something?"    -> "Bir şey için mi aradınız?"
 *   "if you use your imagination..."  -> "hayal gücünüzü kullanırsanız"
 *   "when you find the product, bring it back here"
 *                                     -> "bulduğunuzda... getirin"
 *
 * 130 replikte 6 tane; az görünüyor ama Jason ile Lucia sevgili,
 * Donnie ile arkadaş — araya giren "siz" kulağa çok batıyor.
 *
 * ÇÖZÜM: çeviriyi tekilleştir, AMA yalnız kaynak gerçekten tek kişiye
 * sesleniyorsa. İngilizce "you" hem tekil hem çoğuldur; "you guys",
 * "boys", "everyone" gibi işaretler varsa çoğul doğrudur ve
 * dokunulmaz. Kenton'ın dört kişiye "Bu takım elbiseler size uygun
 * mu?" demesi doğru çeviridir.
 *
 * TASARIM NOTU: Android bağımlılığı yok, tek başına sınanabiliyor.
 * Kurallar iki sınıfa ayrıldı:
 *
 *  1. BİÇİMBİRİM OLARAK KESİN olanlar: Türkçede hiçbir ad "-sınız",
 *     "-dınız", "-yorsunuz" diye bitmez. Bunlar koşulsuz çevrilir.
 *  2. BELİRSİZ olanlar: yalın iyelik "-nız/-niz/-nuz/-nüz".
 *     "deniz", "yalnız", "geniz", "beniz" de böyle bitiyor. Bunlar
 *     için hem uzunluk koşulu hem yasak kök listesi var.
 */
object HitapTekil {

    private val TR = Locale("tr", "TR")

    /** Kaynakta bunlardan biri varsa çoğul doğrudur, dokunulmaz. */
    private val COGUL_ISARETLERI = listOf(
        "you guys", "you all", "y'all", "yall", "you two", "you three",
        "all of you", "both of you", "everyone", "everybody", "every one of you",
        "guys", "boys", "girls", "fellas", "fellows", "folks", "ladies",
        "gentlemen", "lads", "people", "team", "men", "comrades", "brothers",
        "sisters", "children", "kids", "class", "gang", "crew",
    )

    /**
     * Biçimbirim olarak kesin çoğul çekimler. Sıra önemli: uzun olan
     * önce denenir, yoksa "sunuz" içindeki "nuz" önce yakalanırdı.
     */
    private val KESIN: List<Pair<String, String>> = listOf(
        // şimdiki zaman
        "yorsunuz" to "yorsun",
        // gelecek
        "acaksınız" to "acaksın", "eceksiniz" to "eceksin",
        // gereklilik
        "malısınız" to "malısın", "melisiniz" to "melisin",
        // geçmiş
        "dınız" to "dın", "diniz" to "din", "dunuz" to "dun", "dünüz" to "dün",
        "tınız" to "tın", "tiniz" to "tin", "tunuz" to "tun", "tünüz" to "tün",
        // şart
        "sanız" to "san", "seniz" to "sen",
        // geniş/haber
        "sınız" to "sın", "siniz" to "sin", "sunuz" to "sun", "sünüz" to "sün",
    )

    /** Yalın iyelik: belirsiz, koşullu uygulanır. */
    private val IYELIK: List<Pair<String, String>> = listOf(
        "nız" to "n", "niz" to "n", "nuz" to "n", "nüz" to "n",
    )

    /**
     * İyelik kuralının dokunmayacağı kökler.
     * "denizde" -> "dende", "yalnızca" -> "yalnca" olmasın.
     */
    private val YASAK_KOK = listOf(
        "deniz", "yalnız", "geniz", "beniz", "peniz", "teniz", "kiniz", "haniz",
    )

    /** İyelik kuralı için en az sözcük uzunluğu. */
    private const val IYELIK_EN_AZ = 7

    /** Çekim ekinden sonra gelebilen hâl ekleri. */
    private val HAL_EKLERI = listOf(
        "", "ı", "i", "u", "ü", "a", "e", "da", "de", "ta", "te",
        "dan", "den", "tan", "ten", "la", "le", "ın", "in", "un", "ün",
        "dır", "dir", "dur", "dür", "ki", "mi", "mı", "mu", "mü",
    )

    /** Zamirler: tam sözcük olarak kesin. */
    private val ZAMIRLER: Map<String, String> = mapOf(
        "siz" to "sen", "sizi" to "seni", "size" to "sana", "sizin" to "senin",
        "sizce" to "sence", "sizinle" to "seninle", "sizden" to "senden",
        "sizde" to "sende", "sizindir" to "senindir", "sizsiniz" to "sensin",
    )

    /**
     * Emir kipi çoğulu. SADECE SEÇİLMİŞ LİSTE: ekle çözülmeye
     * çalışılsa "alın" (vücut), "gelin" (evlenen), "serin", "derin"
     * gibi sözcükler bozulurdu.
     */
    private val EMIR: Map<String, String> = mapOf(
        "geçin" to "geç", "getirin" to "getir", "götürün" to "götür",
        "bakın" to "bak", "verin" to "ver", "gidin" to "git", "durun" to "dur",
        "bekleyin" to "bekle", "dinleyin" to "dinle", "yapın" to "yap",
        "bırakın" to "bırak", "çekilin" to "çekil", "koşun" to "koş",
        "kullanın" to "kullan", "deneyin" to "dene", "söyleyin" to "söyle",
        "izleyin" to "izle", "açın" to "aç", "kapatın" to "kapat",
        "oturun" to "otur", "kalkın" to "kalk", "girin" to "gir",
        "çıkın" to "çık", "atın" to "at", "tutun" to "tut", "binin" to "bin",
        "inin" to "in", "susun" to "sus", "anlatın" to "anlat",
        "bulun" to "bul", "alın" to "al", "gelin" to "gel", "edin" to "et",
        "olun" to "ol", "sorun" to "sor", "unutmayın" to "unutma",
        "korkmayın" to "korkma", "merak etmeyin" to "merak etme",
        "kımıldamayın" to "kımıldama", "endişelenmeyin" to "endişelenme",
        "vurun" to "vur", "ateş edin" to "ateş et", "acele edin" to "acele et",
        "dikkat edin" to "dikkat et", "hazır olun" to "hazır ol",
        "sakin olun" to "sakin ol", "affedersiniz" to "affedersin",
    )

    /**
     * Emir listesinde ÇOK ANLAMLI olanlar: yalnız satırda başka bir
     * çoğul hitap kanıtı varsa çevrilir.
     *
     * "alın" vücut parçası, "gelin" evlenen kişi, "sorun" problem,
     * "inin" iniş... Bunlar emir olarak da sık geçtiği için listede
     * kalıyor ama tek başına kanıt sayılmıyor.
     */
    private val EMIR_SUPHELI = setOf("alın", "gelin", "sorun", "inin", "edin", "olun", "atın", "tutun", "bulun")

    // --------------------------------------------------------------- giriş

    /** Kaynak tek kişiye mi sesleniyor? */
    fun tekilMi(kaynak: String?): Boolean {
        if (kaynak.isNullOrBlank()) return true
        val k = kaynak.lowercase(Locale.ROOT)
        for (i in COGUL_ISARETLERI) {
            if (Regex("\\b" + Regex.escape(i) + "\\b").containsMatchIn(k)) return false
        }
        return true
    }

    /**
     * Çeviriyi tekilleştirir. Kaynak çoğula sesleniyorsa dokunulmaz.
     *
     * @param kaynak İngilizce özgün satır (çoğul denetimi için)
     * @param ceviri Türkçe çeviri
     */
    fun duzelt(kaynak: String?, ceviri: String?): String {
        if (ceviri.isNullOrBlank()) return ceviri ?: ""
        if (!tekilMi(kaynak)) return ceviri
        return tekille(ceviri)
    }

    /** Kaynak denetimi olmadan tekilleştirir (sınama ve doğrudan kullanım). */
    fun tekille(ceviri: String): String {
        if (ceviri.isBlank()) return ceviri
        val kanitVar = kesinKanit(ceviri)
        val sb = StringBuilder(ceviri.length)
        var i = 0
        while (i < ceviri.length) {
            val c = ceviri[i]
            if (!c.isLetter()) {
                sb.append(c)
                i++
                continue
            }
            var j = i
            while (j < ceviri.length && (ceviri[j].isLetter() || ceviri[j] == '\'' || ceviri[j] == '’')) j++
            val kelime = ceviri.substring(i, j)
            sb.append(sozcuk(kelime, kanitVar))
            i = j
        }
        return sb.toString()
    }

    /**
     * Satırda biçimbirim olarak KESİN bir çoğul hitap var mı?
     * Şüpheli emir sözcükleri ancak bu varsa çevrilir.
     */
    fun kesinKanit(ceviri: String): Boolean {
        for (p in ceviri.split(Regex("[^\\p{L}'’]+"))) {
            if (p.isBlank()) continue
            val k = p.lowercase(TR)
            if (k in ZAMIRLER) return true
            if (kesinEk(k) != null) return true
            val e = EMIR[k]
            if (e != null && k !in EMIR_SUPHELI) return true
        }
        return false
    }

    private fun sozcuk(kelime: String, kanitVar: Boolean): String {
        val kucuk = kelime.lowercase(TR)

        ZAMIRLER[kucuk]?.let { return bicimle(kelime, it) }

        EMIR[kucuk]?.let { yeni ->
            if (kucuk in EMIR_SUPHELI && !kanitVar) return kelime
            return bicimle(kelime, yeni)
        }

        kesinEk(kucuk)?.let { return bicimle(kelime, it) }

        iyelikEk(kucuk)?.let { return bicimle(kelime, it) }

        return kelime
    }

    /** Biçimbirim olarak kesin çekimler; bulunursa tekil hâli döner. */
    private fun kesinEk(kucuk: String): String? {
        for ((cogul, tekil) in KESIN) {
            for (hal in HAL_EKLERI) {
                val ek = cogul + hal
                if (kucuk.length > ek.length && kucuk.endsWith(ek)) {
                    return kucuk.dropLast(ek.length) + tekil + hal
                }
            }
        }
        return null
    }

    /** Yalın iyelik; koşullar sağlanırsa tekil hâli döner. */
    private fun iyelikEk(kucuk: String): String? {
        if (kucuk.length < IYELIK_EN_AZ) return null
        for (kok in YASAK_KOK) if (kucuk.startsWith(kok)) return null
        for ((cogul, tekil) in IYELIK) {
            for (hal in HAL_EKLERI) {
                // HÂL EKİ ZORUNLU. Yalın iyelik ("eviniz") serbest
                // bırakılsa birinci çoğul kişi çekimleri bozulurdu:
                // "yorgunuz" (yorgun + uz) ve "memnunuz" da "-nuz" ile
                // bitiyor ve "yorgun", "memnun" olup "biz" anlamını
                // kaybediyordu. Hâl eki geldiğinde böyle bir çakışma yok.
                if (hal.isEmpty()) continue
                val ek = cogul + hal
                if (kucuk.length > ek.length + 2 && kucuk.endsWith(ek)) {
                    return kucuk.dropLast(ek.length) + tekil + hal
                }
            }
        }
        return null
    }

    /** Özgün sözcüğün büyük/küçük biçimini yeni sözcüğe taşır. */
    private fun bicimle(ozgun: String, yeni: String): String {
        if (ozgun.isEmpty() || yeni.isEmpty()) return yeni
        if (ozgun[0].isUpperCase()) {
            return yeni.substring(0, 1).uppercase(TR) + yeni.substring(1)
        }
        return yeni
    }
}
