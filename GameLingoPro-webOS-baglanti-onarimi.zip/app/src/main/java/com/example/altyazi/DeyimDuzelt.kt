package com.example.altyazi

import java.util.Locale

/**
 * DEYİM VE KAYNAK ONARIMI (10.57)
 *
 * Kullanıcının 19 Kasım kaydından çıkan üç hata sınıfı:
 *
 * 1. DEYİMLER BİREBİR ÇEVRİLİYOR
 *      "Ooh, fuck yeah."        -> "Ooh, sikiş evet."
 *      "The fuck you going?"    -> "Siktir git gidiyor mu?"
 *      "They're holding up."    -> "İşleri gecikiyor."
 *      "jailbird"               -> "hırsız"
 *      "Work detail."           -> "Çalışma ayrıntıları."
 *      "Mr. Fuckin' Busy"       -> "Bay Siktiğimin meşgul"
 *
 * 2. İNGİLİZCE SÖZCÜK ÇEVİRİDE KALIYOR
 *      "Well, you got out early" -> "Well, erkenden çıktın"
 *      "Whoops, dog!"            -> "Whoops, köpek!"
 *
 * 3. OCR SATIR BAŞINI BOZUYOR, ÖZNE UÇUYOR
 *      "Y-you flew the plane?"  -> "Yyou uçağı mı uçurdu?"
 *      "Butiyou don't..."       -> "Butiyou, yapma..."
 *
 * TASARIM İLKESİ: her düzeltme KAYNAĞA BAKARAK yapılır. "hırsız"
 * sözcüğü körlemesine "eski mahkûm" olmaz; yalnız kaynakta
 * "jailbird" geçiyorsa olur. Böylece gerçekten hırsız geçen bir
 * satır bozulmaz.
 *
 * Android bağımlılığı yok, tek başına sınanabiliyor.
 */
object DeyimDuzelt {

    private val TR = Locale("tr", "TR")
    private val ROOT = Locale.ROOT

    // ------------------------------------------------- 3) kaynak onarımı

    /** OCR'ın bozduğu, kayıtta görülen sözcükler. */
    private val KAYNAK_SOZCUK: Map<String, String> = mapOf(
        "butiyou" to "But you",
        "yyou" to "you",
        "youlre" to "you're",
        "youl" to "you'll",
        "donlt" to "don't",
        "canlt" to "can't",
        "islt" to "isn't",
        "thatls" to "that's",
        "itls" to "it's",
        "aviator" to "Aviator",
        "aight" to "alright",
    )

    /**
     * Kekeleme: "Y-you" -> "you", "I-I" -> "I", "w-what" -> "what".
     * Aynı harf tekrarı ve araya tire; OCR'da ve özgün altyazıda ikisi
     * de geçiyor. Harf atılıyor, kalan sözcük bozulmuyor.
     */
    private val KEKELEME = Regex("(?i)\\b([a-z])-(?=\\1)")

    /** Satır içinde boşluk fazlalığı. */
    private val COK_BOSLUK = Regex("\\s{2,}")

    /**
     * Çeviriye girmeden önce kaynağı onarır.
     *
     * NEDEN ÇEVİRİDEN ÖNCE: "Y-you flew the plane?" çeviriciye böyle
     * gidince özne kayboluyor ve "Yyou uçağı mı uçurdu?" çıkıyor.
     * Kaynak onarılırsa çevirici doğru cümleyi görüyor.
     */
    fun kaynakOnar(kaynak: String?): String {
        if (kaynak.isNullOrBlank()) return kaynak ?: ""
        var t = KEKELEME.replace(kaynak, "")
        val sb = StringBuilder(t.length)
        var i = 0
        while (i < t.length) {
            val c = t[i]
            if (!c.isLetter()) {
                sb.append(c)
                i++
                continue
            }
            var j = i
            while (j < t.length && (t[j].isLetter() || t[j] == '\'')) j++
            val kelime = t.substring(i, j)
            val yeni = KAYNAK_SOZCUK[kelime.lowercase(ROOT)]
            if (yeni != null && kelime.lowercase(ROOT) != yeni.lowercase(ROOT)) {
                sb.append(if (kelime[0].isUpperCase()) basBuyut(yeni) else yeni)
            } else {
                sb.append(kelime)
            }
            i = j
        }
        t = COK_BOSLUK.replace(sb.toString(), " ")
        return t
    }

    // ------------------------------------- 2) çeviride kalan İngilizce

    /**
     * Satır başında çeviriye sızan İngilizce bağlayıcılar.
     * Yalnız KAYNAK DA aynı sözcükle başlıyorsa değiştirilir: bu,
     * sözcüğün çevrilmeden kopyalandığının kanıtı.
     */
    private val BAS_SOZCUK: Map<String, String> = mapOf(
        "well" to "Yani", "whoops" to "Hoop", "oops" to "Hoop",
        "so" to "Yani", "look" to "Bak", "listen" to "Dinle",
        "alright" to "Pekâlâ", "anyway" to "Her neyse", "actually" to "Aslında",
        "okay" to "Tamam", "nope" to "Yok", "yep" to "Evet", "yup" to "Evet",
        "huh" to "Ha", "wow" to "Vay", "damn" to "Lanet olsun",
        "dude" to "Dostum", "please" to "Lütfen", "sorry" to "Üzgünüm",
        "maybe" to "Belki", "sure" to "Tabii", "fine" to "Tamam",
    )

    private val BAS_DESENI = Regex("^([\\p{L}']+)(\\s*[,:;.!?]?\\s*)(.*)$", RegexOption.DOT_MATCHES_ALL)

    /**
     * Çevirinin başındaki çevrilmemiş İngilizce sözcüğü Türkçeleştirir.
     *
     * KONUŞAN ADI ÖNEKİ AYRILIYOR: "Lucia: Whoops, köpek!" satırında
     * ilk sözcük "Lucia"dır, "Whoops" değil. Önek ayrılmazsa kural hiç
     * çalışmıyordu.
     */
    fun basOnar(kaynak: String?, ceviri: String): String {
        if (ceviri.isBlank()) return ceviri
        val onek = onekAl(ceviri)
        val govde = ceviri.trimStart().substring(onek.length)
        val m = BAS_DESENI.find(govde) ?: return ceviri
        val ilk = m.groupValues[1]
        val karsilik = BAS_SOZCUK[ilk.lowercase(ROOT)] ?: return ceviri
        // Kaynak da aynı sözcükle başlamıyorsa dokunulmaz: Türkçe
        // "So" diye bir sözcük yok ama "Sorun" var ve kesilmemeli.
        val k = adiAt((kaynak ?: "")).trimStart('-', '–', ' ', '"', '\'', '[')
        val kaynakIlk = Regex("^([\\p{L}']+)").find(k)?.groupValues?.get(1) ?: return ceviri
        if (!kaynakIlk.equals(ilk, ignoreCase = true)) return ceviri
        val kalan = m.groupValues[3]
        val ayrac = m.groupValues[2].ifBlank { if (kalan.isBlank()) "" else " " }
        return onek + karsilik + ayrac + kalan
    }

    // ------------------------------------------------------ 1) deyimler

    /**
     * [kaynakDeseni] kaynakta geçerse çeviriye bakılır.
     * [tam] ise çevirinin tamamı [turkce] olur; değilse çeviride
     * [bozuk] bulunup [turkce] ile değiştirilir.
     */
    private class Kural(
        kaynakDeseni: String,
        val turkce: String,
        val tam: Boolean,
        bozukDeseni: String? = null,
    ) {
        val kaynak = Regex(kaynakDeseni, RegexOption.IGNORE_CASE)
        val bozuk = bozukDeseni?.let { Regex(it, RegexOption.IGNORE_CASE) }
    }

    private val KURALLAR: List<Kural> = listOf(
        // --- tam satır
        Kural("^(ooh|oh|aah)?[,!.\\s]*fuck yeah[.!\\s]*$", "Oh, evet be!", true),
        Kural("^the fuck (are )?you going[?!.\\s]*$", "Nereye gidiyorsun lan?", true),
        Kural("^it'?s just something i picked (it )?up[.!\\s]*$", "Öyle aldığım bir şey.", true),
        Kural("^(they'?re|we'?re) hold(ing| in'?) up[.!\\s]*$", "Dayanıyorlar.", true),
        Kural("^(it'?s|he'?s|she'?s) hold(ing| in'?) up[.!\\s]*$", "Dayanıyor.", true),
        Kural("^can'?t go r?ound missing th(ose|em)[.!\\s]*$", "Bunları kaybetmek olmaz.", true),
        Kural("^work detail[.!\\s]*$", "Kamu hizmeti.", true),
        Kural("^after you[.!\\s]*$", "Önce sen.", true),
        Kural("^through there[.!\\s]*$", "Şurada.", true),
        Kural("^a'?ight[.!\\s]*$", "Tamam.", true),
        Kural("^what now[?!.\\s]*$", "Şimdi ne olacak?", true),
        // --- parça değişimi (kaynak kanıtlı)
        Kural("\\bjailbird\\b", "eski mahkûm", false, "hırsız(ın|ı|a|dan|la)?"),
        Kural("\\bwork detail\\b", "kamu hizmeti", false, "çalışma ayrıntı(ları|sı|lar)?"),
        // DİKKAT: Türkçe desende \\w KULLANILMAZ. Java/Kotlin'de \\w yalnız
        // ASCII harfleri tutuyor; "Siktiğimin" içindeki ğ ve ı eşleşmiyordu.
        // Türkçe tarafta \\p{L} kullanılıyor.
        Kural("\\bmr\\.? fuck\\w*'? busy\\b", "Bay Çok Meşgul", false, "Bay Sik\\p{L}+ meşgul"),
        Kural("\\bthem others\\b", "diğerlerini", false, "onlara başkalarını"),
        Kural("\\bthe aviators\\b", "Aviator'ları", false, "aviator gözlük(leri|lerini|lerle)?"),
        Kural("\\bfuck yeah\\b", "evet be", false, "sikiş,? evet"),
        Kural("\\bhold(ing| in'?) up\\b", "dayanıyor", false, "işleri gecikiyor"),
        Kural("\\bcapeesh\\b", "anladın mı", false, "capeesh"),
        Kural("\\blimp dick\\b", "sönük herif", false, "let'in sırası"),
    )

    /**
     * Deyim düzeltmesi. Kaynak kanıt olmadan hiçbir şey değişmez.
     */
    fun deyim(kaynak: String?, ceviri: String): String {
        if (ceviri.isBlank()) return ceviri
        val k = adiAt(kaynak ?: return ceviri).trim()
        if (k.isEmpty()) return ceviri
        var sonuc = ceviri
        for (kural in KURALLAR) {
            if (!kural.kaynak.containsMatchIn(k)) continue
            if (kural.tam) {
                // Tam satır kuralı: konuşan adı öneki korunur.
                val onek = onekAl(ceviri)
                return onek + kural.turkce
            }
            val bozuk = kural.bozuk ?: continue
            if (bozuk.containsMatchIn(sonuc)) {
                sonuc = bozuk.replace(sonuc) { kural.turkce }
            }
        }
        return sonuc
    }

    /** Hepsi bir arada: kaynak kanıtlı deyim ve baş sözcük düzeltmesi. */
    fun duzelt(kaynak: String?, ceviri: String?): String {
        if (ceviri.isNullOrBlank()) return ceviri ?: ""
        return basOnar(kaynak, deyim(kaynak, ceviri))
    }

    // ------------------------------------------------------- yardımcılar

    private val AD_ONEKI = Regex("^(\\p{Lu}[\\p{L}.'\\-]{1,19}(?:\\s\\p{Lu}[\\p{L}.'\\-]{1,19})?\\s*:\\s*)")
    private val KOSELI_ONEK = Regex("^(\\[[^\\]]{1,24}\\]\\s*)")

    /** Satır başındaki konuşan adını atar (kaynak karşılaştırması için). */
    fun adiAt(satir: String): String {
        var t = satir.trim()
        t = KOSELI_ONEK.replace(t, "")
        t = AD_ONEKI.replace(t, "")
        return t
    }

    /** Satır başındaki konuşan adı öneki (tam satır kuralında korunur). */
    fun onekAl(satir: String): String {
        val t = satir.trimStart()
        KOSELI_ONEK.find(t)?.let { return it.groupValues[1] }
        AD_ONEKI.find(t)?.let { return it.groupValues[1] }
        return ""
    }

    private fun basBuyut(t: String): String =
        if (t.isEmpty()) t else t.substring(0, 1).uppercase(ROOT) + t.substring(1)
}
