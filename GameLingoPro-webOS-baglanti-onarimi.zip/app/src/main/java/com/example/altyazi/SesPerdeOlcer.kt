package com.example.altyazi

import java.io.File
import java.io.RandomAccessFile

/**
 * SES PERDE ÖLÇER — 10.46
 *
 * Bir WAV dosyasındaki konuşmanın temel frekansını (F0) ölçer.
 * Amaç: telefondaki Türkçe seslerin erkek mi kadın mı olduğunu KENDİLİĞİNDEN
 * anlamak.
 *
 * NEDEN GEREKLİ: Android'in `Voice` sınıfı cinsiyet bildirmiyor, ses adından
 * ("tr-tr-x-ama-local") da anlaşılmıyor. Ama sesin kendisi ölçülebilir:
 * erkek konuşması kabaca 85-180 Hz, kadın 165-255 Hz bandında.
 *
 * YÖNTEM: otokorelasyon. Her çerçeve kendi gecikmeli kopyasıyla çarpılır;
 * en güçlü tekrar hangi gecikmedeyse periyot odur, frekans da 1/periyot.
 * Yalnız yeterince periyodik (sesli) çerçeveler sayılır; sessizlik ve
 * gürültü atılır. Sonuç, sesli çerçevelerin MEDYANI — tek bir bozuk çerçeve
 * sonucu kaydırmasın.
 *
 * Bu dosya saf hesap: Android'e bağlı değil, dosyadan okur. Böylece
 * telefona kurmadan sınanabiliyor.
 */
object SesPerdeOlcer {

    const val BELIRSIZ = 0
    const val ERKEK = 1
    const val KADIN = 2

    /** Bu eşiğin altı erkek sayılır (Hz). */
    const val ERKEK_SINIRI = 155.0

    /** Bu eşiğin üstü kadın sayılır (Hz). Arası BELIRSIZ. */
    const val KADIN_SINIRI = 175.0

    /** İnsan konuşmasında aranan en düşük ve en yüksek temel frekans. */
    private const val EN_DUSUK_HZ = 70.0
    private const val EN_YUKSEK_HZ = 320.0

    /**
     * YIN mutlak eşiği. Normalleştirilmiş fark işlevi bunun altına düştüğü
     * İLK gecikme periyot sayılır. Standart değer 0,10-0,15.
     */
    private const val YIN_ESIK = 0.15

    /** Eşiğin altına hiç inilmezse, en küçük değer bundan büyükse çerçeve sessiz sayılır. */
    private const val YIN_UST_SINIR = 0.45

    /** Güvenilir sonuç için gereken en az sesli çerçeve sayısı. */
    private const val EN_AZ_SESLI_CERCEVE = 8

    data class Sonuc(
        /** Ölçülen temel frekansın medyanı (Hz); ölçülemediyse 0. */
        val hz: Double,
        /** Sesli sayılan çerçeve sayısı. */
        val sesliCerceve: Int,
        /** ERKEK / KADIN / BELIRSIZ. */
        val cinsiyet: Int,
    ) {
        val olculdu: Boolean get() = hz > 0.0 && sesliCerceve >= EN_AZ_SESLI_CERCEVE

        val aciklama: String
            get() = when {
                !olculdu -> "ölçülemedi"
                cinsiyet == ERKEK -> "erkek (${hz.toInt()} Hz)"
                cinsiyet == KADIN -> "kadın (${hz.toInt()} Hz)"
                else -> "belirsiz (${hz.toInt()} Hz)"
            }
    }

    val BOS = Sonuc(0.0, 0, BELIRSIZ)

    /** WAV dosyasını okuyup ölçer. Dosya bozuksa [BOS]. */
    fun olc(dosya: File): Sonuc {
        val ses = try {
            wavOku(dosya)
        } catch (_: Throwable) {
            null
        } ?: return BOS
        return olc(ses.ornekler, ses.ornekHizi)
    }

    /** Hazır örnekleri ölçer (-1..1 aralığında, tek kanal). */
    fun olc(ornekler: FloatArray, ornekHizi: Int): Sonuc {
        if (ornekHizi <= 0 || ornekler.size < ornekHizi / 10) return BOS

        // 45 ms çerçeve, 10 ms adım. YIN çerçevenin yarısını pencere, yarısını
        // gecikme payı olarak kullanır; bu yüzden çerçeve otokorelasyondakinden
        // uzun ve en uzun gecikme çerçevenin yarısıyla sınırlı.
        val cerceve = (ornekHizi * 0.045).toInt().coerceAtLeast(512)
        val adim = (ornekHizi * 0.010).toInt().coerceAtLeast(64)
        val enKisaGecikme = (ornekHizi / EN_YUKSEK_HZ).toInt().coerceAtLeast(2)
        val enUzunGecikme = (ornekHizi / EN_DUSUK_HZ).toInt().coerceAtMost(cerceve / 2 - 1)
        if (enUzunGecikme <= enKisaGecikme) return BOS

        val bulunan = ArrayList<Double>()
        var bas = 0
        while (bas + cerceve <= ornekler.size) {
            val f0 = cerceveF0(ornekler, bas, cerceve, enKisaGecikme, enUzunGecikme, ornekHizi)
            if (f0 > 0) bulunan.add(f0)
            bas += adim
        }
        if (bulunan.size < EN_AZ_SESLI_CERCEVE) return Sonuc(0.0, bulunan.size, BELIRSIZ)

        bulunan.sort()
        val medyan = if (bulunan.size % 2 == 1) bulunan[bulunan.size / 2]
        else (bulunan[bulunan.size / 2 - 1] + bulunan[bulunan.size / 2]) / 2.0

        val cinsiyet = when {
            medyan < ERKEK_SINIRI -> ERKEK
            medyan > KADIN_SINIRI -> KADIN
            else -> BELIRSIZ
        }
        return Sonuc(medyan, bulunan.size, cinsiyet)
    }

    /**
     * Tek çerçevenin temel frekansı (YIN); çerçeve sesli değilse 0.
     *
     * NEDEN YIN, NEDEN OTOKORELASYON DEĞİL — bu kod iki kez hatalı yazıldı:
     *
     *  1. Önce düz otokorelasyonda EN YÜKSEK tepe seçiliyordu. Periyodun
     *     katlarında da güçlü tepe olduğu için 255 Hz'lik ses 127 Hz
     *     okunuyordu: bir oktav AŞAĞI.
     *  2. "En yüksek tepenin %85'ine ulaşan İLK tepeyi seç" diye düzeltildi.
     *     Bu sefer formantların yükselttiği ikinci harmonik yüzünden periyodun
     *     YARISINDAKİ tepeye takıldı: bir oktav YUKARI. Kullanıcının
     *     telefonunda 19 sesten 15'i "kadın" çıktı, erkek karakterler kadın
     *     sesiyle konuştu.
     *
     * YIN bu iki hatayı da önlemek için tasarlanmış standart yöntemdir:
     * farkların karesi alınır (otokorelasyon gibi benzerlik değil), birikimli
     * ortalamaya bölünerek normalleştirilir ve MUTLAK bir eşiğin altına düşen
     * İLK gecikme seçilir. Katları daha sonra geldiği için oktav yukarı; eşik
     * mutlak olduğu için oktav aşağı kayma olmaz.
     *
     * Kaynak: de Cheveigné & Kawahara (2002), "YIN, a fundamental frequency
     * estimator for speech and music".
     */
    private fun cerceveF0(
        x: FloatArray,
        bas: Int,
        uzunluk: Int,
        enKisa: Int,
        enUzun: Int,
        ornekHizi: Int,
    ): Double {
        val pencere = uzunluk / 2
        if (pencere <= enUzun) return 0.0

        // Sessizlik: ölçecek bir şey yok.
        var enerji = 0.0
        for (j in 0 until pencere) {
            val v = x[bas + j].toDouble()
            enerji += v * v
        }
        if (enerji < 1e-7) return 0.0

        // 1) Fark işlevi.
        val d = DoubleArray(enUzun + 1)
        for (tau in 1..enUzun) {
            var toplam = 0.0
            for (j in 0 until pencere) {
                val fark = x[bas + j] - x[bas + j + tau]
                toplam += fark * fark
            }
            d[tau] = toplam
        }

        // 2) Birikimli ortalamayla normalleştirme.
        val dn = DoubleArray(enUzun + 1)
        dn[0] = 1.0
        var kosu = 0.0
        for (tau in 1..enUzun) {
            kosu += d[tau]
            dn[tau] = if (kosu == 0.0) 1.0 else d[tau] * tau / kosu
        }

        // 3) Eşiğin altına düşen İLK gecikme; oradan yerel en düşüğe inilir.
        var tau = -1
        var t = enKisa
        while (t <= enUzun) {
            if (dn[t] < YIN_ESIK) {
                while (t + 1 <= enUzun && dn[t + 1] < dn[t]) t++
                tau = t
                break
            }
            t++
        }
        if (tau < 0) {
            // Eşiğin altına hiç inilmedi: en küçük değer yeterince düşükse onu al.
            var enAz = Double.MAX_VALUE
            var yer = -1
            for (g in enKisa..enUzun) {
                if (dn[g] < enAz) {
                    enAz = dn[g]
                    yer = g
                }
            }
            if (yer < 0 || enAz > YIN_UST_SINIR) return 0.0
            tau = yer
        }

        // 4) Parabolik ince ayar: örnekleme çözünürlüğünün altına inilir.
        var iyi = tau.toDouble()
        if (tau > enKisa && tau < enUzun) {
            val a = dn[tau - 1]
            val b = dn[tau]
            val c = dn[tau + 1]
            val payda = 2 * (2 * b - a - c)
            if (payda > 1e-12 || payda < -1e-12) iyi = tau + (c - a) / payda
        }
        if (iyi <= 0.0) return 0.0
        return ornekHizi.toDouble() / iyi
    }

    // ------------------------------------------------------------ WAV okuma

    data class Ses(val ornekler: FloatArray, val ornekHizi: Int)

    /**
     * Basit RIFF/WAVE okuyucu: 16 bit PCM, tek ya da çok kanal.
     * TextToSpeech.synthesizeToFile tam bunu üretiyor.
     * Çok kanallıysa kanallar ortalanır.
     */
    fun wavOku(dosya: File): Ses? {
        if (!dosya.isFile || dosya.length() < 44) return null
        RandomAccessFile(dosya, "r").use { f ->
            val bas = ByteArray(12)
            f.readFully(bas)
            if (String(bas, 0, 4, Charsets.US_ASCII) != "RIFF") return null
            if (String(bas, 8, 4, Charsets.US_ASCII) != "WAVE") return null

            var ornekHizi = 0
            var kanal = 1
            var bitDerinligi = 16
            var veri: ByteArray? = null

            while (f.filePointer + 8 <= f.length()) {
                val baslik = ByteArray(8)
                f.readFully(baslik)
                val ad = String(baslik, 0, 4, Charsets.US_ASCII)
                val boy = kucukUcInt(baslik, 4)
                if (boy < 0) return null
                when (ad) {
                    "fmt " -> {
                        val fmt = ByteArray(boy)
                        f.readFully(fmt)
                        kanal = kucukUcShort(fmt, 2)
                        ornekHizi = kucukUcInt(fmt, 4)
                        bitDerinligi = kucukUcShort(fmt, 14)
                    }
                    "data" -> {
                        val kalan = (f.length() - f.filePointer).toInt()
                        val okunacak = if (boy in 1..kalan) boy else kalan
                        if (okunacak <= 0) return null
                        val d = ByteArray(okunacak)
                        f.readFully(d)
                        veri = d
                    }
                    else -> f.seek(f.filePointer + boy + (boy and 1))
                }
                if (veri != null) break
            }

            val d = veri ?: return null
            if (ornekHizi <= 0 || kanal <= 0 || bitDerinligi != 16) return null

            val toplamOrnek = d.size / 2
            val cerceveSayisi = toplamOrnek / kanal
            if (cerceveSayisi <= 0) return null
            val out = FloatArray(cerceveSayisi)
            var o = 0
            for (c in 0 until cerceveSayisi) {
                var toplam = 0
                for (k in 0 until kanal) {
                    val lo = d[o].toInt() and 0xFF
                    val hi = d[o + 1].toInt()
                    toplam += (hi shl 8) or lo
                    o += 2
                }
                out[c] = (toplam.toFloat() / kanal) / 32768f
            }
            return Ses(out, ornekHizi)
        }
    }

    private fun kucukUcInt(b: ByteArray, i: Int): Int =
        (b[i].toInt() and 0xFF) or ((b[i + 1].toInt() and 0xFF) shl 8) or
            ((b[i + 2].toInt() and 0xFF) shl 16) or ((b[i + 3].toInt() and 0xFF) shl 24)

    private fun kucukUcShort(b: ByteArray, i: Int): Int =
        (b[i].toInt() and 0xFF) or ((b[i + 1].toInt() and 0xFF) shl 8)
}
