package com.example.altyazi

/**
 * TV YERLEŞİMİ (10.58)
 *
 * [TvMode]'un Android gerektirmeyen parçaları. Ayrı dosyada,
 * çünkü böylece tek başına derlenip sınanabiliyor; TvMode ise
 * DisplayManager ve UiModeManager'a bağlı.
 */
object TvYerlesim {

    /**
     * TV KENAR BOŞLUĞU (overscan, 10.58)
     *
     * Çoğu televizyon görüntünün kenarlarından %2-3 kırpıyor. TV'de
     * çalışırken ana ekranın kenarına paylaştırılan boşluk, düğmelerin
     * ve yazıların kesilmesini önlüyor. Android TV kılavuzu %5'e kadar
     * öneriyor; %3 hem güvenli hem ekranı boşa harcamıyor.
     */
    const val OVERSCAN_ORANI = 0.03f

    /** Verilen genişliğe göre kenar boşluğu (piksel). */
    fun overscanPx(genislik: Int, yukseklik: Int): Int =
        (minOf(genislik, yukseklik) * OVERSCAN_ORANI).toInt().coerceIn(0, 96)

    /**
     * TV'de hangi uygulamaların çevrilebildiği. Kopya koruması olan
     * video uygulamaları yakalamaya siyah kare veriyor; bu Android'in
     * kuralı, yazılımla aşılamaz. Oyun yayını uygulamaları görüntüyü
     * Android içinde ürettiği için çalışıyor.
     */
    fun tvCalisanlar(): String = """
ÇALIŞIR (görüntü Android içinde üretiliyor)
• GeForce NOW, Xbox Cloud Gaming, Boosteroid, Amazon Luna
• Steam Link (bilgisayardan oyun yayını)
• Chiaki / Pylux (PS5 uzaktan oynatma)
• Android TV'ye kurulu oyunlar
• YouTube, Kodi, VLC, tarayıcıdaki video, yerel dosyalar

ÇALIŞMAZ (kopya koruması yakalamayı kapatıyor)
• Netflix, Disney+, Prime Video, HBO Max
• TV'nin HDMI girişine bağlı konsol ya da kutu: ekran yakalama
  yalnız TV'nin KENDİ çalıştırdığı görüntüyü görebiliyor.
""".trimIndent()
}
