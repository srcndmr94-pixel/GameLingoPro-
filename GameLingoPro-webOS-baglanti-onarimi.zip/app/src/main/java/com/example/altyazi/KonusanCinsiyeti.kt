package com.example.altyazi

import java.util.Locale

/**
 * KONUŞAN ADINDAN CİNSİYET TAHMİNİ — 10.44
 *
 * Sesli okumada her karaktere uygun sesi verebilmek için altyazıdaki konuşan
 * adına ("JASON: ...", "Lucia: ...") bakar.
 *
 * NEDEN TAHMİN: Android'in konuşma motoru seslerin cinsiyetini BİLDİRMİYOR.
 * `Voice` sınıfında cinsiyet alanı yok; "tr-tr-x-ama-local" gibi adlardan da
 * anlaşılmıyor. Bu yüzden hangi sesin erkek hangisinin kadın olduğunu
 * kullanıcı ayarlardan dinleyerek seçiyor; bu dosya yalnız KONUŞANIN
 * hangisi olduğunu kestiriyor.
 *
 * Liste bilinçli olarak küçük ve kesin: tanımadığı adı zorlamıyor,
 * BILINMIYOR dönüyor. Yanlış cinsiyette okumak, ayrım yapmamaktan kötü.
 * Tanınmayan adlar SesliOku içinde ada göre sabit bir sese bağlanıyor —
 * cinsiyeti bilinmese de aynı karakter hep aynı sesle konuşuyor.
 */
object KonusanCinsiyeti {

    const val BILINMIYOR = 0
    const val ERKEK = 1
    const val KADIN = 2

    /**
     * Satırın başındaki konuşan adını döndürür, yoksa null.
     * "JASON: Arabaya bin." -> "JASON"
     */
    fun adiAyikla(satir: String?): String? {
        if (satir.isNullOrBlank()) return null
        val m = AD_ONEKI.find(satir.trim()) ?: return null
        val ad = m.groupValues[1].trim()
        return if (ad.isEmpty()) null else ad
    }

    /** Ada göre ERKEK / KADIN / BILINMIYOR. */
    fun tahmin(ad: String?): Int {
        if (ad.isNullOrBlank()) return BILINMIYOR
        val temiz = ad.trim().trim('.', ',', '!', '?', '"', '\'')
        if (temiz.isEmpty()) return BILINMIYOR
        // Çok kelimeli adın yalnız ilk kelimesi: "John Marston" -> "John".
        val ilk = temiz.substringBefore(' ')
        if (ilk.isEmpty()) return BILINMIYOR
        // İKİ ANAHTAR DENENİR.
        // Türkçe yerelde "IRENE".lowercase() -> "ırene" olur ve listedeki
        // "irene" ile eşleşmez; ROOT yerelde ise "İSMAİL" -> "i̇smail" olup
        // "ismail" ile eşleşmez. Bu yüzden ikisi de denenir.
        for (anahtar in setOf(ilk.lowercase(Locale.ROOT), ilk.lowercase(TR))) {
            if (anahtar in ERKEK_ADLARI) return ERKEK
            if (anahtar in KADIN_ADLARI) return KADIN
        }
        return BILINMIYOR
    }

    private val TR = Locale("tr", "TR")

    /** Satır başındaki "Ad:" ya da "Ad Soyad:" öneki. */
    private val AD_ONEKI =
        Regex("^(\\p{Lu}[\\p{L}.'\\-]{1,19}(?:\\s\\p{Lu}[\\p{L}.'\\-]{1,19})?)\\s*:\\s+")

    private val ERKEK_ADLARI = setOf(
        // Oyunlarda sık geçen İngilizce adlar
        "aaron", "abe", "adam", "alan", "albert", "alex", "alexander", "alfred", "andre", "andrew",
        "andy", "angel", "anthony", "arthur", "austin", "barry", "ben", "benjamin", "bill", "billy",
        "bob", "bobby", "brad", "brian", "bruce", "bryan", "caleb", "calvin", "carl", "carlos",
        "charles", "charlie", "chris", "christian", "christopher", "clark", "clay", "clint", "cole",
        "colin", "connor", "craig", "dan", "daniel", "danny", "dave", "david", "dean", "dennis",
        "derek", "desmond", "diego", "dominic", "don", "donald", "doug", "douglas", "drake", "duke",
        "dutch", "dylan", "earl", "eddie", "edward", "eli", "elijah", "eric", "ethan", "eugene",
        "evan", "ezekiel", "felix", "francis", "frank", "fred", "gabriel", "gary", "gavin", "george",
        "gerald", "glenn", "gordon", "graham", "grant", "greg", "gregory", "gus", "harold", "harry",
        "harvey", "hector", "henry", "herman", "howard", "hugo", "ian", "isaac", "ivan", "jack",
        "jacob", "jake", "james", "jamie", "jason", "javier", "jay", "jeff", "jeffrey", "jeremy",
        "jerome", "jerry", "jesse", "jim", "jimmy", "joe", "joel", "john", "johnny", "jonathan",
        "jordan", "jose", "joseph", "josh", "joshua", "juan", "julian", "justin", "keith", "ken",
        "kenneth", "kevin", "kyle", "lance", "larry", "lawrence", "lee", "leo", "leon", "leonard",
        "leroy", "lewis", "liam", "logan", "louis", "luca", "lucas", "luis", "luke", "malcolm",
        "manuel", "marcus", "mario", "mark", "marshall", "martin", "marty", "mason", "matt",
        "matthew", "max", "michael", "miguel", "mike", "miles", "mitch", "morgan", "nathan",
        "neil", "nick", "nicholas", "noah", "norman", "oliver", "oscar", "owen", "pablo", "patrick",
        "paul", "pedro", "perry", "peter", "philip", "phillip", "quentin", "rafael", "ralph",
        "randy", "ray", "raymond", "reggie", "rex", "ricardo", "richard", "rick", "ricky", "robert",
        "roger", "roland", "ron", "ronald", "ross", "roy", "russell", "ryan", "sam", "samuel",
        "scott", "sean", "sebastian", "sergio", "seth", "shane", "shaun", "shawn", "simon",
        "solomon", "stan", "stanley", "stephen", "steve", "steven", "stuart", "ted", "terry",
        "theodore", "thomas", "tim", "timothy", "tobias", "todd", "tom", "tommy", "tony", "travis",
        "trevor", "troy", "tyler", "victor", "vincent", "wade", "walter", "warren", "wayne",
        "wesley", "will", "william", "willie", "wyatt", "xavier", "zach", "zachary",
        // Türkçe adlar
        "ahmet", "ali", "arda", "baran", "barış", "baris", "berk", "burak", "bülent", "bulent",
        "can", "cem", "cengiz", "deniz", "doğan", "dogan", "efe", "emir", "emre", "ercan", "erdem",
        "eren", "ergin", "erhan", "erkan", "ersin", "fatih", "ferhat", "fikret", "furkan", "gökhan",
        "gokhan", "halil", "hakan", "hasan", "hüseyin", "huseyin", "ibrahim", "ilhan", "ismail",
        "kaan", "kadir", "kemal", "kerem", "koray", "levent", "mehmet", "mert", "metin", "murat",
        "mustafa", "nihat", "oğuz", "oguz", "okan", "onur", "orhan", "osman", "ömer", "omer",
        "özcan", "ozcan", "recep", "rıza", "riza", "sedat", "selim", "serkan", "sinan", "soner",
        "suat", "şahin", "sahin", "tarık", "tarik", "tolga", "tuncay", "turgut", "ufuk", "uğur",
        "ugur", "umut", "veli", "volkan", "yavuz", "yusuf", "zeki",
    )

    private val KADIN_ADLARI = setOf(
        // Oyunlarda sık geçen İngilizce adlar
        "abigail", "ada", "adriana", "agnes", "aisha", "alice", "alicia", "alison", "amanda",
        "amber", "amelia", "amy", "ana", "andrea", "angela", "angelina", "anita", "ann", "anna",
        "anne", "annie", "april", "ashley", "audrey", "ava", "barbara", "beatrice", "becky",
        "bella", "beth", "betty", "beverly", "bonnie", "brenda", "briana", "brittany", "brooke",
        "camila", "candice", "carla", "carmen", "carol", "caroline", "carolyn", "cassandra",
        "catherine", "cathy", "charlotte", "chelsea", "cheryl", "chloe", "christina", "christine",
        "cindy", "claire", "clara", "clarissa", "colleen", "connie", "courtney", "crystal",
        "daisy", "dana", "daphne", "dawn", "debbie", "deborah", "delilah", "denise", "diana",
        "diane", "dolores", "donna", "doris", "dorothy", "edith", "eileen", "elaine", "eleanor",
        "elena", "elizabeth", "ella", "ellen", "ellie", "elsa", "emily", "emma", "erica", "erin",
        "esther", "eva", "evelyn", "faith", "fiona", "frances", "gabriela", "gail", "gemma",
        "georgia", "gina", "gloria", "grace", "hannah", "harriet", "hazel", "heather", "heidi",
        "helen", "holly", "hope", "irene", "iris", "isabel", "isabella", "ivy", "jackie",
        "jacqueline", "jane", "janet", "janice", "jasmine", "jean", "jeanne", "jenna", "jennifer",
        "jenny", "jessica", "jill", "joan", "joanna", "jodie", "josephine", "joy", "joyce",
        "judith", "judy", "julia", "julie", "june", "karen", "kate", "katherine", "kathleen",
        "kathy", "katie", "kayla", "kelly", "kim", "kimberly", "kristen", "kristin", "laura",
        "lauren", "leah", "lena", "leslie", "lila", "lily", "linda", "lisa", "liz", "lois",
        "lola", "loretta", "lori", "louise", "lucia", "lucy", "lydia", "lynn", "mabel", "madison",
        "maggie", "mandy", "mara", "marcia", "margaret", "maria", "marie", "marilyn", "marion",
        "marissa", "martha", "mary", "maya", "megan", "melanie", "melissa", "mia", "michelle",
        "mildred", "miranda", "molly", "monica", "nadia", "nancy", "naomi", "natalie", "natasha",
        "nicole", "nina", "nora", "norma", "olivia", "paige", "pam", "pamela", "patricia",
        "paula", "pauline", "pearl", "peggy", "penny", "phoebe", "phyllis", "rachel", "rebecca",
        "regina", "renee", "rhonda", "rita", "roberta", "robin", "rosa", "rose", "rosemary",
        "roxanne", "ruby", "ruth", "sabrina", "sally", "samantha", "sandra", "sara", "sarah",
        "sasha", "scarlett", "selena", "sharon", "sheila", "shelley", "sherry", "shirley",
        "sofia", "sonia", "sophia", "sophie", "stacy", "stella", "stephanie", "sue", "susan",
        "suzanne", "sylvia", "tammy", "tanya", "tara", "teresa", "tessa", "theresa", "tiffany",
        "tina", "tracy", "trish", "ursula", "valerie", "vanessa", "vera", "veronica", "vicki",
        "victoria", "violet", "virginia", "vivian", "wanda", "wendy", "whitney", "willa", "yvonne",
        "zoe",
        // Türkçe adlar
        "asena", "aslı", "asli", "aybüke", "aybuke", "ayla", "ayşe", "ayse", "banu", "başak",
        "basak", "bahar", "belgin", "berrin", "betül", "betul", "burcu", "buse", "ceren", "ceyda",
        "çiğdem", "cigdem", "damla", "defne", "derya", "didem", "dilek", "duygu", "ebru", "ece",
        "eda", "elif", "elvan", "emel", "esra", "eylül", "eylul", "fatma", "filiz", "funda",
        "gamze", "gizem", "gül", "gul", "gülay", "gulay", "gülsüm", "gulsum", "hande", "hatice",
        "hülya", "hulya", "ilknur", "ipek", "irem", "işıl", "isil", "kübra", "kubra", "lale",
        "leyla", "melek", "melike", "meltem", "merve", "meryem", "mine", "müge", "muge", "nalan",
        "nazlı", "nazli", "neslihan", "nihan", "nilay", "nilgün", "nilgun", "nur", "nurcan",
        "özge", "ozge", "özlem", "ozlem", "pelin", "pınar", "pinar", "rabia", "selin", "sema",
        "semra", "sena", "serap", "sevgi", "sevil", "sibel", "sultan", "şeyma", "seyma", "tuba",
        "tuğba", "tugba", "tülay", "tulay", "ülkü", "ulku", "yasemin", "yeliz", "yeşim", "yesim",
        "zehra", "zeynep", "zuhal",
    )
}
