# GameLingo Pro webOS istemcisi

Bu klasör LG webOS web uygulamasıdır. `ares-package webos` komutuyla IPK oluşturulabilir (LG webOS CLI gerekir). TV'de Developer Mode ve yükleme yetkisi gerekir. Telefon ve TV aynı yerel ağda olmalıdır.

Telefonda GameLingo Pro > TV köprüsü açıkken yerel IP adresi ve 4 haneli kod TV uygulamasına girilir. Android altyazı servisi 47323 TCP üzerinden son Türkçe altyazıyı sunar; istemci 700 ms aralıklarla okur. İzin verilen cihazlar aynı ağdaki PIN'i bilen istemcilerdir; HTTP trafiği şifrelenmez, güvenilir ev ağı kullanın.

**Önemli sınırlama:** webOS normal web uygulaması HDMI girişindeki PS5 oyun görüntüsünün üstüne sistem katmanı çizemeyebilir. Bu istemci kendi ekranında altyazıyı gösterir, HDMI üstüne overlay garantisi vermez. PS Remote Play'in ekran yakalamayı engellediği durumlarda OCR da çalışmaz. Bu iki kısıt platformdan kaynaklanır.
