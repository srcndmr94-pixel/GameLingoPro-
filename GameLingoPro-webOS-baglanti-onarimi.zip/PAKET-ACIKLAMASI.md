# GameLingo Pro – kaynak kodu (APK değildir)

Bu ZIP Android Gradle projesini ve `webos/` altındaki LG webOS istemcisini içerir. ZIP dosyasını GitHub deposuna tek dosya olarak yüklemek, uygulama kodunu otomatik olarak değiştirmez.

## Doğrulanmış
- Android kaynak kodunda TV köprüsü ve altyazı HTTP uç noktası mevcut.
- webOS istemcisinin eşleştirme, zaman aşımı, hatalı PIN ve tekrar bağlanma mantığı düzenlendi.

## Doğrulanmamış / kısıtlar
- Android APK ve webOS IPK derlenmedi; gerçek TV ve PS5 cihaz testi yapılmadı.
- webOS uygulaması HDMI görüntüsünün üzerine altyazı çizemez; kendi uygulama ekranında görüntüler.
- PS Remote Play DRM / ekran yakalama kısıtları nedeniyle OCR her durumda çalışmayabilir.
