# GameLingo Pro hazırlık durumu

- Ayrı Android applicationId: `com.gamelingo.pro` (eski GameLingo korunur).
- Uygulama etiketi: GameLingo Pro.
- Koyu lacivert, neon turkuaz, mor ve pembe renk paleti.
- Mevcut açılış animasyonu yaklaşık 1.35 saniyeye kısaltıldı, metni yenilendi.
- Hesap girişi eklenmedi.
- Çeviri motorları ve mevcut özellikler kaynakta korundu.
- GitHub Actions debug APK workflow'u eklendi.

**Doğrulanmamış:** Gradle derlemesi, Pixel 9 Pro testi, tüm ekranlarda renk uyumu, OCR/çeviri hatalarının giderildiği.
**Not:** Açılışta eski animasyon çizimi kullanılır; yeni neon ikon görselinin birebir uygulanması sonraki tasarım işidir.

## Bu pakette yapılan yeni değişiklik
- GameLingo Pro açılışında 0,65 saniyelik özgün elektronik ses eklendi.
- Ses tercihi: `gamelingo_pro/acilis_sesi` (varsayılan açık).
- Eski GameLingo paket kimliği değiştirilmedi; Pro kimliği `com.gamelingo.pro`.
- webOS / PS Remote Play işlevlerinin tam entegrasyonu ve cihaz testleri henüz doğrulanmadı.
