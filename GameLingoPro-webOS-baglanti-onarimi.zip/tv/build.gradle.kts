// GameLingo TV — Android TV'nin kendisine kurulan AYRI uygulama.
// Kodun ve tasarımın tamamı telefon uygulamasıyla ORTAK (../app/src/main);
// burada yalnızca TV'ye özel olanlar var: paket adı, eski Android desteği,
// TV ana ekranı (leanback) manifesti ve afiş.
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    // Aynı namespace: ortak kod com.example.altyazi.R'yi kullanıyor.
    namespace = "com.example.altyazi"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.altyazi.tv"   // telefondaki GameLingo'dan ayrı uygulama
        minSdk = 28                                // Android 9 ve üstü TV'ler
        targetSdk = 34
        // 10.58: TV sürümü telefon sürümüyle aynı kodu taşıyor; sürüm adı
        // da onu göstersin. Eskiden "TV 2.0" yazıyordu ve hangi kodun
        // içinde olduğu anlaşılmıyordu.
        versionCode = 11
        versionName = "TV 10.60"
        ndk { abiFilters += listOf("armeabi-v7a", "arm64-v8a") }   // TV'lerin çoğu 32 bit ARM
    }

    signingConfigs {
        getByName("debug") {
            storeFile = file("../app/debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    sourceSets {
        getByName("main") {
            manifest.srcFile("src/main/AndroidManifest.xml")
            java.srcDirs("../app/src/main/java")
            res.srcDirs("../app/src/main/res", "src/main/res")
            // 10.59 — ZORUNLU: ortak kaynaklardaki FirefoxCeviri.kt
            // dev.davidv.translator.* arayüzlerini içe aktarıyor. Bu arayüzler
            // app/src/main/aidl altında duruyor; java.srcDirs ezildiği için
            // aidl klasörü de elle verilmeli, yoksa ":tv" derlemesi
            // "Unresolved reference 'dev'" ile düşer.
            aidl.srcDirs("../app/src/main/aidl")
        }
    }

    buildTypes {
        debug { isMinifyEnabled = false }
        release { isMinifyEnabled = false }
    }

    buildFeatures {
        viewBinding = false
        // Firefox çeviri motoru arayüzü (yukarıdaki aidl.srcDirs)
        aidl = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
        jniLibs { pickFirsts.add("**/liblitertlm_jni.so") }
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("com.google.mlkit:text-recognition:16.0.0")
    implementation("com.google.mlkit:translate:17.0.2")
    // 10.58 — ZORUNLU: ortak kaynaklardaki DogalSesMotoru.kt bu kütüphaneyi
    // içe aktarıyor. 10.49'da doğal ses motoru eklenirken TV modülüne
    // yazılmamış; o günden beri ":tv" derlemesi "unresolved reference
    // com.google.mlkit.genai" ile düşüyordu. TV'lerde AICore olmadığı için
    // motor çalışmayacak, DogalSesMotoru da zaten yedeğe düşüyor; ama
    // kaynak ortak olduğu için bağımlılık burada da bulunmalı.
    implementation("com.google.mlkit:genai-text-to-speech:1.0.0-alpha1")
    // Ortak kod derlensin diye var; TV'de model indirilmez, yapay zekâ hiç yüklenmez.
    implementation("com.google.ai.edge.litertlm:litertlm-android:0.18.1")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    // 10.59 — ZORUNLU: ortak kaynaklardaki OpusMtEngine.kt ai.onnxruntime.*
    // kullanıyor. TV'de OPUS-MT modeli indirilmez ve motor hiç kurulmaz,
    // ama kaynak ortak olduğu için kütüphane derlemede bulunmalı.
    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.22.0")
}
